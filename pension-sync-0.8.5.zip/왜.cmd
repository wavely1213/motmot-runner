@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem 왜 이런가 — 어떤 날 어떤 방이 왜 그 상태인지 한 장으로 본다. 읽기만 한다.
set /p D=날짜 (2026-10-04, 그냥 엔터면 오늘): 
node src/cli/why.js yeogi %D%
echo.
pause
