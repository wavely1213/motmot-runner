-- ─────────────────────────────────────────────────────────────────────────
-- 실행기 상태를 클라우드에 맡기는 표 (제안)
--
-- 왜: 실행기의 세션·자격증명·기억이 지금은 한 PC 의 state/ 폴더에만 있다. 그래서 PC 를 바꾸면
--     파트너센터에 다시 로그인(페어링)해야 하고, 클라우드 컨테이너로 옮기면 뜰 때마다 새로 로그인한다
--     (그때마다 사장님이 튕긴다 — 여기어때는 한 계정 동시 로그인이 안 된다).
--     이 표 하나면 "어떤 PC 에서 켜도 이어진다".
--
-- ★ 무엇이 들어오나: **봉인된 글자(blob)뿐이다.** 실행기가 올리기 직전에 .env 의 STATE_SECRET 으로
--   AES-256-GCM 봉인한다. 이 DB 는 그 열쇠를 모르므로 아이디·비밀번호·세션을 읽을 수 없다.
--   열쇠(STATE_SECRET)는 클라우드에 두지 않는다 — 자물쇠와 열쇠를 한 상자에 넣지 않는다는 뜻이다.
--   그래서 PC 를 옮길 때 손으로 옮기는 것은 `.env` 하나뿐이다.
--
-- 무엇이 안 들어오나: 브라우저 프로필 폴더(수백 MB·PC 마다 다름), artifacts/(실패 화면 사진).
--
-- 번호 75 는 74 다음으로 붙인 것이니 실제 번호에 맞춰 파일 이름을 바꿔 적용한다.
-- 기존 표·정책은 건드리지 않고 더하기만 한다.
-- ─────────────────────────────────────────────────────────────────────────

create table if not exists public.agent_state (
  property_id text        not null,
  name        text        not null,          -- 'executor-state' | '<채널>/creds' | '<채널>/storage'
  blob        text        not null,          -- 봉인된 글자('v1:…'). 평문이 들어오면 안 된다.
  updated_at  timestamptz not null default now(),
  device      text,                          -- 마지막으로 올린 PC 이름(누가 덮었는지 보려는 것뿐)
  primary key (property_id, name)
);

comment on table  public.agent_state is '실행기(pension-sync) 상태 — 봉인된 세션·자격증명·기억. 서버는 열쇠를 모른다.';
comment on column public.agent_state.blob is 'AES-256-GCM 으로 봉인된 글자. 열쇠는 실행기 PC 의 STATE_SECRET 뿐이다.';

-- 봉인 안 된 값이 실수로 들어오는 것을 막는다(평문 비밀번호가 DB 에 앉는 사고).
alter table public.agent_state drop constraint if exists agent_state_sealed;
alter table public.agent_state add  constraint agent_state_sealed check (blob like 'v1:%');

alter table public.agent_state enable row level security;

-- 로그인한 사용자(= 실행기 전용 계정)만 자기 숙소 줄을 다룬다.
-- is_staff_of(text) 가 있으면 그것으로 숙소 담당자를 가르고, 없으면 authenticated 전체에 연다.
do $$
declare has_staff boolean := to_regprocedure('public.is_staff_of(text)') is not null;
begin
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='agent_state' and policyname='agent_state_rw') then
    if has_staff then
      execute $p$create policy agent_state_rw on public.agent_state for all to authenticated
                 using (public.is_staff_of(property_id)) with check (public.is_staff_of(property_id))$p$;
    else
      execute $p$create policy agent_state_rw on public.agent_state for all to authenticated
                 using (true) with check (true)$p$;
      raise notice 'is_staff_of(text) 가 없어 authenticated 전체에 열었다 — 콘솔 정책과 맞춰 좁힐 것';
    end if;
  end if;
end $$;

-- 확인:
--   select property_id, name, updated_at, device, left(blob, 3) as 봉인 from public.agent_state;
--   → 봉인 칸이 전부 'v1:' 이어야 한다.
