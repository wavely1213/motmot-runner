-- ─────────────────────────────────────────────────────────────────────────
-- 실행기(pension-sync) 를 위한 대시보드 Supabase 추가 마이그레이션 (제안)
--
-- 이 파일은 대시보드 저장소의 supabase-NN-*.sql 관례를 따른 **제안**이다. 번호 74 는 콘솔에서 마지막으로
-- 보인 73 다음으로 추정한 것이니 실제 번호에 맞춰 이름을 바꿔 적용한다. 기존 표·정책은 바꾸지 않고 더하기만 한다.
--
-- 무엇을 하나
--  0) 그 표들에 authenticated 권한(GRANT)을 준다 — 정책이 다 있어도 권한이 없으면 permission denied 로 막힌다.
--  1) 실행기 전용 관리자 계정(사용자 JWT)이 콘솔은 읽기만 하는 표에 쓸 수 있게 정책을 연다:
--     agent_heartbeats(생존 신호), sync_runs(동기화 기록), channel_alerts(경보 열기·닫기), channel_room_map(자동 매핑 추가)
--     → 이 정책이 없으면 실행기는 MOTMOT_SERVICE_ROLE_KEY 로 폴백한다(둘 중 하나면 된다).
--  2) agent_heartbeats 에 (property_id, channel_code) 유일 제약이 없으면 만든다(upsert 용).
--  (실행기가 손댄 흔적 컬럼은 두지 않는다. 한 PC 에 실행기 하나라는 것을 자물쇠로 보장하므로 필요가 없다.)
--
-- 표가 없으면 그 부분은 건너뛴다(오류 없이). is_staff_of(text) 함수(supabase-15)가 있으면 그것으로 숙소 담당자를 가르고,
-- 없으면 로그인한 사용자 전체(authenticated)에게 연다 — 그 경우 관리자 명부(admin_users) 검사는 콘솔 쪽 정책에 맡긴다.
-- ─────────────────────────────────────────────────────────────────────────

create or replace function public._executor_policy(tbl text, pol text, cmd text, using_expr text, check_expr text)
returns void language plpgsql as $$
begin
  if to_regclass('public.' || tbl) is null then
    raise notice '표 % 가 없어 정책 % 을 건너뛴다', tbl, pol;
    return;
  end if;
  if exists (select 1 from pg_policies where schemaname = 'public' and tablename = tbl and policyname = pol) then
    raise notice '정책 % 이 이미 있다', pol;
    return;
  end if;
  -- ★ RLS 를 새로 켜지 않는다. 꺼져 있던 표에 켜면 그 순간 콘솔의 읽기가 전부 막힌다(정책이 없으니까).
  --   이 파일은 "추가만 한다" 가 원칙이다. 꺼져 있으면 건드리지 않고 알린다.
  if not (select relrowsecurity from pg_class where oid = ('public.' || tbl)::regclass) then
    raise notice '표 % 는 RLS 가 꺼져 있다 — 켜지 않고 건너뛴다(켜면 콘솔 읽기가 막힌다). service_role 로 쓸 것', tbl;
    return;
  end if;
  if cmd = 'select' then
    execute format('create policy %I on public.%I for select to authenticated using (%s)', pol, tbl, using_expr);
  elsif cmd = 'insert' then
    execute format('create policy %I on public.%I for insert to authenticated with check (%s)', pol, tbl, check_expr);
  elsif cmd = 'update' then
    execute format('create policy %I on public.%I for update to authenticated using (%s) with check (%s)', pol, tbl, using_expr, check_expr);
  end if;
end $$;

-- 0) 표 권한(GRANT) — 정책보다 먼저다.
--    RLS 정책이 다 들어가 있어도 표 자체에 권한이 없으면 `permission denied for table …` 로 막힌다.
--    정책과 권한은 다른 자물쇠다: 권한은 "이 표를 만질 수 있나", 정책은 "어느 줄을 만질 수 있나".
--    여기서 권한을 열어도 위의 RLS 정책(is_staff_of)이 그대로 줄을 가르므로, 남의 숙소는 여전히 못 건드린다.
--    (2026-09-11 실측: 정책만 넣은 PC 에서 생존 신호가 permission denied 로 막혔다.)
do $$
declare
  t text;
  privs text;
  s text;
begin
  foreach t in array array['agent_heartbeats', 'sync_runs', 'channel_alerts', 'channel_room_map'] loop
    if to_regclass('public.' || t) is null then
      raise notice '표 % 가 없어 권한을 건너뛴다', t;
      continue;
    end if;
    -- 실행기가 실제로 하는 일만 준다. delete 는 어느 표에도 주지 않는다.
    privs := case when t in ('sync_runs', 'channel_room_map') then 'select, insert' else 'select, insert, update' end;
    execute format('grant %s on public.%I to authenticated', privs, t);
    raise notice '표 % 에 % 권한을 주었다(authenticated)', t, privs;

    -- bigserial 등 시퀀스를 쓰는 표라면 insert 에 시퀀스 권한도 필요하다. 없으면 아무 일도 안 한다.
    for s in
      select quote_ident(n.nspname) || '.' || quote_ident(c.relname)
        from pg_class c
        join pg_namespace n on n.oid = c.relnamespace
        join pg_depend d on d.objid = c.oid and d.deptype = 'a'
        join pg_class r on r.oid = d.refobjid
       where c.relkind = 'S' and n.nspname = 'public' and r.relname = t
    loop
      execute format('grant usage, select on sequence %s to authenticated', s);
      raise notice '  시퀀스 % 도 함께', s;
    end loop;
  end loop;
end $$;

do $$
declare
  staff text;
begin
  -- 숙소 담당자 판정식. is_staff_of(supabase-15)가 있어야 "이 숙소 담당자만" 으로 좁힐 수 있다.
  -- ★ 없으면 정책을 만들지 않는다. 'true' 로 열면 로그인한 모든 사용자가 이 표에 쓸 수 있게 된다.
  if exists (select 1 from pg_proc where proname = 'is_staff_of') then
    staff := 'public.is_staff_of(property_id)';
  else
    raise notice '%', 'is_staff_of(text) 가 없어 쓰기 정책을 만들지 않는다 (supabase-15-multi-property.sql 을 먼저 적용하거나,';
    raise notice '%', '  실행기 .env 에 MOTMOT_SERVICE_ROLE_KEY 를 넣어 쓰기를 그쪽으로 돌릴 것). 아래 2·3 번만 진행한다.';
    staff := null;
  end if;

  -- 1) 쓰기 정책 (담당자 판정식이 있을 때만)
  if staff is not null then
  perform public._executor_policy('agent_heartbeats', 'executor_heartbeat_select', 'select', staff, null);
  perform public._executor_policy('agent_heartbeats', 'executor_heartbeat_insert', 'insert', null, staff);
  perform public._executor_policy('agent_heartbeats', 'executor_heartbeat_update', 'update', staff, staff);

  -- sync_runs 는 property_id 가 없을 수도 있다(콘솔 질의에 숙소 필터가 없다). 있으면 담당자, 없으면 로그인 사용자.
  -- sync_runs 에 property_id 가 없으면 숙소로 좁힐 수 없다. 관리자 명부(admin_users)로 좁힌다.
  if to_regclass('public.sync_runs') is not null then
    if exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'sync_runs' and column_name = 'property_id') then
      perform public._executor_policy('sync_runs', 'executor_sync_runs_insert', 'insert', null, staff);
      perform public._executor_policy('sync_runs', 'executor_sync_runs_select', 'select', staff, null);
    elsif to_regclass('public.admin_users') is not null then
      perform public._executor_policy('sync_runs', 'executor_sync_runs_insert', 'insert', null,
        'exists (select 1 from public.admin_users u where u.user_id = auth.uid() and u.active is not false)');
      perform public._executor_policy('sync_runs', 'executor_sync_runs_select', 'select',
        'exists (select 1 from public.admin_users u where u.user_id = auth.uid() and u.active is not false)', null);
    else
      raise notice '%', 'sync_runs 에 property_id 도 admin_users 도 없어 정책을 만들지 않는다 — service_role 로 쓸 것';
    end if;
  end if;

  perform public._executor_policy('channel_alerts', 'executor_alerts_select', 'select', staff, null);
  perform public._executor_policy('channel_alerts', 'executor_alerts_insert', 'insert', null, staff);
  perform public._executor_policy('channel_alerts', 'executor_alerts_update', 'update', staff, staff);

  perform public._executor_policy('channel_room_map', 'executor_room_map_insert', 'insert', null, staff);
  end if;   -- staff is not null

  -- 2) 생존 신호 유일 제약 (upsert onConflict 'property_id,channel_code')
  if to_regclass('public.agent_heartbeats') is not null
     and not exists (select 1 from pg_constraint where conrelid = 'public.agent_heartbeats'::regclass and contype in ('p', 'u')
                     and pg_get_constraintdef(oid) like '%property_id%channel_code%') then
    begin
      alter table public.agent_heartbeats add constraint agent_heartbeats_property_channel_key unique (property_id, channel_code);
    exception when others then
      raise notice 'agent_heartbeats 유일 제약을 못 만들었다(중복 행이 있을 수 있다): %', sqlerrm;
    end;
  end if;

end $$;

drop function if exists public._executor_policy(text, text, text, text, text);

-- 확인: 아래가 한 줄 이상 나오면 정책이 들어간 것이다.
-- select tablename, policyname, cmd from pg_policies where policyname like 'executor_%' order by 1, 2;
