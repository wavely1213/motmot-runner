﻿# 실행기를 윈도우 작업 스케줄러에 등록한다 — 등록하면 그 자리에서 바로 켜지고,
# 그 뒤로는 로그온할 때마다 자동으로 뜨고 죽으면 1분 뒤 다시 켠다.
#   PowerShell(관리자 아님도 됨) 에서 pension-sync 폴더로 가서:
#     powershell -ExecutionPolicy Bypass -File scripts\install-windows-task.ps1
#   지우기:
#     powershell -ExecutionPolicy Bypass -File scripts\install-windows-task.ps1 -Remove
#   상태:  Get-ScheduledTask -TaskName "pension-sync-executor" | Get-ScheduledTaskInfo
#   지금 켜기:  Start-ScheduledTask -TaskName "pension-sync-executor"
#   지금 끄기:  Stop-ScheduledTask  -TaskName "pension-sync-executor"
# ⚠ PC 가 잠자기에 들어가면 브라우저도 멈춘다. 전원 옵션에서 절전을 끌 것.
#
# ★ 이 파일은 **UTF-8 BOM** 으로 저장해야 한다. 한국어 윈도우의 Windows PowerShell 5.1 은
#   BOM 이 없는 .ps1 을 시스템 코드페이지(cp949)로 읽어서 아래 한글이 조용히 깨진다.
#   작업 이름을 ASCII 로 둔 것도 같은 이유다 — 이름이 깨지면 Start-ScheduledTask 가 못 찾는다.
param([switch]$Remove)

$TaskName = "pension-sync-executor"          # 사람이 콘솔에 그대로 칠 이름 — ASCII 로 둔다
$TaskDesc = "모트모트 실행기 (pension-sync) — 여기어때 파트너센터 동기화"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

if ($Remove) {
  Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
  Write-Host "지웠다: $TaskName"
  exit 0
}

$npm = (Get-Command npm.cmd -ErrorAction SilentlyContinue).Source
if (-not $npm) { Write-Error "npm 을 찾지 못했다 — Node.js 22 를 설치하고 새 창에서 다시 실행할 것"; exit 1 }
if (-not (Test-Path (Join-Path $Root ".env"))) { Write-Error ".env 가 없다 — env.example 을 복사해 채울 것 ($Root)"; exit 1 }

$logDir = Join-Path $Root "state"
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$log = Join-Path $logDir "executor.log"

# ★ cmd.exe 로 등록하면 켤 때마다 검은 창이 뜬다. 사장님이 제일 싫어하는 그 창이다.
#   클라이언트 exe 에 창 없이 실행기만 띄우는 자리(--executor)를 만들어 두었으므로
#   그것을 등록한다. 그 exe 는 창이 없고(-H=windowsgui), 자식(node)도 CREATE_NO_WINDOW
#   로 띄우므로 아무 창도 안 뜬다. 로그도 그 안에서 파일로 흘린다.
$client = Join-Path $Root "실행기.exe"
if (Test-Path $client) {
  $action = New-ScheduledTaskAction -Execute $client -Argument "--executor" -WorkingDirectory $Root
  Write-Host "[ACTION=CLIENT] 창 없이 도는 방식으로 등록한다: $client --executor"
} else {
  # exe 가 아직 없으면 예전 방식으로라도 등록한다(창이 뜬다).
  $action = New-ScheduledTaskAction -Execute "cmd.exe" `
    -Argument "/c `"`"$npm`" start >> `"$log`" 2>&1`"" `
    -WorkingDirectory $Root
  Write-Host "[ACTION=CMD] 실행기.exe 를 못 찾았다: $client"
  Write-Warning "예전 방식으로 등록한다 — 켤 때 검은 창이 뜬다. exe 를 그 자리에 넣고 다시 등록할 것."
}
# ★ 트리거가 로그온 하나뿐이면, 실행기가 한 번 죽었을 때 **다시 안 뜬다.**
#   -RestartCount 는 "작업이 비정상 종료했을 때" 만 걸리는데, 사람이나 다른 프로그램이
#   끝낸 경우(0x41306)에는 안 걸린다. 2026-09-14 에 실제로 그렇게 꺼진 채로 남았다.
#   그래서 5분마다 깨우는 트리거를 같이 건다 — 이미 돌고 있으면 IgnoreNew 로 무시되고,
#   죽어 있으면 5분 안에 다시 뜬다. 이것이 그물이다.
$trigger = @(
  (New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME),
  (New-ScheduledTaskTrigger -Once -At (Get-Date) `
     -RepetitionInterval (New-TimeSpan -Minutes 5) `
     -RepetitionDuration (New-TimeSpan -Days 3650))
)
$settings = New-ScheduledTaskSettingsSet -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) `
  -ExecutionTimeLimit (New-TimeSpan -Days 3650) -StartWhenAvailable -DontStopIfGoingOnBatteries -AllowStartIfOnBatteries `
  -MultipleInstances IgnoreNew
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Limited

Register-ScheduledTask -TaskName $TaskName -Description $TaskDesc -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Force | Out-Null
Write-Host "등록했다: $TaskName  (로그: $log)"

# ★ 등록만 하면 다음 로그온까지 아무것도 안 돈다 — 그 사이 예약 유입이 통째로 빈다. 여기서 바로 켠다.
Start-ScheduledTask -TaskName $TaskName
Start-Sleep -Seconds 3
$info = Get-ScheduledTask -TaskName $TaskName | Get-ScheduledTaskInfo
Write-Host "지금 켰다 — 상태: $((Get-ScheduledTask -TaskName $TaskName).State)  (마지막 결과 $($info.LastTaskResult))"
Write-Host ""
Write-Host "  잘 도는지 보려면:  Get-Content `"$log`" -Tail 20 -Wait"
Write-Host "  끄려면:            Stop-ScheduledTask  -TaskName `"$TaskName`""
Write-Host "  다시 켜려면:       Start-ScheduledTask -TaskName `"$TaskName`""
Write-Host ""
Write-Host "  ※ 재부팅 뒤 사람 없이도 뜨게 하려면 자동 로그인이 필요하다(로그온할 때 켜지는 작업이다)."
