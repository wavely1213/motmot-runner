﻿# 모트모트 실행기 조작판 — 더블클릭으로 켜고·끄고·상태 보기.
#   여는 법: pension-sync 폴더의 "실행기.cmd" 를 더블클릭한다.
#
# ★ 이 파일은 **UTF-8 BOM** 으로 저장해야 한다. 한국어 윈도우의 Windows PowerShell 5.1 은
#   BOM 없는 .ps1 을 cp949 로 읽어서 아래 한글이 조용히 깨진다(install-windows-task.ps1 과 같은 이유).

$TaskName = 'pension-sync-executor'
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Log  = Join-Path $Root 'state\executor.log'
$Lock = Join-Path $Root 'state\executor.lock'

try { $Host.UI.RawUI.WindowTitle = '모트모트 실행기' } catch { }
Set-Location $Root

function Get-TaskState {
  try { return (Get-ScheduledTask -TaskName $TaskName -ErrorAction Stop).State } catch { return $null }
}

# 자물쇠 파일에 적힌 pid — 지금 실행기를 돌리는 프로세스다(state/executor.lock).
function Get-LockPid {
  if (-not (Test-Path $Lock)) { return 0 }
  try {
    $j = Get-Content $Lock -Raw -Encoding UTF8 | ConvertFrom-Json
    return [int]$j.pid
  } catch { return 0 }
}

function Test-Alive([int]$ProcId) {
  if ($ProcId -le 0) { return $false }
  try { $null = Get-Process -Id $ProcId -ErrorAction Stop; return $true } catch { return $false }
}

# 로그가 마지막으로 쓰인 지 얼마나 됐나. 로그 글자를 해석하지 않고 파일 시각만 본다.
function Get-LogAge {
  if (-not (Test-Path $Log)) { return $null }
  return ((Get-Date) - (Get-Item $Log).LastWriteTime)
}

# 얼마나 지났는지를 사람 말로. 초만 찍으면 "10,800초 전" 같은 게 나와 읽히지 않는다.
# ★ 숫자는 반드시 -f 로 넣는다. "$sec초" 라고 쓰면 파워셸이 '$sec초' 를 **변수 이름 하나**로
#   읽어서(한글도 변수명에 쓸 수 있다) 빈칸이 찍힌다 — 실제로 그렇게 나왔다.
# ★ [int] 는 반올림이다. 1.5시간이 "2시간" 으로 나오므로 내림([Math]::Floor)을 쓴다.
function Format-Ago([TimeSpan]$Span) {
  $sec = [Math]::Floor($Span.TotalSeconds)
  if ($sec -lt 90)    { return ('{0}초 전' -f $sec) }
  if ($sec -lt 5400)  { return ('{0}분 전' -f [Math]::Floor($Span.TotalMinutes)) }
  if ($sec -lt 86400) { return ('{0}시간 {1}분 전' -f [Math]::Floor($Span.TotalHours), $Span.Minutes) }
  return ('{0}일 전' -f [Math]::Floor($Span.TotalDays))
}

function Write-Line([string]$Text, [string]$Color) {
  if ($Color) { Write-Host $Text -ForegroundColor $Color } else { Write-Host $Text }
}

function Show-Status {
  Write-Host ''
  $state = Get-TaskState
  $procId = Get-LockPid
  $alive = Test-Alive $procId
  $age = Get-LogAge

  if ($alive -and $null -ne $age -and $age.TotalMinutes -lt 5) {
    Write-Line '  ● 돌고 있습니다' 'Green'
  } elseif ($alive) {
    Write-Line '  ● 떠 있는데 최근 5분간 일한 기록이 없습니다 — 로그를 볼 것' 'Yellow'
  } else {
    Write-Line '  ● 꺼져 있습니다' 'Red'
  }

  if ($null -eq $state) {
    Write-Line '     예약 작업  : 등록 안 됨 (메뉴 [7] 로 등록)' 'Yellow'
  } else {
    Write-Host "     예약 작업  : $state"
  }
  if ($alive) { Write-Host "     프로세스   : 살아 있음 (pid $procId)" }
  else        { Write-Host '     프로세스   : 없음' }
  if ($null -eq $age) {
    Write-Host '     마지막 기록: 로그 파일이 아직 없음'
  } else {
    Write-Host ('     마지막 기록: ' + (Format-Ago $age))
  }

  # 한 판이 끝날 때마다 남는 줄 — 다섯 칸이 정상인지 여기서 보인다.
  if (Test-Path $Log) {
    $lap = Select-String -Path $Log -Pattern 'rooms:.*inbound:' -Encoding UTF8 -ErrorAction SilentlyContinue | Select-Object -Last 1
    if ($lap) { Write-Host ('     마지막 한 바퀴: ' + $lap.Line.Trim()) }

    # 최근 기록에 에러가 있었는지. 오래된 것까지 훑지 않는다(파일이 커진다).
    $tail = Get-Content $Log -Tail 400 -Encoding UTF8 -ErrorAction SilentlyContinue
    $errs = @($tail | Select-String -Pattern '\[error\]')
    if ($errs.Count -gt 0) {
      Write-Line ("     [!] 최근 기록에 에러 {0}건 — 메뉴 [4] 로 볼 것" -f $errs.Count) 'Yellow'
    }
  }
  Write-Host ''
}

# 실행기를 멈춘다. 예약 작업을 먼저 끄고(작업이 띄운 프로세스는 같이 죽는다),
# 손으로 켠 창이 남아 있으면 자물쇠에 적힌 pid 로 끈다.
function Stop-Executor {
  Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
  Start-Sleep -Seconds 2
  $procId = Get-LockPid
  if (Test-Alive $procId) {
    Write-Host "     남아 있는 실행기를 끕니다 (pid $procId)"
    Stop-Process -Id $procId -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
  }
  # node 를 강제로 끄면 브라우저가 고아로 남아 프로필을 계속 쥔다 — 다음 켜기가 막힌다.
  # 우리 프로필 폴더를 쓰는 크롬만 골라 정리한다(다른 크롬은 건드리지 않는다).
  $profileDir = Join-Path $Root 'state'
  try {
    $chromes = Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" -ErrorAction SilentlyContinue |
      Where-Object { $_.CommandLine -and $_.CommandLine.Contains($profileDir) }
    foreach ($c in $chromes) { Stop-Process -Id $c.ProcessId -Force -ErrorAction SilentlyContinue }
    if ($chromes) { Write-Host ("     실행기가 쓰던 브라우저 {0}개를 정리했습니다" -f @($chromes).Count) }
  } catch { }
}

function Start-Executor {
  Write-Host ''
  Write-Host '  켜는 중…'
  # 이미 하나 돌고 있으면 새로 뜬 쪽이 자물쇠에 막혀 곧바로 물러난다(main.js).
  # 그래서 "켜기" 는 항상 정리부터 한다 — 손으로 켠 창이 있어도 이 한 번으로 넘어온다.
  Stop-Executor

  $state = Get-TaskState
  if ($null -eq $state) {
    Write-Line '  예약 작업이 등록돼 있지 않습니다 — 먼저 [7] 로 등록하세요.' 'Yellow'
    return
  }
  Start-ScheduledTask -TaskName $TaskName

  # 떴는지 눈으로 확인될 때까지 기다린다 — "켰다" 만 말하고 끝내지 않는다.
  $before = $null
  if (Test-Path $Log) { $before = (Get-Item $Log).LastWriteTime }
  for ($i = 0; $i -lt 30; $i++) {
    Start-Sleep -Seconds 2
    $procId = Get-LockPid
    if (Test-Alive $procId) {
      $now = $null
      if (Test-Path $Log) { $now = (Get-Item $Log).LastWriteTime }
      if ($null -ne $now -and ($null -eq $before -or $now -gt $before)) {
        Write-Line '  [됨] 켜졌습니다. 이제 이 창을 닫으셔도 계속 돕니다.' 'Green'
        return
      }
    }
  }
  Write-Line '  켜긴 했는데 1분 안에 일한 기록이 안 보입니다 — [4] 로 로그를 볼 것.' 'Yellow'
}

function Show-Log {
  if (-not (Test-Path $Log)) { Write-Line '  로그 파일이 아직 없습니다.' 'Yellow'; return }
  Write-Host ''
  Write-Host '  실시간 로그입니다. 보기를 끝내려면 Ctrl+C 를 누르세요.'
  Write-Host '  (창을 닫아도 실행기는 계속 돕니다)'
  Write-Host ''
  try { Get-Content $Log -Tail 30 -Wait -Encoding UTF8 } catch { }
}

function Invoke-Npm([string[]]$NpmArgs, [string]$Title) {
  $procId = Get-LockPid
  if (Test-Alive $procId) {
    Write-Line '  실행기가 돌고 있어 브라우저를 같이 못 씁니다. 잠깐 끄고 하겠습니다.' 'Yellow'
    Stop-Executor
    $restart = $true
  } else { $restart = $false }

  Write-Host ''
  Write-Host "  $Title …"
  Write-Host ''
  & npm.cmd @NpmArgs
  Write-Host ''
  if ($restart) {
    Write-Host '  실행기를 다시 켭니다.'
    Start-Executor
  }
}

function Install-Task {
  $script = Join-Path $Root 'scripts\install-windows-task.ps1'
  if (-not (Test-Path $script)) { Write-Line '  등록 스크립트를 못 찾았습니다.' 'Red'; return }
  & powershell -NoProfile -ExecutionPolicy Bypass -File $script
}

# 문제가 생겼을 때 "이것만 보내면 되는" 파일 하나를 만든다.
# 로그에는 예약자 이름·연락처·금액이 원래 안 찍히므로(scrubSecrets·maskPii) 그대로 보내도 안전하다.
function New-Report {
  $stamp = Get-Date -Format 'yyyyMMdd-HHmm'
  $out = Join-Path $Root ("state\보고서-" + $stamp + ".txt")
  $lines = New-Object System.Collections.Generic.List[string]

  $lines.Add('모트모트 실행기 상태 보고서')
  $lines.Add('만든 시각: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
  $lines.Add('')
  $lines.Add('[ 지금 상태 ]')

  $state = Get-TaskState
  if ($null -eq $state) { $lines.Add('  예약 작업  : 등록 안 됨') } else { $lines.Add('  예약 작업  : ' + $state) }

  $procId = Get-LockPid
  if (Test-Alive $procId) { $lines.Add('  프로세스   : 살아 있음 (pid ' + $procId + ')') }
  else { $lines.Add('  프로세스   : 없음') }

  $age = Get-LogAge
  if ($null -eq $age) { $lines.Add('  마지막 기록: 로그 없음') }
  else { $lines.Add('  마지막 기록: ' + (Format-Ago $age)) }

  # 작업이 언제 왜 끝났는지 — Ready 로 떨어진 까닭이 여기 남는다.
  try {
    $info = Get-ScheduledTaskInfo -TaskName $TaskName -ErrorAction Stop
    $lines.Add('  마지막 실행: ' + $info.LastRunTime + '  (결과 코드 ' + $info.LastTaskResult + ')')
    $lines.Add('  다음 실행  : ' + $info.NextRunTime)
  } catch { $lines.Add('  마지막 실행: 알 수 없음') }

  $lines.Add('')
  $lines.Add('[ 최근 에러 ]')
  if (Test-Path $Log) {
    $tail = Get-Content $Log -Tail 2000 -Encoding UTF8 -ErrorAction SilentlyContinue
    $errs = @($tail | Select-String -Pattern '\[error\]') | Select-Object -Last 20
    if ($errs.Count -eq 0) { $lines.Add('  없음') }
    else { foreach ($e in $errs) { $lines.Add('  ' + $e.Line.Trim()) } }

    $lines.Add('')
    $lines.Add('[ 마지막 기록 200줄 ]')
    foreach ($l in (Get-Content $Log -Tail 200 -Encoding UTF8 -ErrorAction SilentlyContinue)) { $lines.Add($l) }
  } else {
    $lines.Add('  로그 파일이 없다')
  }

  $lines | Set-Content -Path $out -Encoding UTF8
  Write-Line ('  [됨] 만들었습니다: ' + $out) 'Green'
  Write-Host '       이 파일 하나만 보내 주시면 됩니다.'
  try { Start-Process explorer.exe ('/select,"' + $out + '"') } catch { }
}

function New-DesktopShortcut {
  $cmd = Join-Path $Root '실행기.cmd'
  if (-not (Test-Path $cmd)) { Write-Line '  실행기.cmd 를 못 찾았습니다.' 'Red'; return }
  $link = Join-Path ([Environment]::GetFolderPath('Desktop')) '모트모트 실행기.lnk'
  try {
    $ws = New-Object -ComObject WScript.Shell
    $sc = $ws.CreateShortcut($link)
    $sc.TargetPath = $cmd
    $sc.WorkingDirectory = $Root
    $sc.Description = '모트모트 실행기 — 여기어때 동기화 켜기·끄기·상태'
    $sc.IconLocation = "$env:SystemRoot\System32\shell32.dll,137"
    $sc.Save()
    Write-Line "  [됨] 바탕화면에 만들었습니다: 모트모트 실행기" 'Green'
  } catch {
    Write-Line ('  바로가기를 못 만들었습니다 — ' + $_.Exception.Message) 'Red'
  }
}

while ($true) {
  Clear-Host
  Write-Host ''
  Write-Host '  ┌──────────────────────────────────────────┐'
  Write-Host '  │   모트모트 실행기 (여기어때 자동 동기화)  │'
  Write-Host '  └──────────────────────────────────────────┘'
  Show-Status
  Write-Host '   [1] 켜기            [2] 끄기'
  Write-Host '   [3] 상태 새로고침   [4] 로그 보기'
  Write-Host '   [5] 미리보기 (저장 안 하고 한 바퀴만 확인)'
  Write-Host '   [6] 점검 (doctor)   [7] 자동시작 등록'
  Write-Host '   [8] 바탕화면 바로가기 만들기'
  Write-Host '   [9] 보고서 만들기 (문제 생기면 이 파일만 보내면 됨)'
  Write-Host '   [0] 닫기'
  Write-Host ''
  $pick = Read-Host '   고르세요'

  switch ($pick) {
    '1' { Start-Executor; Read-Host '   엔터를 누르면 돌아갑니다' | Out-Null }
    '2' {
      Write-Host ''
      Stop-Executor
      Write-Line '  [됨] 껐습니다. 다시 켜려면 [1] 을 고르세요.' 'Green'
      Read-Host '   엔터를 누르면 돌아갑니다' | Out-Null
    }
    '3' { }
    '4' { Show-Log }
    '5' { Invoke-Npm @('run','once','--','--preview') '미리보기 (아무것도 저장하지 않습니다)'; Read-Host '   엔터를 누르면 돌아갑니다' | Out-Null }
    '6' { Invoke-Npm @('run','doctor','--','--write') '점검'; Read-Host '   엔터를 누르면 돌아갑니다' | Out-Null }
    '7' { Install-Task; Read-Host '   엔터를 누르면 돌아갑니다' | Out-Null }
    '8' { New-DesktopShortcut; Read-Host '   엔터를 누르면 돌아갑니다' | Out-Null }
    '9' { Write-Host ''; New-Report; Read-Host '   엔터를 누르면 돌아갑니다' | Out-Null }
    '0' { return }
    default { }
  }
}
