#!/usr/bin/env bash
# 새 판을 만든다 — 올릴 파일 두 개(압축 + 안내문)를 dist/ 에 뽑아 준다.
#
#   bash scripts/publish-update.sh 0.2.0 "고친 것을 한 줄씩 적는다"
#
# 뽑힌 두 파일을 업데이트 주소(버킷)에 올리면, 사장님이 실행기를 켤 때
# 알아서 받아서 적용하고 새 판으로 다시 뜬다.
set -euo pipefail

VER="${1:?판 번호를 적을 것 — 예: 0.2.0}"
NOTES="${2:-}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/dist"
# 올릴 자리 — **실행기 전용 공개 저장소**(motmot-runner)다.
#
# ★ 왜 옮겼나 (2026-09-15): 전에는 바이브 보드(Vercel)에 올렸는데, main 에 머지해도
#   운영 배포가 18시간째 안 바뀌어 실행기가 새 판을 영영 못 봤다. 사이에 배포 파이프라인이
#   한 겹 있으면 그것이 멈출 때마다 업데이트가 같이 멈춘다. 저장소에 밀어 넣으면 그 겹이 없다.
#
# ★ 왜 Releases 가 아니라 raw 인가: 릴리스 자산을 올리는 것은 내(AI) 권한 밖이라
#   사장님이 매번 손으로 올려야 한다 — 그러면 자동이 아니다. raw 는 밀어 넣기만 하면 된다.
#   안내문과 꾸러미가 **같은 호스트**(raw.githubusercontent.com)라 실행기의 검사도 그대로 통과한다.
#
# ★ 이 저장소에는 **코드가 없다.** 꾸러미(zip)와 안내문(latest.json)뿐이다.
#   비밀값·계정·손님 정보는 애초에 꾸러미에 안 들어간다(아래 zip 목록 참고).
RUNNER_REPO_SLUG="${RUNNER_REPO_SLUG:-wavely1213/motmot-runner}"
RUNNER_BRANCH="${RUNNER_BRANCH:-main}"
BASE="${UPDATE_BASE:-https://raw.githubusercontent.com/$RUNNER_REPO_SLUG/$RUNNER_BRANCH}"
# 그 저장소를 받아 둔 자리. 없으면 파일만 dist/ 에 뽑고 만다.
WEBDIR="${UPDATE_WEBROOT:-$ROOT/../motmot-runner}"

# ★ 같은 판 번호로 다시 올리지 않는다. 받는 쪽은 **번호만** 보고 새 판인지 정하므로,
#   내용이 달라도 번호가 같으면 사장님 PC 는 영영 안 받는다(2026-09-18 검토).
UP=$(curl -fsSL "$BASE/latest.json" 2>/dev/null | python3 -c 'import json,sys; print(json.load(sys.stdin).get("version",""))' 2>/dev/null || true)
if [ -n "$UP" ] && [ "$UP" = "$VER" ]; then
  echo "이미 $VER 이 올라가 있다 — 판 번호를 올릴 것 (지금 올라간 판: $UP)" >&2
  exit 1
fi

cd "$ROOT"
rm -rf "$OUT"; mkdir -p "$OUT"

# ★ 화면(ui.html)이 exe 안에 박히므로 exe 를 먼저 새로 만든다.
#   판 번호도 여기서 박는다 — 안 박으면 켤 때마다 같은 판을 또 받는다.
( cd tools/panel && GOOS=windows GOARCH=amd64 \
  go build -ldflags "-H=windowsgui -s -w -X main.version=$VER" -o "$OUT/실행기.exe" . )

# 그 PC 의 것은 넣지 않는다 — .env(비밀값)·state(세션·로그)·node_modules.
# 넣어도 받는 쪽이 거르지만, 애초에 만들지 않는 편이 안전하다.
# 돌아가는 데 필요한 것만 넣는다. 지침 문서(docs·AGENTS.md)는 저장소에 있으면 되고,
# 이 압축은 누구나 열 수 있는 자리에 올라가므로 적을수록 좋다.
# ★ 눌러서 쓰는 파일(.cmd)도 넣는다. 2026-09-18 에 `왜.cmd` 를 새로 만들고도 꾸러미에 안 넣어
#   업데이트로는 영영 안 갔다 — 새 명령을 만들면 여기 목록에도 넣어야 사장님 PC 에 닿는다.
zip -qr "$OUT/pension-sync-$VER.zip" \
  package.json package-lock.json src config scripts sql \
  README.md env.example 실행기.cmd 왜.cmd \
  -x '*/node_modules/*' '*.log' '*.test.js'
( cd "$OUT" && zip -q "pension-sync-$VER.zip" "실행기.exe" )

SHA=$(sha256sum "$OUT/pension-sync-$VER.zip" | cut -d' ' -f1)

# 안내문. zip 주소는 안내문과 **같은 호스트**여야 받는 쪽이 받아들인다.
cat > "$OUT/latest.json" <<JSON
{
  "version": "$VER",
  "notes": $(printf '%s' "$NOTES" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))'),
  "zip": "$BASE/pension-sync-$VER.zip",
  "sha256": "$SHA"
}
JSON

# 배포 저장소에 넣는다.
#
# ★ **역사를 남기지 않는다.** 판마다 3MB 짜리 꾸러미가 쌓이면 저장소가 그만큼 무거워지고,
#   그 무게는 영영 안 줄어든다(깃은 지운 파일도 들고 있다). 이 저장소는 '지금 판' 하나만
#   있으면 되는 자리다 — 그래서 매번 **뿌리 없는 커밋 하나**로 갈아 끼운다.
if [ -d "$WEBDIR/.git" ]; then
  rm -f "$WEBDIR"/pension-sync-*.zip
  cp "$OUT/pension-sync-$VER.zip" "$OUT/latest.json" "$WEBDIR/"
  cat > "$WEBDIR/README.md" <<MD
# 모트모트 실행기 — 배포 자리

여기는 **코드가 아니라 꾸러미**만 두는 곳이다. 실행기가 켤 때 \`latest.json\` 을 보고,
새 판이면 물어본 뒤 \`pension-sync-*.zip\` 을 받아 갈아 끼운다.

- \`latest.json\` — 지금 판 번호·주소·sha256
- \`pension-sync-$VER.zip\` — 지금 판 꾸러미(실행기.exe 포함)

받는 쪽은 https 만 받고, 꾸러미 주소가 안내문과 같은 호스트여야 하며, sha256 이 맞아야만 적용한다.
\`.env\`(비밀값)·\`state\`(세션·로그)·\`node_modules\`·\`artifacts\` 는 덮지 않는다.

판마다 뿌리 없는 커밋 하나로 갈아 끼운다 — 옛 꾸러미가 역사에 쌓이지 않게.
MD
  ( cd "$WEBDIR"
    git checkout --orphan "tmp-$VER" >/dev/null 2>&1
    git add -A
    git -c user.email=noreply@anthropic.com -c user.name=Claude commit -q -m "실행기 $VER"
    git branch -M "$RUNNER_BRANCH"
    git push --force -u origin "$RUNNER_BRANCH" )
  echo "배포 저장소에 올렸다: $RUNNER_REPO_SLUG ($RUNNER_BRANCH)"
  echo "→ 확인:  curl -s $BASE/latest.json"
else
  echo "배포 저장소가 없다($WEBDIR) — 파일만 dist/ 에 뽑았다."
  echo "  git clone https://github.com/$RUNNER_REPO_SLUG.git \"$WEBDIR\"  한 뒤 다시 돌리면 올라간다."
fi

echo
echo "만들었다 — 이 둘을 $BASE 에 올릴 것:"
echo "  $OUT/pension-sync-$VER.zip   ($(du -h "$OUT/pension-sync-$VER.zip" | cut -f1))"
echo "  $OUT/latest.json"
echo
cat "$OUT/latest.json"
