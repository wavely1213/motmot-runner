/* 채널 하나 = 브라우저 프로필 하나(state/<channel>/profile). 로그인 상태(쿠키·저장소)가 여기 남아 재시작해도 이어진다.
   같은 프로필로 브라우저를 둘 띄울 수 없으니 채널 작업은 자연히 직렬이다(BR-011).
   자격증명(creds.json)과 세션 백업(storage.json)은 STATE_SECRET 로 잠근다(BR-010). */
import fs from 'node:fs';
import path from 'node:path';
import { sealJson, openJson } from './secrets.js';
import { heldByOther } from '../lib/lock.js';
import { deadline, soft } from '../lib/deadline.js';

export class ChannelSession {
  /**
   * @param {object} o  { channel, stateDir, secret, headless, browser:{channel,executablePath,slowMoMs,timeoutMs}, log, playwright }
   */
  constructor(o) {
    this.channel = o.channel;
    this.stateDir = o.stateDir;
    this.dir = path.join(o.stateDir, o.channel);
    this.profileDir = path.join(this.dir, 'profile');
    this.credsFile = path.join(this.dir, 'creds.json');
    this.storageFile = path.join(this.dir, 'storage.json');
    this.secret = o.secret || '';
    this.headless = o.headless !== false;
    this.browser = o.browser || {};
    this.log = o.log;
    this.pw = o.playwright || null;
    this.context = null;
    this.page = null;
  }

  ensureDir() {
    fs.mkdirSync(this.profileDir, { recursive: true, mode: 0o700 });
  }

  // ── 자격증명 ───────────────────────────────────────────────
  saveCreds({ loginId, password }) {
    this.ensureDir();
    if (!this.secret) this.log?.warn(`${this.channel}: STATE_SECRET 이 없어 자격증명을 평문으로 저장한다 — .env 에 STATE_SECRET 을 넣을 것`);
    fs.writeFileSync(this.credsFile, sealJson({ loginId, password, savedAt: new Date().toISOString() }, this.secret), { mode: 0o600 });
  }
  loadCreds() {
    if (!fs.existsSync(this.credsFile)) return null;
    return openJson(fs.readFileSync(this.credsFile, 'utf8'), this.secret);
  }
  hasProfile() {
    return fs.existsSync(this.profileDir) && fs.readdirSync(this.profileDir).length > 0;
  }
  /** 자격증명 파일이 주어진 시각 이후에 다시 써졌는가 — 사장님이 페어링을 다시 했다는 뜻이다. */
  credsChangedAfter(ms) {
    try { return fs.statSync(this.credsFile).mtimeMs > ms; } catch { return false; }
  }

  // ── 브라우저 ───────────────────────────────────────────────
  async open({ headless = this.headless } = {}) {
    /* ★ 브라우저가 죽거나 사장님이 창을 닫으면 context 는 남아 있고 page 는 닫힌 상태다.
         그대로 돌려주면 다음 작업이 전부 "Target closed" 로 실패한다 — 치우고 새로 연다. */
    if (this.context && this.page && !this.page.isClosed()) return this.page;
    if (this.context) await this.close();
    this.ensureDir();
    const pw = this.pw || (await import('playwright'));
    const opts = {
      headless,
      viewport: { width: 1360, height: 900 },
      locale: 'ko-KR',
      timezoneId: 'Asia/Seoul',
      slowMo: this.browser.slowMoMs || 0,
      // 탐지 우회 플래그는 쓰지 않는다(D-001) — 보통 브라우저와 같은 동작만 한다
    };
    /* ★ PC 마다 깔려 있는 것이 다르다. Playwright 1.49 부터 headless 는 별도 내려받기인
         'chromium_headless_shell' 을 쓰는데, 회사 PC 에서는 백신이 그 압축 해제를 잡아
         그것만 빠져 있는 일이 흔하다. 반대로 channel 을 지정하면 안 되는 판도 있다.
         그래서 한 가지에 걸지 않고 될 때까지 차례로 해 본다. 마지막 오류는 남겨서 알려 준다. */
    /* ★ 여기서 먼저 막지 않으면, 상주 실행기가 프로필을 쥐고 있을 때 플레이라이트가
         "Target page, context or browser has been closed" 로 죽는다. 그 문구만 보고는
         브라우저가 없는 줄 알고 `npx playwright install` 을 하게 된다(2026-09-11 실제로 그랬다).
         문구를 맞히는 대신 자물쇠를 본다 — 문구는 판·OS 마다 다르다. */
    const busy = heldByOther(this.stateDir);
    if (busy.held) {
      throw new Error(`${this.channel}: 상주 실행기가 돌고 있어 브라우저를 같이 못 쓴다(pid ${busy.pid}).\n` +
        '  먼저:  Stop-ScheduledTask -TaskName "pension-sync-executor"\n' +
        '  끝나면: Start-ScheduledTask -TaskName "pension-sync-executor"');
    }
    const tries = [];
    if (this.browser.executablePath) {
      tries.push(['지정한 실행 파일', { ...opts, executablePath: this.browser.executablePath }]);
    } else if (this.browser.channel) {
      tries.push([`설치된 ${this.browser.channel}`, { ...opts, channel: this.browser.channel }]);
    } else {
      tries.push(['일반 Chromium(channel:chromium)', { ...opts, channel: 'chromium' }]);
      tries.push(['Playwright 기본', { ...opts }]);                    // 헤드리스 셸이 있으면 이쪽이 된다
      tries.push(['설치된 Chrome', { ...opts, channel: 'chrome' }]);   // PC 에 크롬이 있으면
      tries.push(['설치된 Edge', { ...opts, channel: 'msedge' }]);     // 윈도우에는 대개 있다
    }
    let last;
    for (const [what, o] of tries) {
      try {
        this.context = await pw.chromium.launchPersistentContext(this.profileDir, o);
        if (tries.length > 1 && what !== tries[0][0]) this.log.info(`브라우저: ${what} 로 열었다`);
        break;
      } catch (e) {
        if (/ProcessSingleton|already (?:in use|running)|SingletonLock/i.test(e.message)) {
          throw new Error(`${this.channel}: 이 채널의 브라우저 프로필을 이미 다른 곳에서 쓰고 있다 — ` +
            `상주 실행기(npm start)를 끄고 다시 할 것 (${this.profileDir})`);
        }
        last = e;
        this.log.debug(`브라우저: ${what} 실패 — ${e.message.split('\n')[0]}`);
      }
    }
    if (!this.context) {
      throw new Error(`브라우저를 열지 못했다(${tries.length}가지 다 해 봤다). ` +
        `npx playwright install chromium 을 하거나 .env 에 BROWSER_CHANNEL=chrome 을 넣어 볼 것 — ` +
        `${last ? last.message.split('\n')[0] : '이유 불명'}`);
    }
    this.context.setDefaultTimeout(this.browser.timeoutMs || 30000);
    this.page = this.context.pages()[0] || (await this.context.newPage());
    // 프로필이 비어 있고 세션 백업이 있으면(예: 프로필을 지웠을 때) 쿠키·저장소를 되살린다
    if (!this._restored && fs.existsSync(this.storageFile)) {
      this._restored = true;
      /* 못 세면 '없다' 로 본다 — 그러면 아래 복원이 돌아 오히려 안전한 쪽으로 기운다.
         여기서 서 있을 일이 아니다(플레이라이트의 이 호출에는 시간제한 옵션이 없다). */
      const cookies = (await soft(this.context.cookies(), 10000, [])).length;
      if (!cookies) await this.restoreStorage().catch((e) => this.log?.warn(`${this.channel}: 세션 백업 복원 실패 — ${e.message}`));
    }
    return this.page;
  }

  async close() {
    if (!this.context) return;
    /* ★ 손잡이를 **먼저** 놓는다. 닫기가 안 끝나도 다음 open() 이 새로 띄울 수 있어야 한다 —
         브라우저 하나 새는 것이 무인 중단보다 낫다. */
    const ctx = this.context;
    this.context = null;
    this.page = null;
    await soft(ctx.close(), 10000, null);
  }

  /** 지금 브라우저의 쿠키·localStorage 를 파일로(잠가서) 남긴다. 페어링 직후와 작업 끝에 부른다. */
  async saveStorage() {
    if (!this.context) return false;
    if (!this.secret && !this._warnedPlain) {
      this._warnedPlain = true;
      this.log?.warn(`${this.channel}: STATE_SECRET 이 없어 세션 백업(storage.json)도 평문으로 남는다`);
    }
    /* ★ 여기가 2026-09-14 에 실행기를 76분 세운 자리로 지목된 곳이다. 이 호출은
         **한 바퀴의 맨 끝(finally)** 에서 돌고, 플레이라이트에는 시간제한 옵션이 없다.
         세션 백업은 있으면 좋은 것이지, 이 한 바퀴가 걸릴 이유가 아니다. */
    const state = await deadline(this.context.storageState(), 15000, `${this.channel} 세션 백업`);
    fs.writeFileSync(this.storageFile, sealJson(state, this.secret), { mode: 0o600 });
    return true;
  }

  /** storage.json 의 쿠키·localStorage 를 지금 컨텍스트에 넣는다. */
  async restoreStorage() {
    const state = openJson(fs.readFileSync(this.storageFile, 'utf8'), this.secret);
    if (state.cookies && state.cookies.length) await deadline(this.context.addCookies(state.cookies), 10000, '쿠키 복원');
    for (const origin of state.origins || []) {
      if (!origin.localStorage || !origin.localStorage.length) continue;
      const p = await deadline(this.context.newPage(), 15000, '복원용 창 열기');
      try {
        await p.goto(origin.origin, { waitUntil: 'domcontentloaded' });
        await deadline(
          p.evaluate((items) => { for (const { name, value } of items) localStorage.setItem(name, value); }, origin.localStorage),
          10000, 'localStorage 복원');
      } finally { await soft(p.close(), 5000, null); }
    }
    return true;
  }

  /** 프로필·백업·자격증명을 모두 지운다(페어링을 처음부터 다시 할 때). */
  wipe() {
    fs.rmSync(this.dir, { recursive: true, force: true });
  }
}
