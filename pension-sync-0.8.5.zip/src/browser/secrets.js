/* 파트너센터 아이디·비밀번호·세션 백업을 디스크에 둘 때 쓰는 암호화(AES-256-GCM, scrypt).
   STATE_SECRET 이 비어 있으면 평문으로 저장하되 호출자가 경고를 남긴다(BR-010). */
import crypto from 'node:crypto';

const PREFIX = 'v1:';

function keyFrom(secret, salt) {
  // N=2^14·r=8 → 16MB. 기본 maxmem(32MB) 안에서 돈다.
  return crypto.scryptSync(String(secret), salt, 32, { N: 1 << 14, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
}

/** 문자열 → 'v1:<base64(salt|iv|tag|ct)>' */
export function encrypt(plain, secret) {
  if (!secret) throw new Error('암호가 없다');
  const salt = crypto.randomBytes(16);
  const iv = crypto.randomBytes(12);
  const key = keyFrom(secret, salt);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ct = Buffer.concat([cipher.update(String(plain), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return PREFIX + Buffer.concat([salt, iv, tag, ct]).toString('base64');
}

export function isEncrypted(blob) {
  return typeof blob === 'string' && blob.startsWith(PREFIX);
}

/** 'v1:…' → 문자열. 암호가 틀리면 던진다. */
export function decrypt(blob, secret) {
  if (!isEncrypted(blob)) throw new Error('암호화된 형식이 아니다');
  if (!secret) throw new Error('암호가 없다');
  const buf = Buffer.from(blob.slice(PREFIX.length), 'base64');
  const salt = buf.subarray(0, 16), iv = buf.subarray(16, 28), tag = buf.subarray(28, 44), ct = buf.subarray(44);
  const key = keyFrom(secret, salt);
  const d = crypto.createDecipheriv('aes-256-gcm', key, iv);
  d.setAuthTag(tag);
  try {
    return Buffer.concat([d.update(ct), d.final()]).toString('utf8');
  } catch {
    throw new Error('복호화 실패 — STATE_SECRET 이 저장할 때와 다르다');
  }
}

/** JSON 값을 (암호가 있으면) 암호화해 문자열로. */
export function sealJson(value, secret) {
  const text = JSON.stringify(value);
  return secret ? encrypt(text, secret) : text;
}

/** sealJson 의 반대. 평문 JSON 도 받는다. */
export function openJson(text, secret) {
  if (isEncrypted(text)) return JSON.parse(decrypt(text, secret));
  return JSON.parse(text);
}
