/* 단계 러너 — 채널 JSON(config/selectors/<channel>.json) 에 적힌 단계를 Playwright 페이지 위에서 그대로 실행한다.
   파트너센터가 바뀌면 코드가 아니라 JSON 을 고친다(BR-013). 코드는 단계의 뜻만 안다.

   단계(step) 한 개 = 객체 하나. 값 안의 {이름} 은 vars 로 채운다({a.b} 도 된다).
     { "request": { "method": "PUT", "url": "/api/…", "json": { "ids": ["#{roomKey}"] }, "as": "res" } }
                                                     화면을 거치지 않고 API 를 직접 부른다(쿠키가 실린다). 4xx·5xx 면 던진다
     { "goto": "/path?x={y}" }                       주소로 이동(baseUrl 상대). "wait": "load|domcontentloaded|networkidle"
     { "waitFor": "css", "state": "visible|hidden|attached", "timeout": 10000 }
     { "waitForUrl": "**\/reservations**" }          글롭. 정규식은 "re:…" 로 (waitForResponse 도 같다)
     { "click": "css" } / { "fill": "css", "value": "{loginId}" } / { "press": "css", "key": "Enter" }
     { "select": "css", "value": "…" } / { "check": "css", "value": true }
     { "sleep": 500 }
     { "assert": "css", "present": true }            없으면(또는 present:false 인데 있으면) 실패
     { "ifExists": "css", "then": [단계…], "else": [단계…] }
     { "forEach": "dates", "as": "date", "do": [단계…] }   vars.dates 배열을 돌며 vars.date 를 바꿔 가며 실행
     { "capture": "css", "as": "name", "attr": "text|value|href|data-x" }   요소 하나의 값을 vars[name] 에
     { "table": { "row": "css", "cells": { "필드": "css 또는 @data-x" }, "as": "rows", "append": true } }
                                                       행마다 셀 값을 읽어 vars.rows (배열) 에. cells 값이 "@attr" 이면 행의 속성
     { "collect": { "item": "css", "fields": { … }, "as": "name" } }   table 과 같되 이름만 다르다(격자용)
     { "waitForResponse": "url 조각|정규식", "as": "name", "during": [단계…] }  during 을 실행하는 동안 맞는 응답의 JSON 을 vars[name] 에
     { "sniff": { "urls": ["/reservation?…", "/reservations"], "match": "re:/api/", "candidates": { "checkIn": ["checkInDate", …], … },
                  "require": ["reservationNo", "checkIn", "checkOut"], "as": "rows" } }
                                                       **주소를 몰라도** 잡는다. urls 를 차례로 열어 그동안 온 JSON 을 전부 보고,
                                                       "예약 목록처럼 생긴 배열"(예약번호 + 날짜 둘)을 골라 candidates 로 칸을 붙인다.
                                                       못 고르면 던진다(optional:true 면 빈 목록). 고른 주소·칸 이름만 로그에 남고 값은 안 남는다
       sniff 의 선택 절 — **우리 창으로 물었다는 증거**를 만들고 요구한다(BR-019, ask.js 머리말 참조):
         "query": { "searchType": "CHECK_IN", "startDate": "{from}", "endDate": "{toInclusive}" }
                                                       urls 와 메뉴에서 찾은 **화면 주소마다** 이 질의를 붙여 연다.
                                                       주소에 그 이름이 이미 다 있으면 건드리지 않는다
         "ask": [ { "url": "/api/…/reservations", "method": "GET", "query": {…}, "listAt": ["body"],
                    "page": { "param": "page", "start": 1, "max": 20, "sizeParam": "size", "size": 200,
                              "totalAt": ["body.paging.totalCount"] },
                    "probe": { "offsetDays": -60, "days": 30 } } ]
                                                       화면을 연 뒤 **우리가 조립한 요청**을 같은 창의 쿠키·머리로 보낸다.
                                                       그 응답은 '우리가 물은 것' 이므로 증거가 된다. 4xx·5xx 면 던지지 않고 다음 길로 간다.
                                                       한 창에 **한 번만** 보낸다(후보 화면마다 되풀이하지 않는다, D-001).
                                                       page 가 있으면 장을 넘긴다 — 총건수(totalAt)를 찾으면 그것과 대조하고,
                                                       못 찾으면 **다음 장을 실제로 물어** 빈 장이 올 때까지 간다(서버가 우리 size 를
                                                       무시하고 자기 기본 장 크기를 줄 수 있다). 같은 장이 또 오는데 첫 장이 꽉 찼거나
                                                       총건수가 모자라면 **던진다**(잘린 목록 금지). 상한(max)까지 가도 모자라면 던진다.
                                                       probe 가 있으면 **일부러 다른 창**으로 한 번 더 물어 본다 — 같은 목록이 오면 던지고,
                                                       다른 목록이 오면 "서버가 우리 날짜를 본다" 는 확인이 된다(한 바퀴에 한 번만 묻는다)
         "proof": { "emptyAt": ["body", "body.contents"], "why": "…" }
                                                       proof 가 있으면 **증거가 있는 응답에서만** 목록을 고른다. 증거가 없으면
                                                       그 목록은 채택하되 proven:false 로 표시해 어댑터가 던진다.
                                                       '증명된 0건'(0건을 성공으로 넘기는 유일한 문)은 조건이 셋 다 맞을 때만이다 —
                                                       ① 우리가 보낸 ask 의 응답이고 ② emptyAt 자리 중 줄이 든 곳이 하나도 없고
                                                       ③ 서버가 우리 날짜를 본다는 확인(응답의 되읊음 또는 probe)이 있다.
                                                       ③ 이 없으면 "질의 이름이 틀려 서버가 기본 거르개로 답한 200 + 빈 목록" 과
                                                       구분되지 않는다 — 그 판을 성공으로 넘기면 그 밤이 다시 팔린다
     { "fromJson": { "source": "api", "list": "data.list", "fields": { "reservationNo": "orderNumber", "checkIn": "stay.checkIn" }, "as": "rows", "append": true } }
     { "fromJson": { "source": "api", "list": "body", "flatten": ["rooms", "products"], "fields": { … } } }   겹겹이 든 배열을 펴며 바깥 값을 물려준다
                                                       waitForResponse 로 받은 JSON(vars.api) 의 배열을 골라 필드를 점 경로로 뽑는다. list 가 "" 면 응답 자체가 배열
     { "set": { "이름": "값" } }                      vars 에 값을 넣는다(값도 {치환} 된다)
     { "log": "…" }
   실패하면 화면·HTML 을 artifactsDir/<channel>/ 에 남기고 어느 단계에서 죽었는지 붙여 다시 던진다. */
import fs from 'node:fs';
import path from 'node:path';
import { scrubSecrets, maskPii } from '../lib/log.js';
import { deadline, soft } from '../lib/deadline.js';

/* 같은 자리에서 되풀이 실패할 때 기록물을 얼마나 자주 남길지. */
export const DUMP_SAME_TAG_MS = 60 * 60000;
/* 채널 폴더에 남겨 둘 기록물 벌수. 넘으면 오래된 것부터 지운다. */
export const DUMP_KEEP = 40;

/**
 * 첫 장의 번호. **`Number(pg.start) || 1` 로 쓰면 안 된다** — 0 은 거짓값이라 1 이 되고,
 * 그러면 0부터 세는 API 에는 늘 **둘째 장**을 묻게 되어 첫 장이 통째로 사라진다.
 * 여기어때 PMS(gps-reservations/orders)가 정확히 그런 API 다(채널 JSON 의 `"start": 0`) —
 * 2026-09-11 실계정 로그에서 그 주소만 매번 0건이던 것이 이것이었다.
 * @param {{start?:number}|null} pg
 * @returns {number}
 */
export function pageStart(pg) {
  return pg && Number.isFinite(Number(pg.start)) ? Number(pg.start) : 1;
}

/**
 * 빈 장이 왔다 — 여기서 끝내도 되는가?
 * 보통은 빈 장이 끝이지만, **서버가 더 있다고 말한 경우에는 아니다.** 그대로 끝으로 치면
 * "잘린 목록은 원장에 넣지 않는다" 방어를 그냥 통과해, 원장에 안 들어간 밤을 대시보드가
 * 빈 것으로 알고 또 판다(BR-019).
 * @returns {boolean} true 면 잘린 것이다(던져야 한다)
 */
export function truncatedOnEmptyPage(total, collectedLen) {
  return Number.isFinite(total) && collectedLen < total;
}

/**
 * 기록물 폴더를 상한 안으로 줄인다. `-step-N.png/.html` 같은 **한 벌**을 이름(확장자 앞)으로 묶어
 * 세고, 오래된 벌부터 지운다. 사람이 보려고 만든 last-scan-*.txt 류(handoff)는 폴더 루트에 있어
 * 여기(채널 폴더)에 없다 — 그래도 혹시 몰라 `-step`/`-`시각 꼴이 아닌 이름은 건드리지 않는다.
 * @param {string} dir 채널 기록물 폴더
 */
export function pruneArtifacts(dir, log, keep = DUMP_KEEP) {
  let names;
  try { names = fs.readdirSync(dir); } catch { return 0; }
  const groups = new Map();
  for (const n of names) {
    if (!/^\d{4}-\d{2}-\d{2}T/.test(n)) continue;          // 우리가 만든 것만 손댄다
    const base = n.replace(/\.(png|html)$/i, '');
    if (base === n) continue;
    if (!groups.has(base)) groups.set(base, []);
    groups.get(base).push(n);
  }
  const old = [...groups.keys()].sort().slice(0, Math.max(0, groups.size - keep));
  let gone = 0;
  for (const base of old) {
    for (const n of groups.get(base)) {
      try { fs.rmSync(path.join(dir, n), { force: true }); gone++; } catch { /* 못 지우면 다음에 */ }
    }
  }
  if (gone) log?.debug(`기록물 ${old.length}벌(${gone}개)을 치웠다 — 최근 ${keep}벌만 남긴다`);
  return old.length;
}
import { addDays } from '../lib/kst.js';
import { pickRows, toRows, whyNothing } from './sniff.js';
import { windowForms, provesWindow, emptyListAt, withQuery, hasQueryKeys, sameRowSet, identityKeys, needMorePages, getAt } from './ask.js';
import { readTables, readEmbeddedJson, tableToRows } from './dom-rows.js';
import { readLinks, readRoutes, readClickables, pickLinks, pickRoutes, pickClickTexts } from './menu.js';

/**
 * 4xx 응답이 "어느 파라미터가 틀렸다" 고 알려 주면 **이름만** 뽑는다.
 * 여기어때는 `{code, message, dataList:[{parameterName, message}]}` 로 답한다(2026-09-09 실측).
 * ★ 이름과 코드만 남기고 `message` 는 안 남긴다 — 거기엔 사람이 넣은 검색어가 섞여 올 수 있다(BR-020).
 *   이게 없으면 400 을 볼 때마다 무엇이 틀렸는지 처음부터 헤맨다.
 * @returns {string} 예: "코드 AUT017 · 문제 파라미터: dateType, startDate" (못 읽으면 '')
 */
export function badParams(text) {
  let j;
  try { j = JSON.parse(text); } catch { return ''; }
  if (!j || typeof j !== 'object') return '';
  const names = [];
  const walk = (n, d = 0) => {
    if (!n || typeof n !== 'object' || d > 4 || names.length >= 8) return;
    if (Array.isArray(n)) { for (const x of n.slice(0, 20)) walk(x, d + 1); return; }
    for (const [k, v] of Object.entries(n)) {
      if (/^(parameterName|paramName|fieldName|field)$/i.test(k) && typeof v === 'string' && v.trim()) {
        if (!names.includes(v)) names.push(v.slice(0, 40));
      } else walk(v, d + 1);
    }
  };
  walk(j);
  const bits = [];
  if (typeof j.code === 'string' || typeof j.code === 'number') bits.push(`코드 ${String(j.code).slice(0, 24)}`);
  if (names.length) bits.push(`문제 파라미터: ${names.join(', ')}`);
  return bits.join(' · ');
}

const MAX_DEPTH = 8;

/* 주워서 다시 쓸 머리. 인증(authorization)과 그 사이트가 직접 만든 머리(x-…, client-…)만 가져온다.
   host·cookie·content-length 처럼 요청마다 달라져야 하는 것은 절대 가져오지 않는다 — 그건 우리가 정한다. */
const LEARN_HEADER = /^(authorization|x-[a-z0-9-]+|client-[a-z0-9-]+|accept-language)$/i;

export function fill(template, vars) {
  if (template == null) return template;
  if (typeof template !== 'string') return template;
  return template.replace(/\{([A-Za-z0-9_.]+)\}/g, (m, key) => {
    const v = key.split('.').reduce((o, k) => (o == null ? undefined : o[k]), vars);
    return v == null ? m : String(v);
  });
}

/** 객체·배열 속까지 치환한다.
    "{x}"  한 값만 있으면 문자열로 만들지 않고 vars 의 원래 값을 그대로 넣는다(배열·숫자·불리언).
    "#{x}" 는 숫자로 바꾼다 — 파트너센터 API 가 객실 id 를 숫자로 받는 자리가 있다. */
export function fillDeep(v, vars) {
  if (Array.isArray(v)) return v.map((x) => fillDeep(x, vars));
  if (v && typeof v === 'object') {
    const out = {};
    for (const [k, val] of Object.entries(v)) out[fill(k, vars)] = fillDeep(val, vars);
    return out;
  }
  if (typeof v !== 'string') return v;
  let m = /^#\{([A-Za-z0-9_.]+)\}$/.exec(v);
  if (m) return Number(fill(`{${m[1]}}`, vars));
  m = /^\{([A-Za-z0-9_.]+)\}$/.exec(v);
  if (m) {
    const raw = m[1].split('.').reduce((o, k) => (o == null ? undefined : o[k]), vars);
    return raw === undefined ? v : raw;
  }
  return fill(v, vars);
}

/* 're:패턴' 이면 정규식, 아니면 null(부분 문자열 비교로 쓴다). URL 경로가 '/' 로 시작하므로 /…/ 표기는 쓰지 않는다. */
function toRegExp(pattern) {
  if (pattern instanceof RegExp) return pattern;
  const s = String(pattern);
  if (s.startsWith('re:')) return new RegExp(s.slice(3));
  return null;
}

/**
 * 화면에서 뜯은 목록(그려진 표·__NEXT_DATA__)을 "우리 창으로 물어서 받은 것" 으로 볼 수 있는가.
 *
 * ★ 우리가 연 주소에는 우리가 붙였으니 **언제나** 우리 날짜가 들어 있다. 그것만 보고 증거라 하면,
 *   주소의 질의를 무시하고 자기 기본 거르개('예약일+오늘')로 표를 그리는 SPA 에서 오늘 1건이
 *   187일치 전부가 된다(2026-09-09 검토에서 실측 — 여기어때 화면이 바로 그 판이다).
 *   그래서 화면이 **자기 API 를 하나라도 불렀으면** 표를 만든 것은 그 요청이므로 증거도 거기서
 *   나와야 하고, 하나도 안 불렀을 때에만 문서 요청(= 우리가 연 주소)이 그 표를 만든 것이 된다.
 * @param {{proven:boolean}[]} pageBodies 화면이 스스로 부른 응답들
 */
export function docProves(pageBodies, openedUrl, forms) {
  if ((pageBodies || []).length) return pageBodies.some((b) => b.proven);
  return provesWindow(openedUrl, forms);
}

export class StepRunner {
  /** @param {object} o { page, baseUrl, log, artifactsDir, channel } */
  constructor(o) {
    this.page = o.page;
    this.baseUrl = (o.baseUrl || '').replace(/\/+$/, '');
    this.log = o.log;
    this.artifactsDir = o.artifactsDir || null;
    this.channel = o.channel || 'channel';
    /* 머리를 주우려면 **화면이 자기 API 를 한 번 불러야** 한다. 저장된 세션으로 바로 들어가면
       홈 화면이 아무것도 안 부르고 끝나는 판이 있다 — 그때 열어 볼 화면들(채널 JSON 의 warmUp). */
    this.warmUpPaths = Array.isArray(o.warmUp) ? o.warmUp : [];
    this.warmedUp = false;
    /* 이번 바퀴에 "그 물음의 거르개가 먹더라" 를 이미 확인했는가(주소별). 창을 둘로 쪼개 물을 때
       같은 확인을 창마다 되풀이할 이유가 없다 — 거르개가 먹는지는 창이 아니라 그 API 의 성질이다.
       어댑터가 예약 조회를 시작할 때마다 비운다(시계에 기대지 않는다, D-001 — 요청을 덜 보낸다). */
    this.probeVerdicts = new Map();
    this.lastAsk = null;
    /* ★ 화면이 자기 API 를 부를 때 붙이는 머리(header)를 주워 둔다.
         쿠키만 실어 보내면 여기어때는 `AUT017-400 부적절한 요청입니다` 로 돌려보낸다(I-025) —
         화면이 붙이는 인증 머리(Authorization·x-… 따위)가 더 있다는 뜻이다. 그것을 추측해서 적는 대신
         **사람이 쓰는 화면이 실제로 보낸 그대로** 가져다 쓴다. 탐지 우회가 아니라, 같은 창에서 같은
         값을 다시 쓰는 것이다(D-001). 값은 로그·기록에 찍지 않는다. */
    this.learned = {};
    if (this.page && this.page.on) {
      this.page.on('request', (req) => {
        try {
          if (!/\/api\//.test(req.url())) return;
          for (const [k, v] of Object.entries(req.headers() || {})) {
            if (LEARN_HEADER.test(k) && v) this.learned[k.toLowerCase()] = v;
          }
        } catch { /* 무시 */ }
      });
    }
  }

  url(u) {
    return /^https?:\/\//.test(u) ? u : this.baseUrl + (u.startsWith('/') ? u : '/' + u);
  }

  /** 파트너센터 API 를 같은 창(쿠키·주운 머리)으로 부른다. 상태 판단은 부르는 쪽이 한다 —
      `request` 단계는 4xx·5xx 를 던지고, `ask` 는 던지지 않고 다음 길로 간다. */
  async apiFetch(url, { method = 'GET', timeout = 30000, data, headers } = {}) {
    const p = this.page;
    const opts = { method, timeout, failOnStatusCode: false };
    if (data !== undefined) opts.data = data;
    /* ★ 화면이 보내는 것과 같은 머리(header)를 붙인다. 쿠키만 실어 보내면 파트너센터가
         "브라우저가 보낸 것이 아니다" 로 보고 400·401 로 돌려보내는 자리가 있다(I-025) —
         Referer·Origin 을 보고 판단하는 서버가 흔하다. 탐지 우회가 아니라 **모자란 것을 채우는 것**이다:
         같은 창에서 사람이 눌렀을 때 브라우저가 자동으로 붙이는 값 그대로다(D-001).
         채널 JSON 에 headers 를 적으면 그쪽이 이긴다. */
    const origin = (() => { try { return new URL(url).origin; } catch { return null; } })();
    const auto = { accept: 'application/json, text/plain, */*' };
    if (origin) {
      auto.origin = origin;
      const now = p.url();
      auto.referer = now && now.startsWith(origin) ? now : origin + '/';
    }
    /* ★ 주운 머리가 하나도 없으면 그대로 보내 봐야 400 이다(AUT017-400). 화면을 한 번 열어
         그 화면이 자기 API 를 부르는 것을 보고 머리를 주운 뒤에 보낸다. 한 번만 한다. */
    if (this.warmUpPaths.length && !Object.keys(this.learned).length) await this.warmUp();
    opts.headers = { ...auto, ...this.learned, ...(headers || {}) };
    const res = await p.context().request.fetch(url, opts);
    const text = await res.text().catch(() => '');
    return { res, text };
  }

  /** 단계 목록을 실행하고 vars 를 돌려준다(같은 객체를 고친다). */
  async run(steps, vars = {}, depth = 0) {
    if (depth > MAX_DEPTH) throw new Error('단계가 너무 깊게 겹쳤다');
    for (let i = 0; i < (steps || []).length; i++) {
      const step = steps[i];
      try {
        await this.one(step, vars, depth);
      } catch (e) {
        const where = `${this.channel} 단계 ${i + 1}/${steps.length} ${JSON.stringify(step).slice(0, 160)}`;
        const saved = await this.dump(`step-${i + 1}`).catch(() => null);
        const err = new Error(`${where} — ${e.message}${saved ? ` (기록: ${saved})` : ''}`);
        err.cause = e;
        err.step = step;
        // 부르는 쪽이 4xx(자격증명·권한)와 5xx·네트워크(잠깐)를 갈라야 해서 상태 코드를 잃지 않는다
        if (e.status) err.status = e.status;
        throw err;
      }
    }
    return vars;
  }

  async one(step, vars, depth) {
    const p = this.page;
    const f = (v) => fill(v, vars);
    if ('log' in step) { this.log?.info(f(step.log)); return; }
    if ('set' in step) { for (const [k, v] of Object.entries(step.set)) vars[k] = f(v); return; }
    if ('sleep' in step) { await p.waitForTimeout(Number(step.sleep)); return; }
    /* 화면을 거치지 않고 파트너센터 API 를 직접 부른다. 브라우저 컨텍스트로 보내므로 쿠키·세션이 그대로 실린다.
       여기어때 방막기가 이 길이다 — PUT /products/close {"productIdList":[…],"saleDateList":[…]}.
       화면을 클릭하는 것보다 정확하고, 여러 날짜를 한 번에 보낼 수 있다. */
    if ('request' in step) {
      const r = step.request;
      const method = String(r.method || 'GET').toUpperCase();
      const url = this.url(f(r.url));
      const { res, text } = await this.apiFetch(url, {
        method,
        timeout: r.timeout || 30000,
        data: r.json !== undefined ? fillDeep(r.json, vars) : undefined,
        headers: r.headers ? fillDeep(r.headers, vars) : null,
      });
      if (!res.ok()) {
        const known = Object.keys(this.learned);
        /* ★ 서버가 짚어 준 파라미터 이름을 **맨 앞에** 붙인다 — 뒤쪽 본문은 부르는 쪽에서 잘려 나간다. */
        const why = badParams(text);
        const err = new Error(`${method} ${url} → ${res.status()}${why ? ` (${why})` : ''}` +
          ` ${scrubSecrets(String(text)).slice(0, 200)}` +
          ` [화면에서 주운 머리: ${known.length ? known.join(',') : '없음 — 화면을 한 번 열어야 주울 수 있다'}]`);
        err.status = res.status();
        throw err;
      }
      if (r.as) { try { vars[r.as] = JSON.parse(text); } catch { vars[r.as] = text; } }
      this.log.debug(`${method} ${url} → ${res.status()}`);
      return;
    }
    if ('goto' in step) { await p.goto(this.url(f(step.goto)), { waitUntil: step.wait || 'domcontentloaded' }); return; }
    if ('waitFor' in step) { await p.waitForSelector(f(step.waitFor), { state: step.state || 'visible', timeout: step.timeout }); return; }
    if ('waitForUrl' in step) { await p.waitForURL(toRegExp(step.waitForUrl) || f(step.waitForUrl), { timeout: step.timeout }); return; }
    if ('click' in step) { await p.click(f(step.click), { timeout: step.timeout }); return; }
    if ('fill' in step) { await p.fill(f(step.fill), String(f(step.value) ?? ''), { timeout: step.timeout }); return; }
    if ('press' in step) { await p.press(f(step.press), step.key || 'Enter'); return; }
    if ('select' in step) { await p.selectOption(f(step.select), String(f(step.value))); return; }
    if ('check' in step) { await p.setChecked(f(step.check), step.value !== false); return; }
    if ('assert' in step) {
      const n = await p.locator(f(step.assert)).count();
      const present = step.present !== false;
      if (present && n === 0) throw new Error(`있어야 할 요소가 없다: ${f(step.assert)}`);
      if (!present && n > 0) throw new Error(`없어야 할 요소가 있다: ${f(step.assert)}`);
      return;
    }
    if ('ifExists' in step) {
      const n = await p.locator(f(step.ifExists)).count();
      await this.run(n > 0 ? step.then : step.else, vars, depth + 1);
      return;
    }
    if ('forEach' in step) {
      const list = vars[step.forEach];
      if (!Array.isArray(list)) throw new Error(`forEach 대상이 배열이 아니다: ${step.forEach}`);
      const name = step.as || 'item';
      for (const item of list) {
        vars[name] = item;
        await this.run(step.do, vars, depth + 1);
      }
      delete vars[name];
      return;
    }
    if ('capture' in step) {
      const loc = p.locator(f(step.capture)).first();
      vars[step.as] = await readValue(loc, step.attr || 'text');
      return;
    }
    if ('table' in step || 'collect' in step) {
      const spec = step.table || step.collect;
      const rowSel = f(spec.row || spec.item);
      const rows = await p.locator(rowSel).all();
      const out = [];
      for (const row of rows) {
        const rec = {};
        for (const [field, sel] of Object.entries(spec.cells || spec.fields || {})) {
          const s = f(sel);
          if (s.startsWith('@')) rec[field] = await row.getAttribute(s.slice(1));
          else if (s === '.') rec[field] = (await row.innerText()).trim();
          else {
            const cell = row.locator(s).first();
            rec[field] = (await cell.count()) ? await readValue(cell, 'text') : null;
          }
        }
        out.push(rec);
      }
      const as = spec.as || 'rows';
      vars[as] = spec.append && Array.isArray(vars[as]) ? vars[as].concat(out) : out;
      return;
    }
    if ('fromJson' in step) {
      const spec = step.fromJson;
      const src = vars[spec.source];
      if (src == null) throw new Error(`fromJson: vars.${spec.source} 가 없다`);
      const list = spec.list ? getPath(src, spec.list) : src;
      if (!Array.isArray(list)) throw new Error(`fromJson: ${spec.source}.${spec.list || ''} 가 배열이 아니다`);
      /* flatten: 안쪽 배열을 차례로 펴면서 바깥 값을 물려준다. 여기어때 판매현황은
         날짜[] → rooms[] → products[] 3단이라 한 겹만으로는 못 읽는다.
         { list:"body", flatten:["rooms","products"] } 이면 날짜·객실·상품 필드를 한 객체에서 함께 본다
         (안쪽이 같은 이름을 가지면 안쪽이 이긴다). 안쪽이 배열이 아니거나 비면 그 가지는 버린다. */
      let ctxs = list;
      for (const inner of spec.flatten || []) {
        const next = [];
        for (const parent of ctxs) {
          const kids = getPath(parent, inner);
          if (!Array.isArray(kids)) continue;
          /* ★ 안쪽 값이 비어 있으면(null·undefined·'') 바깥 값을 덮어쓰지 않는다.
               여기어때 객실 목록이 이 자리에서 이름을 잃었다 — 상품(products[])에 roomName 이
               빈 채로 들어 있어, 객실에 있던 진짜 이름을 지워 버렸다. 그러면 매핑 제안이
               빈 이름으로 나가고, 빈 이름은 아무 객실에나 '부분 일치' 해 버린다. */
          for (const kid of kids) {
            const merged = { ...parent };
            for (const [k, v] of Object.entries(kid)) {
              if (v !== null && v !== undefined && v !== '') merged[k] = v;
              else if (!(k in merged)) merged[k] = v;
            }
            next.push(merged);
          }
        }
        ctxs = next;
      }
      const out = ctxs.map((item) => {
        const rec = {};
        for (const [field, pth] of Object.entries(spec.fields || {})) rec[field] = getPath(item, pth);
        return rec;
      });
      const as = spec.as || 'rows';
      vars[as] = spec.append && Array.isArray(vars[as]) ? vars[as].concat(out) : out;
      return;
    }
    /* 예약 목록처럼 **주소를 모르는** 것을 잡는다. urls 를 차례로 열어 보며 그동안 온 JSON 응답을
       전부 받아 두고, 모양으로 예약 목록을 고른다(sniff.js). 고른 주소·칸 이름은 로그에 남긴다 —
       값(예약자 이름·연락처)은 찍지 않는다. */
    if ('sniff' in step) {
      const s = step.sniff;
      const pat = s.match ? (toRegExp(s.match) || f(s.match)) : null;
      const urls = (s.urls && s.urls.length ? [...s.urls] : [null]);
      let picked = null, bodies = [];
      /* ★ 우리 창(vars.from ~ vars.toInclusive)의 날짜 표기들. proof 절이 있을 때만 쓴다.
           이 표기 중 하나가 요청 주소·몸통(또는 우리가 연 화면 주소)에 들어 있어야 그 응답을
           "우리 창으로 물어서 받은 것" 으로 인정한다(ask.js 머리말). */
      const forms = s.proof ? windowForms(vars.from, vars.toInclusive) : null;
      /* 화면 주소마다 붙일 질의. 그 이름이 이미 다 있는 주소는 건드리지 않는다. */
      const askQuery = s.query ? fillDeep(s.query, vars) : null;
      const queryKeys = askQuery ? Object.keys(askQuery) : [];
      const openUrl = (raw) => {
        const filled = this.url(f(raw));
        return askQuery && !hasQueryKeys(filled, queryKeys) ? withQuery(filled, askQuery) : filled;
      };
      let provenEmptyAt = null;   // '증명된 0건' 의 근거가 된 자리(있으면 0건을 성공으로 인정한다)
      const askTried = new Set();   // 이미 보낸 물음 — 되든 안 되든 한 창에 한 번만 보낸다
      /* ★ 머리 줍기(warmUp)는 **후보 화면을 열기 전에** 끝내 둔다. 예전에는 ask 안의 apiFetch 가
           머리가 없을 때 warmUp 을 부르는 바람에, 애써 연 예약 화면을 warmUp 이 다른 화면으로
           옮겨 버렸다 — 그러면 그 뒤의 폴백(그려진 표·__NEXT_DATA__)이 예약 화면이 아니라
           워밍업 화면을 읽는다(2026-09-09 검토에서 실측). 여기서 미리 하면 apiFetch 는 그냥 지나간다. */
      if ((s.ask || []).length && this.warmUpPaths.length) await this.warmUp();
      /* 큐에 드는 것은 주소(문자열) 아니면 **누를 자리**({click:'예약'}) 다. 여기어때 파트너센터의
         메뉴는 링크가 아니라 버튼이어서, 주소로 못 닿는 화면이 있다. */
      const queue = [...urls];
      let menuTried = false;
      while (queue.length) {
        const target = queue.shift();
        const click = target && typeof target === 'object' ? target.click : null;
        const u = click ? null : target;
        /* 이번에 우리가 연 화면 주소. 화면이 **자기 API 를 하나도 안 불렀을 때에 한해** 문서에서
           뜯은 목록의 증거가 된다(그때는 그 목록을 만든 요청이 곧 이 문서 요청이다 — docProves).
           눌러서 간 화면은 주소를 우리가 정하지 못하므로 증거가 없다(그래서 null). */
        const openedUrl = u ? openUrl(u) : null;
        const got = [];      // 화면이 스스로 부른 응답
        const asked = [];    // 우리가 조립해 보낸 응답(ask)
        const pending = [];
        const onResponse = (res) => {
          const url = res.url();
          /* ★ 주소로만 거르면 안 된다 — 실계정에서 `/api/` 를 기대했다가 정작 예약을 부르는 응답을
               통째로 놓쳤다(I-033). 주소가 안 맞아도 **JSON 으로 온 것은 받아 둔다**. 고르는 일은
               어차피 모양이 한다(D-007) — 여기서 미리 버릴 이유가 없다. */
          const ct = (res.headers()['content-type'] || '').toLowerCase();
          const urlOk = !pat || (pat instanceof RegExp ? pat.test(url) : url.includes(pat));
          if (!urlOk && !ct.includes('json')) return;
          /* ★ 요청도 함께 본다 — 이 응답이 **우리 창으로 물은 것인지**를 판단할 근거는 요청뿐이다.
               머리(header)는 담지 않는다: 토큰이 돌아다니게 만들 이유가 없다. */
          let proven = false;
          try {
            const rq = res.request();
            proven = !!forms && provesWindow([rq.url(), rq.postData()], forms);
          } catch { /* 요청을 못 보면 증거 없음 */ }
          pending.push(res.text().then((t) => { const j = JSON.parse(t); got.push({ url, json: j, proven }); }).catch(() => {}));
        };
        p.on('response', onResponse);
        try {
          let gone = null;
          if (click) await this.clickMenu(click, s.menuFrom);
          else if (u) gone = await p.goto(openedUrl, { waitUntil: s.wait || 'domcontentloaded' });
          /* 없는 화면(404)은 자기 API 를 부르지 않는다 — 거기서 8초씩 기다리면 후보가 여섯이면
             1분을 버린다. 상태만 보고 바로 다음 후보로 넘어간다. */
          if (gone && gone.status() >= 400) {
            this.log?.debug(`${this.channel}: ${u} → ${gone.status()} — 없는 화면이라 기다리지 않는다`);
          } else {
            await this.run(s.during || [], vars, depth + 1);
            await p.waitForLoadState('networkidle', { timeout: s.settleMs ?? 8000 }).catch(() => {});
            await p.waitForTimeout(s.extraMs ?? 800);
          }
        } finally {
          p.off('response', onResponse);
        }
        /* 몸통이 안 닫히는 응답 하나 때문에 이 바퀴가 서면 안 된다 — 늦는 것은 그냥 안 쓴다.
           (플레이라이트의 Response.text() 에는 시간제한 옵션이 아예 없다.) */
        await soft(Promise.all(pending), 10000, null);
        /* ★ 눌러서 간 화면은 주소를 우리가 못 정해 증거를 만들 수 없다. 그렇다고 누르기가 헛일은
             아니다 — **어디로 갔는지**는 알 수 있다. 그 주소를 후보에 얹으면 다음 바퀴에 우리 질의를
             붙여 다시 연다. 여기어때 왼쪽 메뉴는 링크가 아니라 버튼이라, 누르는 것이 유일한 발견
             수단인 화면이 있다(D-007). 이렇게 해야 그 길이 증거를 가진 채 살아난다. */
        if (click) {
          let landed = null;
          try { landed = new URL(p.url()).pathname; } catch { /* 주소를 못 읽으면 그냥 지나간다 */ }
          if (landed && landed !== '/' && !urls.includes(landed)) {
            urls.push(landed);
            queue.push(landed);
            this.log?.info(`${this.channel}: '${click}' 을 눌러 ${landed} 에 닿았다 — 이제 그 주소를 우리 창으로 다시 연다`);
          }
        }
        /* (0) ★ 우리가 조립한 요청(ask). 화면이 무엇을 물었든 상관없이 **우리 창으로** 묻는다.
               같은 창의 쿠키·주운 머리로 보내므로 사람이 화면에서 조회 조건을 바꿔 다시 조회하는 것과
               같은 요청이다(D-001). 안 되면 던지지 않고 아래의 세 갈래로 넘어간다. */
        for (const a of s.ask || []) {
          /* ★ 한 창에 **한 번만** 보낸다 — 됐든 안 됐든. 예전에는 안 통했을 때만 기억해서, 200 인데
               목록을 못 알아본 판이면 후보 화면마다 같은 물음을 다시 보냈다(한 바퀴 14회 실측).
               사람이 화면에서 하는 일의 범위를 넘는다(D-001). */
          if (askTried.has(a)) continue;
          askTried.add(a);
          const r = await this.askOnce(a, s, vars);
          if (!r) continue;
          asked.push({ url: r.url, json: r.json, proven: true });
          /* ★ '증명된 0건' 은 세 가지가 **다** 맞을 때만이다:
               (1) 우리가 보낸 물음의 응답이고, (2) 그 물음이 실제로 쓴 목록 자리가 0줄이고
               (다른 목록 자리에 줄이 들어 있으면 0건이 아니다 — emptyListAt 이 그것을 본다),
               (3) 서버가 우리 날짜를 보고 있다는 것이 확인됐다(응답이 날짜를 되읊거나, 다른 창은
               다른 목록을 준다). (3) 이 없으면 "질의 이름이 틀려 서버가 기본 거르개로 답한 200"
               과 구분되지 않는다 — 그 판을 0건 성공으로 넘기면 그 밤이 다시 팔린다(BR-019). */
          if (s.proof && !provenEmptyAt && r.rows === 0 && r.filterProven) {
            provenEmptyAt = emptyListAt(r.json, (r.listPath ? [r.listPath] : []).concat(s.proof.emptyAt || a.listAt || []));
          }
        }
        bodies = bodies.concat(got, asked);
        /* ★ 고를 때는 **증거가 있는 응답을 먼저** 본다. 화면 기본 거르개('예약일+오늘')로 온
             오늘치 목록이 우리 180일치를 이기지 않게 하는 자리다. */
        const seenNow = asked.concat(got);
        let cand = (forms ? pickRows(seenNow.filter((b) => b.proven), s) : null) || pickRows(seenNow, s);
        /* (2) 화면이 XHR 을 안 부르고 서버가 HTML 에 데이터를 실어 보낸 판 — __NEXT_DATA__ 안을 본다.
               이 목록을 만든 요청은 곧 **이 화면 문서 요청**이므로, 우리가 질의를 붙여 연 그 주소가 증거다. */
        if (!cand) {
          const docProven = !!forms && docProves(got, openedUrl, forms);
          const embedded = (await readEmbeddedJson(p)).map((b) => ({ ...b, proven: docProven }));
          bodies = bodies.concat(embedded);
          cand = pickRows(embedded, s);
          if (cand) this.log?.debug(`${this.channel}: 화면 속 JSON 에서 잡았다`);
        }
        /* (3) 그래도 없으면 **그려진 표를 그대로 뜯는다.** 열은 머리글 글자로 찾는다(클래스 이름은 안 쓴다). */
        if (!cand && s.headers) {
          const docProven = !!forms && docProves(got, openedUrl, forms);
          if (!docProven && forms) {
            this.log?.debug(`${this.channel}: 화면의 표는 우리 창으로 물어서 그려진 것인지 알 수 없어 증거로 치지 않는다`);
          }
          for (const t of await readTables(p)) {
            const built = tableToRows(t, s.headers);
            if (!built) continue;
            const ident = Object.fromEntries(Object.keys(s.candidates || {}).map((k) => [k, [k]]));
            const one = pickRows([{ url: `(화면의 ${t.where})`, json: built.rows, proven: docProven }], { ...s, candidates: ident });
            if (one) {
              cand = one;
              this.log?.info(`${this.channel}: 화면의 표를 뜯어 읽었다 — 머리글 ${t.headers.filter(Boolean).slice(0, 8).join('·')}`);
              break;
            }
          }
        }
        /* ★ 증거가 있는 목록을 잡았으면 거기서 멈춘다. 증거가 없는 목록은 **기억만 해 두고**
             다음 후보를 마저 돌아본다 — 어딘가에 증거 있는 길이 남아 있을 수 있다.
             (끝까지 못 찾으면 proven:false 인 채로 어댑터에 넘어가 거기서 실패한다.) */
        if (cand && (!forms || cand.proven)) {
          picked = cand;
          this.log?.debug(`${this.channel}: 예약 목록을 ${click ? `'${click}' 을 눌러` : u} 잡았다`);
          break;
        }
        if (cand && !picked) picked = cand;
        /* 증명된 0건이면 더 돌 이유가 없다 — 우리 창으로 물었고 정말 비어 있다. */
        if (provenEmptyAt) break;
        /* ★ 후보 주소가 **다** 빗나갔을 때에야 사이트의 메뉴에서 찾아 들어간다. 주소를 더 찍어 넣는 것도
             결국 추측이지만, 왼쪽 메뉴의 '예약 내역' 은 사람이 누르는 바로 그 자리다. 클래스가 아니라
             글자로 찾으므로 배포가 바뀌어도 따라간다(D-007 과 같은 생각).
             지금 화면이 없는 화면(404)이면 메뉴도 없다 — 그때는 첫 화면으로 한 번 돌아가서 본다. */
        if (!queue.length && !menuTried && s.viaLink && s.viaLink.length) {
          menuTried = true;
          for (const t of await this.menuTargets(s)) {
            const key = typeof t === 'object' ? 'click:' + t.click : t;
            if (!urls.includes(key)) { urls.push(key); queue.push(t); }
          }
        }
      }
      /* ★ **증명된 0건** — 우리 창으로 물어서 받은 응답의, 채널 JSON 이 목록 자리라고 한 곳이
           빈 배열이었다. "못 불러서 0건" 과 구분되는 유일한 경우이고, 0건을 성공으로 넘기는 유일한 문이다.
           증거 없는 목록(화면 기본 거르개가 준 오늘치)보다 이쪽이 이긴다. */
      const emptyWins = provenEmptyAt && !(picked && picked.proven);
      /* ★ 이번 물음이 어땠는지를 남긴다 — 어댑터가 이것을 보고 BR-019 를 집행한다.
           값은 하나도 담지 않는다(주소·자리 이름·건수만). */
      this.lastAsk = {
        declared: !!s.proof,
        proven: emptyWins ? true : !!(picked && picked.proven),
        provenEmpty: !!emptyWins,
        emptyAt: provenEmptyAt,
        window: { from: vars.from, toInclusive: vars.toInclusive },
        rows: emptyWins ? 0 : (picked ? picked.rows.length : 0),
      };
      if (emptyWins) {
        this.log?.info(`${this.channel}: 예약 0건 — 우리 창(${vars.from} ~ ${vars.toInclusive})으로 물었고 목록 자리(${provenEmptyAt})가 비어 있었다`);
        this.spareFields = [];
        this.missingFields = [];
        this.pickedFields = {};
        vars[s.as || 'rows'] = [];
        return;
      }
      if (!picked) {
        if (s.optional) { vars[s.as || 'rows'] = []; return; }
        throw new Error(whyNothing(bodies, s));
      }
      const rows = toRows(picked);
      this.log?.info(`${this.channel}: 예약 목록 ${rows.length}건 — ${picked.url.replace(/\?.*$/, '')}` +
        `${picked.path === '(최상위)' ? '' : ' · ' + picked.path} · 칸 ` +
        Object.entries(picked.fields).map(([k, v]) => `${k}=${v}`).join(' '));
      /* ★ 못 붙인 칸을 **이름만** 남긴다. 상태 칸을 못 찾으면 저장이 통째로 막히는데(BR-015),
           그때 "무슨 이름으로 왔는지" 를 모르면 또 한 바퀴를 돌아야 한다. 값은 안 남긴다. */
      const used = new Set(Object.values(picked.fields).map((p2) => String(p2).split('.')[0]));
      const spare = Object.keys(picked.rows[0] || {}).filter((k) => !used.has(k));
      const missing = Object.keys(s.candidates || {}).filter((k) => !picked.fields[k]);
      /* 부르는 쪽(유입)이 실패 문구에 그대로 붙일 수 있게 남겨 둔다 — 로그가 잘려도 오류에는 남는다. */
      this.spareFields = spare.slice(0, 24);
      this.missingFields = missing;
      /* 어느 칸을 무엇으로 붙였는지 — 실패 문구가 "상태 칸=orderStatus.name" 까지 들고 가게 한다.
         이름만 남긴다(값은 안 남긴다). 이게 없으면 상태가 비어 보일 때 어느 칸이 범인인지 모른다. */
      this.pickedFields = { ...picked.fields };
      /* ★ 같은 말을 2분마다 되풀이하지 않는다. 이 경고는 바뀔 때까지 똑같은 내용이라,
           매 판 찍으면 로그의 절반이 이 줄이 되고 정작 중요한 줄이 밀려 올라간다
           (2026-09-14 사장님 로그가 실제로 그랬다). 내용이 달라질 때만 다시 말한다. */
      if (missing.length) {
        const note = `${missing.join(',')}|${spare.slice(0, 20).join(',')}`;
        if (note !== this.lastMissingNote) {
          this.lastMissingNote = note;
          this.log?.warn(`${this.channel}: 못 붙인 칸 ${missing.join(',')} — 응답에 남은 이름: ${spare.slice(0, 20).join(', ') || '없음'}` +
            ' (채널 JSON 의 candidates 에 넣을 것)');
        }
      }
      const as = s.as || 'rows';
      vars[as] = s.append && Array.isArray(vars[as]) ? vars[as].concat(rows) : rows;
      return;
    }
    if ('waitForResponse' in step) {
      const pat = toRegExp(step.waitForResponse) || f(step.waitForResponse);
      const match = (r) => (pat instanceof RegExp ? pat.test(r.url()) : r.url().includes(pat));
      /* 채널 JSON 에 값이 없거나 0 이면 플레이라이트는 **무한 대기**로 읽는다. 기본을 준다. */
      const waiting = p.waitForResponse(match, { timeout: Number(step.timeout) || 30000 });
      /* ★ during 이 던지면 이 프로미스를 아무도 받지 않는다. 그대로 두면 대기 시간이 지난 뒤
           TimeoutError 가 unhandled rejection 으로 올라가 실행기 전체가 죽는다(Node 22 기본 동작).
           여기서 미리 받아 두면 아래 await 는 그대로 던지되 프로세스는 살아 있다. */
      waiting.catch(() => {});
      await this.run(step.during || [], vars, depth + 1);
      const res = await waiting;
      /* 기다리는 데는 시간제한이 있는데 **몸통 읽기**에는 없다 — 헤더만 오고 안 닫히는 응답이 있다. */
      const raw = await deadline(res.text(), 10000, `${this.channel} 응답 몸통`);
      try { vars[step.as] = JSON.parse(raw); } catch { vars[step.as] = raw; }
      return;
    }
    throw new Error(`모르는 단계: ${Object.keys(step).join(',')}`);
  }

  /**
   * ★ 우리가 조립한 요청 하나를 보낸다 — "우리 창으로 물었다" 는 직접 증거를 만드는 자리.
   * 화면이 무엇을 물었든(기본 거르개 = 예약일+오늘) 상관없이 우리 날짜로 다시 묻는다.
   * 못 부르면(4xx·5xx·JSON 아님) **던지지 않고 null** 을 돌려준다 — 다른 길이 아직 남아 있다.
   * 다만 **잘린 목록·안 먹은 거르개**는 던진다. 그것을 원장에 넣으면 그 날이 다시 팔린다(BR-019).
   * @returns {Promise<{url:string, json:any, listPath:string|null, rows:number|null, filterProven:boolean}|null>}
   *   rows = 목록 자리의 줄 수(자리를 못 찾으면 null), filterProven = 서버가 우리 날짜를 보고 있다는 확인
   */
  async askOnce(a, s, vars) {
    const f = (v) => fill(v, vars);
    const method = String(a.method || 'GET').toUpperCase();
    const base = this.url(f(a.url));
    const pg = a.page || null;
    const size = pg && Number.isFinite(Number(pg.size)) ? Number(pg.size) : null;
    const listPaths = a.listAt || (s.proof && s.proof.emptyAt) || [''];
    const short = (u) => u.replace(/^https?:\/\/[^/]+/, '');
    const start = pageStart(pg);
    /* 두 응답이 같은 목록인지 볼 때 쓸 **예약을 가리키는 칸 이름**. 응답 전체를 글자로 견주면
       조회시각·정렬 seq 같은 칸 하나에 판정이 뒤집힌다(2026-09-09 검토). */
    const idNames = (s.candidates && s.candidates.reservationNo) || [];
    const sameList = (x, y) => sameRowSet(x, y, identityKeys((x || []).concat(y || []), idNames));
    /* 한 장을 부른다. 못 부르면 null. */
    const fetchPage = async (queryVars, pageNo) => {
      const q = fillDeep(a.query || {}, queryVars);
      if (pg) {
        q[pg.param || 'page'] = pageNo;
        if (pg.sizeParam && size) q[pg.sizeParam] = size;
      }
      const url = withQuery(base, q);
      const { res, text } = await this.apiFetch(url, {
        method, timeout: a.timeoutMs || 20000,
        data: a.json !== undefined ? fillDeep(a.json, queryVars) : undefined,
      });
      if (!res.ok()) {
        /* ★ 401·403 은 "질의가 틀렸다" 가 아니라 **세션이 풀렸다** 다. 이것까지 '다음 길로' 넘기면
             유입 경로에는 request 단계가 없어서(sniff+ask 뿐) status 를 단 예외가 한 번도 안 생기고,
             그러면 withRelogin 의 재로그인이 **설계상 한 번도 안 돈다.** 게다가 로그는 "채널 JSON 을
             고칠 것" 이라 사람을 반대 방향으로 보낸다. status 를 달아 던져 위에서 되찾게 한다. */
        if (res.status() === 401 || res.status() === 403) {
          const e = new Error(`${short(url)} → ${res.status()} 세션이 풀렸다`);
          e.status = res.status();
          throw e;
        }
        const why = badParams(text);
        this.log?.warn(`${this.channel}: 물음 ${short(url)} → ${res.status()}${why ? ` (${why})` : ''}` +
          ' — 다음 길로 간다 (질의 이름·값을 채널 JSON 에서 고칠 것)');
        return null;
      }
      try { return { url, json: JSON.parse(text) }; } catch {
        this.log?.debug(`${this.channel}: 물음 ${short(url)} → JSON 이 아니다 — 다음 길로 간다`);
        return null;
      }
    };
    const first = await fetchPage(vars, start);
    if (!first) return null;
    /* 목록이 놓이는 자리 — 채널 JSON 이 말해 준 곳 중 실제로 배열인 첫 자리. */
    const listPath = listPaths.find((p2) => Array.isArray(getAt(first.json, p2)));
    if (listPath === undefined) {
      /* 목록 자리를 못 찾으면 **몇 줄이 왔는지도, 몇 장이 남았는지도** 알 수 없다. 장을 넘겨야 하는
         판이면 잘린 목록을 쓰느니 이 길을 버린다. 아니면 응답만 넘기고 판단은 고르기에 맡긴다. */
      if (pg) {
        this.log?.warn(`${this.channel}: 물음 응답에서 목록 자리(${listPaths.join(', ')})를 못 찾아 장을 못 넘긴다 — 이 길은 쓰지 않는다`);
        return null;
      }
      this.log?.info(`${this.channel}: 우리 창(${vars.from} ~ ${vars.toInclusive})으로 물었다 — ${short(first.url)}`);
      return { url: first.url, json: first.json, listPath: null, rows: null, filterProven: false };
    }
    const firstArr = getAt(first.json, listPath);
    let collected = [...firstArr];
    /* ── 장 넘기기. 총건수를 찾으면 그것과 대조하고, 못 찾으면 **다음 장을 실제로 물어본다**. ── */
    const totalOf = (json) => {
      for (const p2 of (pg && pg.totalAt) || []) {
        const raw = getAt(json, p2);
        /* ★ Number(null) 은 0 이다(유한!). 빈 값을 총건수 0 으로 읽으면 "다 받았다" 로 조기 종료한다. */
        if (raw === null || raw === undefined || raw === '') continue;
        const v = Number(raw);
        if (Number.isFinite(v)) return v;
      }
      return null;
    };
    const total = pg ? totalOf(first.json) : null;
    if (pg && total === null) {
      this.log?.warn(`${this.channel}: 물음 응답에서 총건수 칸(${(pg.totalAt || []).join(', ')})을 못 찾았다 — ` +
        '잘림을 총건수로 대조하지 못하고 다음 장을 실제로 물어 확인한다');
    }
    if (pg) {
      const maxPages = Math.max(1, Number(pg.max) || 20);
      let done = !needMorePages(total, collected.length, firstArr.length, size).more;
      for (let i = 1; !done && i < maxPages; i++) {
        const next = await fetchPage(vars, start + i);
        if (!next) return null;
        const arr = getAt(next.json, listPath);
        if (!Array.isArray(arr)) break;
        if (!arr.length) {
          /* ★ 빈 장은 보통 "끝" 이지만, **서버가 더 있다고 말한 경우에는 아니다.**
               그대로 끝으로 치면 아래 705줄의 잘림 방어를 그냥 통과해 **잘린 목록이 원장에 들어간다**.
               원장에 안 들어간 밤을 대시보드는 빈 것으로 알고 그 밤을 또 판다(BR-019). */
          if (truncatedOnEmptyPage(total, collected.length)) {
            throw new Error(`장(${pg.param || 'page'})을 넘기니 빈 장이 왔는데 서버는 더 있다고 한다` +
              ` — 받은 ${collected.length}건 / 서버가 말한 ${total}건 (잘린 목록은 원장에 넣지 않는다)`);
          }
          done = true;
          break;
        }
        if (sameList(arr, firstArr)) {
          /* 같은 장이 또 왔다 = 서버가 장 질의를 안 본다.
             총건수를 알면 남은 것이 있는데 못 가져오는 것이니 던진다.
             총건수를 모를 때는, 첫 장이 우리가 부탁한 size 만큼 꽉 찼으면 **잘렸을 수 있으므로** 던지고,
             덜 찼으면 "장을 나누지 않는 서버가 전부를 준 것" 으로 본다. */
          if (Number.isFinite(total) || (Number.isFinite(size) && size > 0 && firstArr.length >= size)) {
            throw new Error(`장(${pg.param || 'page'})을 넘겨도 같은 목록이 온다 — 남은 예약이 있는지 알 수 없다` +
              ` (받은 ${collected.length}건${Number.isFinite(total) ? ` / 서버가 말한 ${total}건` : ''})`);
          }
          this.log?.debug(`${this.channel}: 장을 넘겨도 같은 목록이다 — 장을 나누지 않는 서버로 보고 ${collected.length}건을 전부로 본다`);
          done = true;
          break;
        }
        collected = collected.concat(arr);
        done = !needMorePages(total, collected.length, arr.length, size).more;
      }
      if (!done) {
        throw new Error(`장을 ${maxPages}장까지 넘겼는데도 다 못 받았다 — 받은 ${collected.length}건` +
          `${Number.isFinite(total) ? ` / 서버가 말한 ${total}건` : ''} (잘린 목록은 원장에 넣지 않는다)`);
      }
    }
    /* ── 서버가 우리 날짜를 실제로 보는가(filterProven) ─────────────────────────────
       이것이 있어야 0건을 성공으로 넘길 수 있다. 근거는 둘 —
       (1) 되읊음: 0줄로 온 응답 안에 우리 창의 두 날짜가 그대로 실려 있다(조회 조건을 돌려주는 API).
           줄이 0개일 때만 본다 — 줄이 있으면 예약의 날짜가 우연히 우리 창 끝과 같을 수 있다.
       (2) 탐침: 일부러 다른 창으로 한 번 더 물어 **다른 목록**이 온다. 같은 목록이면 우리가 받은
           것은 우리 창이 아니다(던진다). 둘 다 비면 아무것도 구분 못 한다 — 그때는 증거가 없다. */
    let filterProven = false;
    if (!collected.length) {
      try { filterProven = provesWindow([JSON.stringify(first.json)], windowForms(vars.from, vars.toInclusive)); } catch { /* 못 읽으면 없는 것으로 */ }
      if (filterProven) this.log?.debug(`${this.channel}: 응답이 우리 창의 날짜를 되읊었다 — 서버가 조회 조건을 보고 있다`);
    }
    if (a.probe) {
      const cached = this.probeVerdicts.get(base);
      if (cached) {
        filterProven = filterProven || cached.ok;
      } else {
        const pFrom = addDays(vars.from, Number(a.probe.offsetDays) || -60);
        const pTo = addDays(pFrom, Math.max(1, Number(a.probe.days) || 30) - 1);
        const other = await fetchPage({ ...vars, from: pFrom, to: addDays(pTo, 1), toInclusive: pTo }, start);
        const arr2 = other ? getAt(other.json, listPath) : null;
        if (Array.isArray(arr2)) {
          const same = sameList(arr2, collected);
          if (collected.length && same) {
            throw new Error(`거르개가 안 먹는다 — ${vars.from}~${vars.toInclusive} 와 ${pFrom}~${pTo} 가 같은 목록을 준다` +
              ` (${arr2.length}건). 이 목록은 우리 창이 아니다`);
          }
          this.probeVerdicts.set(base, { ok: !same });
          if (same) {
            /* ★ 우리 창도 비었고 다른 창도 비었다 — "정말 없다" 와 "질의 이름이 틀려 서버가 기본
                 거르개로 답한다" 를 구분할 수 없다. 예전에는 여기서 경고만 하고 **0건을 성공으로
                 넘겼다**. 그러면 화면에 예약이 버젓이 있어도 콘솔은 초록이고 경보까지 닫힌다.
                 이제는 증거로 치지 않는다(filterProven=false) — 유입은 큰 소리로 실패한다. */
            this.log?.warn(`${this.channel}: 우리 창(${vars.from}~${vars.toInclusive})도 탐침 창(${pFrom}~${pTo})도 0건이라 ` +
              '거르개가 먹는지 확인하지 못했다 — 이 0건은 믿지 않는다. `npm run map` 으로 질의 이름을 볼 것');
          } else {
            filterProven = true;
            this.log?.debug(`${this.channel}: 거르개 효험 확인 — 다른 창(${pFrom}~${pTo})은 다른 목록을 준다`);
          }
        }
      }
    }
    /* 여러 장을 **한 응답처럼** 되돌려 준다 — 뒤의 고르기가 장을 몰라도 되게. */
    const json = pg ? setAt(first.json, listPath, collected) : first.json;
    this.log?.info(`${this.channel}: 우리 창(${vars.from} ~ ${vars.toInclusive})으로 물었다 — ` +
      `${short(base)} · ${collected.length}건${Number.isFinite(total) ? ` / 서버가 말한 ${total}건` : ''}` +
      `${collected.length ? '' : filterProven ? ' (물어서 확인한 0건)' : ' (0건인데 거르개가 먹는지는 확인 못 했다)'}`);
    return { url: first.url, json, listPath, rows: collected.length, filterProven };
  }

  /** 화면을 열어 **그 화면이 부르는 인증 머리**를 줍는다. 이미 주웠거나 한 번 해 봤으면 그냥 지나간다.
      왜 필요한가: 저장된 세션으로 바로 들어가면 홈 화면이 자기 API 를 안 부르고 끝나는 판이 있다.
      그러면 우리 요청에 붙일 머리가 없어 파트너센터가 400 으로 돌려보낸다(I-025). */
  async warmUp() {
    if (!this.warmUpPaths.length) return false;                 // 그 채널이 필요 없다고 한 것이다
    if (this.warmedUp || Object.keys(this.learned).length) return Object.keys(this.learned).length > 0;
    this.warmedUp = true;
    const p = this.page;
    if (!p) return false;
    for (const path of this.warmUpPaths) {
      try {
        await p.goto(this.url(path), { waitUntil: 'domcontentloaded' });
        await p.waitForLoadState('networkidle', { timeout: 10000 }).catch(() => {});
        /* networkidle 이 먼저 끝나도 화면이 조금 늦게 부르는 판이 있다 — 잠깐 더 본다. */
        const until = Date.now() + 5000;
        while (!Object.keys(this.learned).length && Date.now() < until) await p.waitForTimeout(250);
      } catch { /* 그 화면을 못 열면 다음 화면 */ }
      const got = Object.keys(this.learned);
      if (got.length) {
        this.log?.info(`${this.channel}: ${path} 화면에서 인증 머리를 주웠다 — ${got.join(',')}`);
        return true;
      }
    }
    this.log?.warn(`${this.channel}: 화면을 ${this.warmUpPaths.join(', ')} 까지 열어 봤지만 인증 머리를 못 주웠다 — ` +
      `세션이 풀렸을 수 있다(npm run pair -- ${this.channel})`);
    return false;
  }

  /** 첫 화면(menuFrom, 기본 '/')으로 가서 사이트가 스스로 들고 있는 지도를 본다.
      셋을 차례로 본다 — 화면 안의 경로 목록(Next.js) → 링크 → 누를 자리의 글자.
      @returns {(string|{click:string})[]} */
  async menuTargets(s) {
    const p = this.page;
    const words = s.viaLink || [];
    try {
      await p.goto(this.url(s.menuFrom || '/'), { waitUntil: 'domcontentloaded' });
      await p.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => {});
    } catch { /* 첫 화면도 못 열면 아래에서 빈손으로 돌아간다 */ }

    const out = [];
    /* (1) 화면이 들고 있는 경로 목록. 여기 있으면 추측이 아니라 **사이트가 말해 준 주소**다. */
    const re = toRegExp(s.routeMatch || 're:reserv|booking|order') || /reserv|booking|order/i;
    for (const r of pickRoutes(await readRoutes(p), re)) out.push(r);
    if (out.length) this.log?.info(`${this.channel}: 화면의 경로 목록에서 찾았다 — ${out.join(', ')}`);

    /* (2) 링크(a[href]) */
    for (const href of pickLinks(await readLinks(p), words)) if (!out.includes(href)) out.push(href);

    /* (3) 주소가 없는 메뉴 — 사람이 누르는 그 글자를 누른다. */
    for (const text of pickClickTexts(await readClickables(p), words)) out.push({ click: text });

    if (out.length) {
      this.log?.info(`${this.channel}: 메뉴에서 갈 곳 ${out.length}군데 — ` +
        out.map((o) => (typeof o === 'object' ? `'${o.click}' 누르기` : o)).join(', '));
    } else {
      this.log?.warn(`${this.channel}: 메뉴에서 '${words[0] || '예약'}' 을(를) 못 찾았다 — npm run scan -- ${this.channel} --menu 로 메뉴를 볼 것`);
    }
    return out;
  }

  /** 메뉴 글자를 눌러 화면을 옮긴다. 메뉴 자리를 먼저 보고, 없으면 화면 전체에서 그 글자를 찾는다. */
  async clickMenu(text, menuFrom = '/') {
    const p = this.page;
    const esc = String(text).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const exact = new RegExp(`^\\s*${esc}\\s*$`);
    try {
      await p.goto(this.url(menuFrom), { waitUntil: 'domcontentloaded' });
      await p.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => {});
    } catch { /* 첫 화면을 못 열면 아래에서 못 찾고 끝난다 */ }
    /* 메뉴 자리부터 본다 — 표 안에 같은 글자가 있어도 그것을 누르지 않게. */
    const scopes = ['nav', 'aside', 'header', '[class*="gnb" i]', '[class*="lnb" i]', '[class*="menu" i]', '[class*="side" i]', 'body'];
    for (const scope of scopes) {
      const loc = p.locator(scope).getByText(exact).last();
      if (!(await loc.count().catch(() => 0))) continue;
      try {
        await loc.click({ timeout: 5000 });
        this.log?.info(`${this.channel}: 메뉴 '${text}' 을(를) 눌렀다 — ${p.url()}`);
        return true;
      } catch { /* 안 눌리면 다음 자리 */ }
    }
    this.log?.debug(`${this.channel}: 메뉴 '${text}' 을(를) 누르지 못했다`);
    return false;
  }

  /**
   * 실패 현장을 남긴다. 파일 경로(확장자 없이)를 돌려준다.
   *
   * ★ 사람 없이 몇 주 도는 프로그램이라 **두 가지를 반드시 지켜야 한다**(2026-09-11 검토):
   *   1. 개수 상한. 되풀이 실패(로그인 막힘·4xx)에서는 주기마다 한 벌씩 쌓여 하루 수백 벌이 된다.
   *      디스크가 차면 state 저장이 던지고, 그러면 "막아 놓고 막았다는 기억이 없는" 상태가 되어
   *      그 밤을 영영 못 연다. 한 벌 남기는 것은 문제가 아니고 **폭발**이 문제다.
   *   2. 예약자 정보. 여기 찍히는 화면은 예약 목록이라 이름·연락처·금액이 그대로 들어 있다.
   *      같은 폴더에 쓰는 discover 는 maskPii 를 거치는데 이쪽만 안 거치고 있었다.
   *      PNG 는 가릴 방법이 없으므로 **기본으로 안 찍는다**(ARTIFACT_SHOTS=true 일 때만).
   */
  async dump(tag) {
    if (!this.artifactsDir || !this.page) return null;
    const dir = path.join(this.artifactsDir, this.channel);
    fs.mkdirSync(dir, { recursive: true });
    /* 같은 자리에서 계속 실패하는 중이면 한 시간에 한 벌이면 충분하다. */
    const now = Date.now();
    this.dumpedAt = this.dumpedAt || new Map();
    if (now - (this.dumpedAt.get(tag) || 0) < DUMP_SAME_TAG_MS) {
      this.log?.debug(`${this.channel}: 같은 자리(${tag}) 기록물을 방금 남겼다 — 건너뛴다`);
      return null;
    }
    this.dumpedAt.set(tag, now);
    const base = path.join(dir, `${new Date(now).toISOString().replace(/[:.]/g, '-')}-${tag}`);
    if (/^true$/i.test(String(process.env.ARTIFACT_SHOTS || ''))) {
      await soft(this.page.screenshot({ path: base + '.png', fullPage: true }), 15000, null);
    }
    /* 비밀번호(scrubSecrets)에 더해 전화·안심번호·이메일·카드번호(maskPii)까지 지운다. */
    /* 기록물은 고치는 데 쓰는 참고자료다 — 그것 때문에 실행기가 서면 본말이 바뀐다. */
    fs.writeFileSync(base + '.html', maskPii(scrubSecrets(await soft(this.page.content(), 5000, ''))));
    pruneArtifacts(dir, this.log);
    return base;
  }
}

/** 점 경로 자리를 바꾼 **새 객체**를 만든다(원본은 안 건드린다). 장을 여러 번 넘겨 모은 줄을
    "한 응답" 처럼 되돌려 줄 때 쓴다 — 그래야 뒤의 고르기가 장을 몰라도 된다. */
export function setAt(json, pth, value) {
  if (!pth) return value;
  const keys = String(pth).split('.');
  const out = Array.isArray(json) ? [...json] : { ...json };
  let node = out;
  for (let i = 0; i < keys.length - 1; i++) {
    const k = keys[i];
    const child = node[k];
    node[k] = Array.isArray(child) ? [...child] : { ...child };
    node = node[k];
  }
  node[keys[keys.length - 1]] = value;
  return out;
}

/** 'a.b.0.c' 같은 점 경로. 없으면 undefined. */
export function getPath(obj, pth) {
  if (!pth) return obj;
  return String(pth).split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj);
}

async function readValue(loc, attr) {
  if (attr === 'text') return (await loc.innerText()).trim();
  if (attr === 'value') return loc.inputValue();
  if (attr === 'html') return loc.innerHTML();
  return loc.getAttribute(attr);
}
