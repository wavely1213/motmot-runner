/* 채널 JSON(config/selectors/<channel>.json) 을 읽고 모양을 검사한다.
   이 파일이 곧 "파트너센터를 아는 곳" 이다. 코드는 여기 적힌 단계만 실행한다(BR-013).

   필수 절:
     channel, baseUrl, unit("room"|"count"), login{url, loggedIn{request|selector|urlNotContains}}, reservations{steps, maxDays},
     rooms{steps}, availability{read{steps}, close{steps}, open{steps}, states{open,closed,sold}, ymFormat}
   선택: login.auto(단계), login.twoFactor{selector}, rates{set{steps}}, verified(bool), notes(문자열 배열)

   login.loggedIn 은 셋 중 하나로 판단한다. request 가 있으면 그것을 먼저 쓴다(가장 믿을 만하다):
     "loggedIn": { "request": { "url": "/api/…", "method": "GET", "expect": "body" } }
       로그인해야만 되는 API 를 한 번 불러 4xx 면 로그인 안 된 것으로 본다.
       expect(점 경로)를 주면 200 이어도 그 자리가 비면 안 된 것으로 본다.
     selector / urlNotContains — 화면으로 보는 예전 방식. 로그인 화면에도 있는 요소를 고르면 잘못 읽으니 주의. */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const SELECTORS_DIR = path.resolve(HERE, '../../config/selectors');

export function specPath(channel) {
  return path.join(SELECTORS_DIR, `${channel}.json`);
}

export function loadSpec(channelOrPath) {
  const p = channelOrPath.endsWith('.json') ? channelOrPath : specPath(channelOrPath);
  if (!fs.existsSync(p)) throw new Error(`채널 JSON 이 없다: ${p}`);
  const spec = JSON.parse(fs.readFileSync(p, 'utf8'));
  const problems = validateSpec(spec);
  if (problems.length) throw new Error(`채널 JSON 이 잘못됐다(${p}):\n- ${problems.join('\n- ')}`);
  return spec;
}

function isSteps(v) { return Array.isArray(v) && v.every((s) => s && typeof s === 'object'); }

/** 문제 목록을 돌려준다(비면 정상). */
export function validateSpec(spec) {
  const out = [];
  const need = (cond, msg) => { if (!cond) out.push(msg); };
  need(spec && typeof spec === 'object', 'JSON 객체가 아니다');
  if (!spec || typeof spec !== 'object') return out;
  need(typeof spec.channel === 'string' && spec.channel, 'channel 이 없다');
  need(typeof spec.baseUrl === 'string' && /^https?:\/\//.test(spec.baseUrl), 'baseUrl 은 http(s):// 로 시작해야 한다');
  need(['room', 'count'].includes(spec.unit), 'unit 은 "room" 또는 "count"');
  const L = spec.login || {};
  need(typeof L.url === 'string', 'login.url 이 없다');
  need(L.loggedIn && (L.loggedIn.request || L.loggedIn.selector || L.loggedIn.urlNotContains),
    'login.loggedIn 에 request 또는 selector 또는 urlNotContains 가 있어야 한다');
  if (L.loggedIn && L.loggedIn.request != null) {
    need(typeof L.loggedIn.request.url === 'string' && L.loggedIn.request.url, 'login.loggedIn.request.url 이 없다');
  }
  if (L.auto != null) need(isSteps(L.auto), 'login.auto 는 단계 배열');
  const R = spec.reservations || {};
  need(isSteps(R.steps), 'reservations.steps 가 없다');
  need(Number.isInteger(R.maxDays) && R.maxDays > 0, 'reservations.maxDays 는 양의 정수');
  need(isSteps((spec.rooms || {}).steps), 'rooms.steps 가 없다');
  const A = spec.availability || {};
  need(isSteps((A.read || {}).steps), 'availability.read.steps 가 없다');
  need(isSteps((A.close || {}).steps), 'availability.close.steps 가 없다');
  need(isSteps((A.open || {}).steps), 'availability.open.steps 가 없다');
  need(A.states && ['open', 'closed', 'sold'].every((k) => Array.isArray(A.states[k])), 'availability.states 에 open/closed/sold 배열이 있어야 한다');
  need(['YYYY-MM', 'YYYY.MM', 'YYYYMM'].includes(A.ymFormat || 'YYYY-MM'), 'availability.ymFormat 은 YYYY-MM | YYYY.MM | YYYYMM');
  if (spec.rates != null) need(isSteps((spec.rates.set || {}).steps), 'rates.set.steps 는 단계 배열');
  return out;
}

/** 'YYYY-MM-DD' → 채널이 쓰는 월 표기. */
export function ymOf(date, format = 'YYYY-MM') {
  const y = date.slice(0, 4), m = date.slice(5, 7);
  if (format === 'YYYY.MM') return `${y}.${m}`;
  if (format === 'YYYYMM') return `${y}${m}`;
  return `${y}-${m}`;
}

/** 채널의 상태 문구 → 'open'|'closed'|'sold'|'unknown'.
    ★ 긴 낱말부터 본다. 짧은 것부터 보면 '판매중지'(마감)가 '판매중'(판매 중)에 걸려
      막힌 날을 열려 있다고 읽고, 재개 할 일이 아무 일도 안 하고 완료된다. */
export function normalizeState(text, states) {
  const s = String(text || '').trim();
  if (!s) return 'unknown';
  const words = [];
  for (const k of ['sold', 'closed', 'open']) for (const w of states[k] || []) if (w) words.push({ k, w });
  words.sort((a, b) => b.w.length - a.w.length);
  for (const { k, w } of words) if (s.includes(w)) return k;
  return 'unknown';
}
