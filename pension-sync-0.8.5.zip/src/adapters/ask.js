/* 물음(ask) — "우리 창으로 물었다는 증거" 를 만들고 확인한다.

   왜 이 파일이 있나: 여기어때 예약 내역 화면의 기본 거르개는 '예약일 + 일별 + 오늘' 이다.
   그 화면을 그냥 열면 오늘 접수된 건만(대개 0건) 온다. 그 목록을 우리 창(오늘−7 ~ 오늘+180)의
   전부로 오해하면 대시보드는 "예약이 없다" 로 알고 그 날을 계속 판다(BR-019 — 오버부킹).

   그래서 규칙을 한 칸 올린다: **우리 창으로 물었다는 증거가 없는 목록은 예약 목록으로 채택하지 않는다.**
   증거가 되는 것은 이것뿐이다 —
     (1) 우리가 조립해 보낸 요청(ask). 우리가 그 주소를 만들었으니 직접 증거다.
     (2) 화면이 스스로 부른 요청의 주소·몸통에 우리 창의 두 날짜가 실려 있다(주소의 질의를
         자기 API 로 넘기는 화면).
     (3) 화면이 **자기 API 를 하나도 부르지 않은** 경우에 한해, 그려진 표·HTML 에 박혀 온
         JSON 은 그 문서 요청이 만든 것이므로 우리가 질의를 붙여 연 그 주소가 증거가 된다.

   ★ (3) 에 "하나도 부르지 않은" 이라는 단서가 붙은 이유(2026-09-09 검토): 우리가 연 주소에는
     우리가 붙였으니 **언제나** 우리 날짜가 들어 있다. 화면이 그 질의를 읽었는지와는 아무 상관이 없다.
     여기어때 예약 내역 화면은 자기 기본 거르개를 스스로 들고 있는 CSR SPA 라, 주소에 무엇을 적어
     주든 오늘치 표를 그린다. 그 표를 "우리 창으로 물어서 받은 것" 이라 부르면 오늘 1건이 187일치
     전부가 된다 — 막으려던 오버부킹 그대로다. 화면이 자기 API 를 불렀다면 그 표는 그 요청이 만든
     것이므로, 증거는 그 요청에서 찾아야 한다.

   증거가 없으면 0건이 아니라 실패다. 그리고 **0건을 성공으로 넘기려면** 증거 하나가 더 필요하다:
   서버가 우리 날짜를 실제로 보고 있다는 것(응답이 우리 날짜를 되읊거나, 다른 창을 물었을 때
   다른 목록을 준다). 질의 이름이 틀려 서버가 기본 거르개로 답하면 4xx 가 아니라 **200 + 빈 목록**
   이 오는데, 그것을 "물어서 확인한 0건" 이라 부르면 조용한 초록이 오버부킹으로 이어진다.

   여기 있는 것은 전부 순수 함수다 — 브라우저 없이 검사할 수 있어야 하기 때문이다.
   개인정보: 이 파일은 값을 보지 않는다. 날짜 문자열과 칸 이름만 다룬다. */

/** 'YYYY-MM-DD' 하나를 파트너센터가 쓸 법한 표기들로 편다.
    10·13자리 시각 숫자는 일부러 넣지 않는다 — 그건 날짜가 아닌 id 와 구분할 수 없다. */
export function dateForms(ymd) {
  const s = String(ymd || '').trim();
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (!m) return [];
  const [, y, mo, d] = m;
  return [`${y}-${mo}-${d}`, `${y}${mo}${d}`, `${y}.${mo}.${d}`, `${y}/${mo}/${d}`];
}

/** 창 하나(시작일 · 끝일포함)의 표기 묶음. */
export function windowForms(from, toInclusive) {
  return { from: dateForms(from), to: dateForms(toInclusive) };
}

/**
 * 이 글(요청 주소·몸통·화면 주소)에 우리 창이 실려 있는가.
 * 시작일과 끝일이 **둘 다** 어떤 표기로든 들어 있어야 한다 — 한쪽만 맞는 것은 우연일 수 있다.
 * @param {(string|null|undefined)[]|string} texts
 * @param {{from:string[], to:string[]}} forms
 */
export function provesWindow(texts, forms) {
  const all = (Array.isArray(texts) ? texts : [texts]).filter(Boolean).join('   ');
  if (!all) return false;
  if (!forms || !forms.from || !forms.from.length || !forms.to || !forms.to.length) return false;
  return forms.from.some((f) => all.includes(f)) && forms.to.some((t) => all.includes(t));
}

/** 'a.b.c' 점 경로. 없으면 undefined. (sniff.js 의 것을 여기서 다시 쓰는 것은 서로 부르지 않게 하려고.) */
export function getAt(json, path) {
  if (!path) return json;
  return String(path).split('.').reduce((o, k) => (o == null ? undefined : o[k]), json);
}

/**
 * 채널 JSON 이 "목록이 놓이는 자리" 라고 말한 곳들 중 **빈 배열**인 곳을 찾는다.
 * 이것이 '증명된 0건' 의 근거 하나다 — 우리 창으로 물어서 받은 응답의, 목록 자리가 비어 있다.
 *
 * ★ 2026-09-09 검토에서 잡힌 구멍: 자리를 여러 개 적어 두면 **한 자리가 비었다는 이유로**
 *   0건이라고 말할 수 있었다. `{contents:[진짜 2건], list:[]}` 이면 `list` 를 보고 "0건" 이라
 *   했다 — 우리가 받아 든 응답 안에 예약이 실려 있는데도. 그래서 규칙을 뒤집는다:
 *   **적어 둔 자리 중 하나라도 줄이 든 배열이면 0건이 아니다.**
 * @returns {string|null} 빈 배열이었던 점 경로
 */
export function emptyListAt(json, paths) {
  let empty = null;
  for (const p of paths || []) {
    const v = getAt(json, p);
    if (!Array.isArray(v)) continue;
    if (v.length) return null;                        // 줄이 든 자리가 하나라도 있으면 0건이 아니다
    if (empty === null) empty = p || '(최상위)';
  }
  return empty;
}

/**
 * 질의를 붙인 주소를 만든다. 값이 null·undefined 면 그 키를 **안 붙인다**(빈 값으로 붙이는 것과 다르다).
 * 배열은 쉼표로 잇는다. 주소에 이미 있던 질의는 남고, 같은 이름은 우리 값이 이긴다.
 * @param {string} url  절대 또는 '/…' 상대
 * @param {Record<string, any>} query  이미 치환이 끝난 값
 */
export function withQuery(url, query) {
  const q = Object.entries(query || {}).filter(([, v]) => v !== null && v !== undefined);
  if (!q.length) return String(url);
  const [head, hash] = String(url).split('#');
  const [path, search] = head.split('?');
  const sp = new URLSearchParams(search || '');
  for (const [k, v] of q) sp.set(k, Array.isArray(v) ? v.join(',') : String(v));
  return `${path}?${sp.toString()}${hash ? '#' + hash : ''}`;
}

/** 주소에 그 이름의 질의가 이미 다 있는가 — 채널 JSON 이 직접 적어 둔 질의를 우리가 덮어쓰지 않기 위해. */
export function hasQueryKeys(url, keys) {
  const search = String(url).split('#')[0].split('?')[1] || '';
  const sp = new URLSearchParams(search);
  return (keys || []).length > 0 && keys.every((k) => sp.has(k));
}

/** 객체 하나를 **키 순서와 무관하게** 같은 글로 적는다(비교용). 값은 밖으로 안 나간다. */
function canon(v) {
  if (v === null || typeof v !== 'object') return JSON.stringify(v === undefined ? null : v);
  if (Array.isArray(v)) return `[${v.map(canon).join(',')}]`;
  return `{${Object.keys(v).sort().map((k) => JSON.stringify(k) + ':' + canon(v[k])).join(',')}}`;
}

/**
 * 이 줄들에서 **예약을 가리키는 칸 이름**을 찾는다(후보 이름표 중 실제로 채워져 있는 첫 이름).
 * 왜 필요한가: 두 응답이 같은 목록인지 볼 때 응답 전체를 글자로 견주면, 조회시각·정렬 seq 처럼
 * 부를 때마다 바뀌는 칸 하나에 판정이 뒤집힌다. 예약번호가 같으면 같은 목록이다.
 */
export function identityKeys(rows, candidates) {
  const sample = (rows || []).slice(0, 20).filter((r) => r && typeof r === 'object');
  if (!sample.length) return [];
  for (const name of candidates || []) {
    if (sample.some((r) => r[name] !== null && r[name] !== undefined && String(r[name]).trim() !== '')) return [name];
  }
  return [];
}

/**
 * 두 응답이 같은 목록인가 — 거르개가 실제로 먹었는지 보는 데 쓴다.
 * 순서는 무시하고 **키 칸의 집합**만 본다. 창을 바꿔 물었는데 같으면 "날짜를 안 보는 서버" 다.
 * 키 칸을 못 찾으면 줄 전체를 (키 순서와 무관하게) 견준다 — 순서 바뀜에는 안 흔들리지만
 * 휘발성 칸에는 흔들린다. 그래서 identityKeys 로 이름을 먼저 찾아 넘기는 것이 원칙이다.
 */
export function sameRowSet(a, b, keys = ['reservationNo']) {
  const use = (keys || []).length ? keys : null;
  const key = (r) => (use ? use.map((k) => String((r || {})[k] == null ? '' : (r || {})[k])).join(' ') : canon(r));
  const A = new Set((a || []).map(key));
  const B = new Set((b || []).map(key));
  if (A.size !== B.size) return false;
  for (const x of A) if (!B.has(x)) return false;
  return true;
}

/**
 * 한 장(page) 을 더 불러야 하는가.
 * 총건수 칸(totalAt)을 찾았으면 그것과 대조한다.
 *
 * ★ 총건수를 못 찾았을 때가 문제였다. 예전 규칙은 '우리가 부탁한 size 보다 적게 왔으면 끝' 이었는데,
 *   그건 **서버가 우리 size 를 존중할 때만** 참이다. 서버가 size 를 무시하고 자기 기본 20건만 주면
 *   200건 중 20건을 전부라고 믿고 원장에 넣는다 — 나머지 180건의 밤이 원장에서 사라진다(BR-019).
 *   그래서 총건수를 모를 때는 **다음 장을 실제로 물어본다.** 빈 장이 오면 그것이 끝이고,
 *   같은 장이 또 오면 부르는 쪽이 판단한다(askOnce).
 * @returns {{more:boolean, total:number|null}}
 */
export function needMorePages(total, gotSoFar, lastPageRows, size) {
  if (Number.isFinite(total)) return { more: gotSoFar < total, total };
  return { more: lastPageRows > 0, total: null };
}
