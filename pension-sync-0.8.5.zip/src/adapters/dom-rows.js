import { soft } from '../lib/deadline.js';
/* 화면(HTML)에서 표를 그대로 뜯어 온다 — JSON 을 못 잡았을 때의 두 번째·세 번째 길.
   순서는 sniff.js 가 정한다: (1) 화면이 부른 JSON → (2) HTML 에 박혀 온 JSON → (3) 그려진 표.

   표를 읽을 때 **클래스 이름을 쓰지 않는다.** 파트너센터는 배포마다 클래스가 바뀌지만(Emotion 해시),
   사람이 보는 **머리글 글자**('예약번호'·'체크인')는 잘 안 바뀐다. 그래서 열을 머리글 글자로 찾는다.
   찾은 뒤에는 JSON 과 똑같은 검사를 받는다 — 날짜로 안 읽히는 칸은 입실일로 치지 않는다(sniff.js). */

/* 브라우저 안에서 도는 함수. 표처럼 생긴 것을 전부 걷어 온다(머리글 + 줄). 값은 글자만. */
const GRAB_TABLES = `(() => {
  const MAX_ROWS = 300, MAX_COLS = 40, MAX_LEN = 200;
  const txt = (el) => (el ? (el.innerText || el.textContent || '').replace(/\\s+/g, ' ').trim().slice(0, MAX_LEN) : '');
  const out = [];
  const push = (where, headers, rows) => {
    if (!headers.length || !rows.length) return;
    out.push({ where, headers, rows: rows.slice(0, MAX_ROWS) });
  };
  for (const t of document.querySelectorAll('table')) {
    const headRow = t.querySelector('thead tr') || t.querySelector('tr');
    if (!headRow) continue;
    const headers = [...headRow.children].slice(0, MAX_COLS).map(txt);
    const bodyRows = t.querySelector('tbody')
      ? [...t.querySelectorAll('tbody tr')]
      : [...t.querySelectorAll('tr')].filter((r) => r !== headRow);
    push('table', headers, bodyRows.map((r) => [...r.children].slice(0, MAX_COLS).map(txt)).filter((c) => c.some((v) => v)));
  }
  /* 요즘 화면은 <table> 이 아니라 div 에 role 을 붙여 쓴다. 그것도 같이 본다. */
  for (const g of document.querySelectorAll('[role=table], [role=grid], [role=treegrid]')) {
    const rows = [...g.querySelectorAll('[role=row]')];
    if (rows.length < 2) continue;
    const headers = [...rows[0].querySelectorAll('[role=columnheader], [role=cell], [role=gridcell]')].slice(0, MAX_COLS).map(txt);
    const body = rows.slice(1).map((r) => [...r.querySelectorAll('[role=cell], [role=gridcell]')].slice(0, MAX_COLS).map(txt))
      .filter((c) => c.some((v) => v));
    push('role=table', headers, body);
  }
  return out;
})()`;

/** HTML 안에 박혀 온 JSON — Next.js 의 __NEXT_DATA__ 나 <script type="application/json">.
    화면이 XHR 을 안 부르고 서버가 처음부터 데이터를 실어 보내는 판은 이쪽에만 있다. */
const GRAB_EMBEDDED = `(() => {
  const out = [];
  for (const s of document.querySelectorAll('script[type="application/json"], script#__NEXT_DATA__')) {
    const t = (s.textContent || '').trim();
    if (t.length > 8 && t.length < 4000000) out.push({ id: s.id || s.getAttribute('type'), text: t });
  }
  return out;
})()`;

export async function readTables(page) {
  /* 굳은 렌더러에서는 evaluate 가 안 돌아온다(시간제한 옵션이 없다). 못 읽으면 '표 없음' 으로 간다. */
  return soft(page.evaluate(GRAB_TABLES), 10000, []);
}

export async function readEmbeddedJson(page) {
  const raw = await soft(page.evaluate(GRAB_EMBEDDED), 10000, []);
  const out = [];
  for (const r of raw) {
    try { out.push({ url: `(화면 속 ${r.id})`, json: JSON.parse(r.text) }); } catch { /* JSON 이 아니면 버린다 */ }
  }
  return out;
}

/** 머리글 글자 → 열 번호. 긴 낱말부터 본다('예약자' 가 '예약' 에 걸리지 않게). */
export function mapHeaders(headers, candidates) {
  const norm = headers.map((h) => String(h || '').replace(/\s+/g, ''));
  const used = new Set();
  const out = {};
  const pairs = [];
  for (const [logical, words] of Object.entries(candidates || {})) for (const w of words) pairs.push({ logical, w: w.replace(/\s+/g, '') });
  pairs.sort((a, b) => b.w.length - a.w.length);
  for (const { logical, w } of pairs) {
    if (out[logical] !== undefined) continue;
    const i = norm.findIndex((h, idx) => !used.has(idx) && h.includes(w));
    if (i >= 0) { out[logical] = i; used.add(i); }
  }
  return out;
}

/** 걷어 온 표 하나를 {논리이름: 값} 줄로 바꾼다. 머리글에서 못 찾은 이름은 넣지 않는다. */
export function tableToRows(table, candidates) {
  const cols = mapHeaders(table.headers, candidates);
  if (!Object.keys(cols).length) return null;
  const rows = table.rows.map((cells) => {
    const rec = {};
    for (const [logical, i] of Object.entries(cols)) rec[logical] = cells[i] ?? null;
    return rec;
  });
  return { cols, rows };
}
