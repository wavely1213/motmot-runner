/* 지도 만들기 — 화면 하나가 부른 JSON 응답들을 **칸 이름만** 남겨 요약한다.
   왜: 예약 화면 주소를 한 번에 하나씩 맞춰 보는 대신, 파트너센터를 한 바퀴 돌며
   "어느 화면이 어느 API 를 부르고, 그 응답에 어떤 칸이 있는지" 를 한 장으로 받는다.
   그 한 장이면 채널 JSON 의 주소와 필드 이름을 추측 없이 채울 수 있다.

   개인정보: 여기서 나오는 것은 **주소와 칸 이름과 줄 수**뿐이다. 값(예약자 이름·연락처·금액)은
   한 글자도 남기지 않는다 — 그래서 이 출력은 그대로 공유해도 된다. */
import { arraysIn, mapFields } from './sniff.js';

const MAX_FIELDS = 16;
const MAX_LISTS = 6;

/** 주소에서 물음표 뒤와 호스트를 떼고 경로만. 질의는 이름만 남긴다(값에 예약자 이름이 들어갈 수 있다). */
export function shortUrl(url) {
  let path = String(url || '');
  try { const u = new URL(path); path = u.pathname + (u.search ? '?' + [...u.searchParams.keys()].join('&') : ''); }
  catch { path = path.replace(/\?.*$/, ''); }
  return path;
}

/**
 * 응답 하나를 요약한다 — 안에 든 "객체들의 배열" 자리와 그 칸 이름.
 * @returns {{lists:{path:string,count:number,fields:string[]}[], topKeys:string[]}}
 */
export function summarize(json) {
  const lists = [];
  for (const { path, rows } of arraysIn(json)) {
    if (!rows.length) continue;
    /* 같은 배열이 겹쳐 잡히지 않게 앞의 것과 같은 자리는 건너뛴다. */
    if (lists.some((l) => l.path === path)) continue;
    lists.push({ path, count: rows.length, fields: Object.keys(rows[0]).slice(0, MAX_FIELDS) });
    if (lists.length >= MAX_LISTS) break;
  }
  const topKeys = json && typeof json === 'object' && !Array.isArray(json) ? Object.keys(json).slice(0, MAX_FIELDS) : [];
  return { lists, topKeys };
}

/**
 * 이 응답이 예약 목록으로 보이는가 — 채널 JSON 의 후보 이름표로 재 본다.
 * 값이 아니라 **어느 칸이 무엇으로 읽혔는지**만 돌려준다.
 * @returns {{path:string, count:number, fields:Record<string,string>}|null}
 */
export function reservationish(json, candidates, require = ['reservationNo', 'checkIn', 'checkOut']) {
  let best = null;
  for (const { path, rows } of arraysIn(json)) {
    if (!rows.length) continue;
    const { fields, score } = mapFields(rows, candidates || {});
    if (!require.every((k) => fields[k])) continue;
    if (fields.checkIn && fields.checkOut && fields.checkIn === fields.checkOut) continue;
    if (!best || score > best.score || (score === best.score && rows.length > best.count)) {
      best = { path, count: rows.length, fields, score };
    }
  }
  return best;
}
