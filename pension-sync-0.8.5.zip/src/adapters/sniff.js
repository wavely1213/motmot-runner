/* 포착(sniff) — 예약 목록이 **어느 주소로 오는지 몰라도** 잡아낸다.
   파트너센터는 SPA 라 화면을 열면 자기 API 를 여러 개 부른다. 그 응답을 전부 받아 두고,
   "예약 목록처럼 생긴 배열" 을 골라 낸다. 고르는 기준은 값이 아니라 **모양**이다 —
   예약번호처럼 생긴 칸, 날짜로 읽히는 칸 둘(입실·퇴실)이 있어야 예약 목록으로 본다.

   왜 이렇게 하나: 주소·필드 이름을 추측해 JSON 에 박아 넣으면 파트너센터가 화면을 바꿀 때마다
   조용히 0건이 되고, 대시보드는 "예약이 없다" 로 안다(그 날을 계속 판다). 모양으로 고르면
   주소가 바뀌어도 따라간다. 대신 **못 고르면 던진다** — 틀린 목록을 원장에 넣는 것보다 낫다(D-004).

   개인정보: 여기서 다루는 것은 예약자 이름·연락처가 든 응답이다. 로그에는 **칸 이름과 주소만**
   남기고 값은 한 글자도 찍지 않는다. */
import { parseLooseDate } from '../lib/kst.js';
import { normalizeStatus, KNOWN_STATUSES } from '../dashboard/paste.js';

/* runner.js 의 것과 같다. 여기서 다시 쓰는 것은 runner ↔ sniff 를 서로 부르게 하지 않기 위해서다. */
const getPath = (obj, pth) => (pth ? String(pth).split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj) : obj);

const MAX_DEPTH = 7;
const SAMPLE = 20;

/** JSON 안에 있는 "객체들의 배열" 을 전부 찾아 준다. { path, rows } */
export function* arraysIn(node, path = '', depth = 0) {
  if (!node || typeof node !== 'object' || depth > MAX_DEPTH) return;
  if (Array.isArray(node)) {
    if (node.length && node.every((x) => x && typeof x === 'object' && !Array.isArray(x))) {
      yield { path: path || '(최상위)', rows: node };
    }
    // 배열 안에 또 배열이 들어 있는 판(날짜[] → 예약[])도 본다. 앞의 몇 개만 훑으면 충분하다.
    for (let i = 0; i < Math.min(node.length, 3); i++) yield* arraysIn(node[i], `${path}[${i}]`, depth + 1);
    return;
  }
  for (const [k, v] of Object.entries(node)) yield* arraysIn(v, path ? `${path}.${k}` : k, depth + 1);
}

const isFilled = (v) => v !== null && v !== undefined && String(v).trim() !== '';

/** 이 칸이 날짜로 읽히는가 — 표본의 절반 넘게 날짜여야 한다. */
function looksLikeDate(values) {
  const filled = values.filter(isFilled);
  if (!filled.length) return false;
  return filled.filter((v) => parseLooseDate(v)).length >= Math.ceil(filled.length * 0.6);
}

/** 예약번호처럼 생겼는가 — 대부분 채워져 있고, 서로 다르다. */
function looksLikeKey(values) {
  const filled = values.filter(isFilled).map((v) => String(v).trim());
  if (filled.length < Math.ceil(values.length * 0.8)) return false;
  return new Set(filled).size >= Math.ceil(filled.length * 0.8);
}

/** 상태 문구로 쓸 수 있는가 — **우리 말로 옮길 수 있는 글자**여야 한다.
    숫자 코드(0, 12)나 참거짓만 든 칸을 상태로 집으면 '예약확정/예약취소' 로 옮길 방법이 없고,
    그러면 "못 붙인 칸" 목록에도 안 떠서 무엇을 고쳐야 할지 영영 안 보인다(2026-09-09 실측).
    그럴 땐 아예 안 고르고 못 붙인 칸으로 남겨, 응답에 남은 이름을 실패 문구가 들고 오게 한다. */
const statusish = (v) => (v && typeof v === 'object' && !Array.isArray(v)
  ? (v.name ?? v.label ?? v.text ?? v.title ?? v.value ?? v.code ?? '') : v);
function looksLikeStatusText(values) {
  return values.map(statusish).some((v) => typeof v === 'string' && v.trim() !== '' && !/^[\d.\-]+$/.test(v.trim()));
}

/** 상태 칸 **후보가 여럿일 때** 어느 것을 집을지. 글자이기만 하면 되는 위의 검사와 달리,
    여기서는 **우리 말로 옮겨지는가**(예약확정·예약취소·예약대기·이용완료)까지 본다.
    2026-09-11 실측: 여기어때 응답에는 processStatus · processStatusLabel · processStatusCode 가
    나란히 있다. 셋 중 어느 것이 진짜 상태인지를 JSON 에 박아 두면 그건 추측이다 —
    값이 실제로 옮겨지는 쪽을 **돌 때마다 골라** 추측을 없앤다(D-004). */
function looksLikeKnownStatus(values) {
  const filled = values.map(statusish).filter(isFilled);
  if (!filled.length) return false;
  return filled.filter((v) => KNOWN_STATUSES.includes(normalizeStatus(v))).length >= Math.ceil(filled.length * 0.6);
}

const CHECK = { checkIn: looksLikeDate, checkOut: looksLikeDate, reservationNo: looksLikeKey, status: looksLikeStatusText };
/** 통과한 후보가 여럿이면 이쪽을 먼저 본다. 하나도 없으면 CHECK 만 통과한 첫 후보로 물러난다. */
const PREFER = { status: looksLikeKnownStatus };

/**
 * 배열 하나를 후보 이름표에 맞춰 본다.
 * @param {object[]} rows
 * @param {Record<string,string[]>} candidates  { checkIn: ["checkInDate","startDate",…], … }
 * @returns {{fields:Record<string,string>, score:number}}
 */
export function mapFields(rows, candidates) {
  const sample = rows.slice(0, SAMPLE);
  const fields = {};
  for (const [logical, paths] of Object.entries(candidates || {})) {
    const prefer = PREFER[logical];
    let fallback = null;           // CHECK 는 통과했지만 PREFER 는 못 넘은 첫 후보
    for (const p of paths) {
      const values = sample.map((r) => getPath(r, p));
      if (!values.some(isFilled)) continue;
      const check = CHECK[logical];
      if (check && !check(values)) continue;
      if (prefer && !prefer(values)) { if (!fallback) fallback = p; continue; }
      fields[logical] = p;
      break;
    }
    /* ★ 물러나기는 **안 고르는 것보다 낫기 때문**이다. 못 고르면 그 칸은 "못 붙인 칸" 으로 남고,
         무엇이 왔는지는 원문이 아니라 이름만 보인다 — 못 알아본 문구를 고칠 단서가 사라진다. */
    if (!fields[logical] && fallback) fields[logical] = fallback;
  }
  return { fields, score: Object.keys(fields).length };
}

/**
 * 받아 둔 응답들에서 예약 목록을 고른다.
 * @param {{url:string, json:any}[]} bodies
 * @param {object} spec { candidates, require:[…], minRows }
 * @returns {{url:string, path:string, rows:object[], fields:object, score:number}|null}
 */
export function pickRows(bodies, spec) {
  const require = spec.require || [];
  const minRows = spec.minRows ?? 1;
  let best = null;
  for (const b of bodies) {
    for (const { path, rows } of arraysIn(b.json)) {
      if (rows.length < minRows) continue;
      const { fields, score } = mapFields(rows, spec.candidates);
      if (!require.every((k) => fields[k])) continue;
      /* 같은 점수면 줄이 많은 쪽 — 상세 한 건짜리보다 목록이 낫다.
         입실·퇴실이 같은 칸으로 잡힌 것은 대실이 아니라 잘못 고른 것이므로 버린다. */
      if (fields.checkIn && fields.checkOut && fields.checkIn === fields.checkOut) continue;
      /* proven 은 "이 응답이 **우리 창으로 물어서** 온 것인가"(runner 가 미리 찍어 둔다). 고르는 데는
         쓰지 않고 그대로 물려만 준다 — 무엇을 믿을지는 부르는 쪽이 정한다(ask.js 머리말). */
      const cand = { url: b.url, path, rows, fields, score, proven: !!b.proven };
      if (!best || score > best.score || (score === best.score && rows.length > best.rows.length)) best = cand;
    }
  }
  return best;
}

/** 고른 배열을 {필드: 값} 줄로 바꾼다. */
export function toRows(picked) {
  return picked.rows.map((r) => {
    const rec = {};
    for (const [logical, p] of Object.entries(picked.fields)) rec[logical] = getPath(r, p);
    return rec;
  });
}

/** arraysIn 과 같되 **빈 배열도** 내놓는다.
    왜 따로 두나: arraysIn 은 `node.length &&` 로 빈 배열을 통째로 버린다. 고르기에는 그게 맞지만,
    진단에는 정반대다 — 그것 때문에 "그 API 가 안 불렸다" 와 "왔는데 0줄이었다" 가 로그에서 똑같이
    보였고, 2026-09-09 진단이 원인을 반대로 짚었다. arraysIn 을 고치면 pickRows·apimap 이 흔들리므로
    고치지 않고 옆에 둔다. */
export function* listShapes(node, path = '', depth = 0) {
  if (!node || typeof node !== 'object' || depth > MAX_DEPTH) return;
  if (Array.isArray(node)) {
    if (!node.length || node.every((x) => x && typeof x === 'object' && !Array.isArray(x))) {
      yield { path: path || '(최상위)', rows: node };
    }
    for (let i = 0; i < Math.min(node.length, 3); i++) yield* listShapes(node[i], `${path}[${i}]`, depth + 1);
    return;
  }
  for (const [k, v] of Object.entries(node)) yield* listShapes(v, path ? `${path}.${k}` : k, depth + 1);
}

/** 왜 못 골랐는지 — 값은 빼고 **칸 이름만** 보여 준다(이 문구는 로그·경보에 그대로 나간다). */
export function whyNothing(bodies, spec) {
  const seen = [];
  for (const b of bodies) {
    for (const { path, rows } of listShapes(b.json)) {
      const { fields } = rows.length ? mapFields(rows, spec.candidates) : { fields: {} };
      /* ★ 질의는 **이름만** 남긴다 — 검색어 자리에 예약자 이름이 실려 있을 수 있다. 대신 주소(호스트
           포함)와 질의 이름이 있어야 "어느 API 에 무엇으로 물었는지" 를 사후에 알 수 있다. */
      seen.push({ rows: rows.length,
        text: `${queryNamesOnly(b.url)}${path === '(최상위)' ? '' : ' · ' + path}` +
          (rows.length
            ? ` (${rows.length}줄, 칸: ${Object.keys(rows[0]).slice(0, 12).join(',')}` +
              `${Object.keys(fields).length ? ` → 알아본 것: ${Object.keys(fields).join(',')}` : ''})`
            : ' (0줄 — 왔는데 비어 있었다)') +
          (b.proven ? ' ★우리 창으로 물은 것' : '') });
    }
  }
  /* ★ 앞자리는 **칸 이름이 실린 배열**에 준다. 빈 배열도 진단에 필요하지만(안 불린 것과 구분),
       큰 응답에서 빈 자리들이 앞을 다 차지하면 정작 고칠 단서가 잘려 나간다. */
  const ordered = seen.slice().sort((x, y) => (y.rows ? 1 : 0) - (x.rows ? 1 : 0)).map((x) => x.text);
  return ordered.length
    ? `예약 목록으로 볼 만한 배열을 못 찾았다(필요: ${(spec.require || []).join(', ')}). 본 것들 — ${ordered.slice(0, 8).join(' / ')}`
    : '화면에서 JSON 응답이 하나도 안 왔다 — 주소가 맞는지, 로그인이 풀리지 않았는지 볼 것';
}

/** 주소는 그대로 두되 질의는 **이름만** 남긴다(값에 예약자 이름이 들어갈 수 있다). */
function queryNamesOnly(url) {
  const s = String(url || '');
  try {
    const u = new URL(s);
    return u.origin + u.pathname + (u.search ? '?' + [...u.searchParams.keys()].join('&') : '');
  } catch {
    const [path, search] = s.split('?');
    return path + (search ? '?' + [...new URLSearchParams(search).keys()].join('&') : '');
  }
}
