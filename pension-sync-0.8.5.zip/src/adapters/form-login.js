/* 화면으로 로그인하기 — **사람이 하는 그대로** 아이디·비밀번호 칸을 채우고 버튼을 누른다.

   왜 필요한가 (2026-09-11 실계정):
     우리는 로그인 API 를 직접 불러 왔다(`login.auto` 의 request 단계). 그런데 여기어때가
     우리 요청을 HTTP 400 으로 거절한다 — 비밀번호가 틀린 것이 아니라 **요청 모양이 다르다**(I-026).
     빠진 항목이 무엇인지는 응답이 안 알려 준다. 그래서 세션이 만료될 때마다 사람이 붙어야 했고,
     그건 24시간 무인이라는 말과 모순이다.

     화면으로 하면 요청 모양을 **몰라도 된다.** 파트너센터의 자기 자바스크립트가 알아서 만든다.
     봇 회피가 아니다(D-001) — 보통 브라우저가 하는 일 그대로이고, 사람이 `npm run pair` 에서
     하던 동작과 똑같다. 다른 점은 글자를 사람이 아니라 우리가 넣는다는 것뿐이다.

   ★ 칸을 **이름으로 찍어 두지 않는다.** 화면이 바뀌면 그날로 못 쓰게 되고, 이름을 추측해 박는 것은
     D-004 가 막는 바로 그 일이다. 대신 **구조로 찾는다** — 비밀번호 칸은 type=password 하나뿐이고,
     아이디 칸은 그 앞에 있는 눈에 보이는 글자 칸이다. 이 관계는 로그인 화면이면 거의 언제나 같다. */

/** 비밀번호 칸 앞에 있는 **아이디 칸**을 고른다. 앞에 없으면 뒤에서라도 찾는다. */
export function pickIdField(fields, passwordIndex) {
  const usable = (f) => f.visible && ['text', 'email', 'tel', 'search', ''].includes(String(f.type || '').toLowerCase());
  for (let i = passwordIndex - 1; i >= 0; i--) if (usable(fields[i])) return i;
  for (let i = passwordIndex + 1; i < fields.length; i++) if (usable(fields[i])) return i;
  return -1;
}

/** 눈에 보이는 비밀번호 칸 중 **첫 번째**. 없으면 -1(=로그인 화면이 아니다). */
export function pickPasswordField(fields) {
  return fields.findIndex((f) => f.visible && String(f.type || '').toLowerCase() === 'password');
}

/* 페이지 안에서 도는 코드. 입력 칸들의 **모양만** 긁어 온다 — 값은 안 가져온다.
   ★ 문자열로 넘기면 안 된다. `page.evaluate('() => …')` 는 그 글자를 **식**으로 평가해서
     함수 객체를 만들 뿐 부르지 않는다 — undefined 가 돌아온다. 실제로 그렇게 터졌다. */
const readFields = () => [...document.querySelectorAll('input')].map((el, i) => {
  const r = el.getBoundingClientRect();
  return { i, type: el.type, visible: r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden' };
});

/**
 * 로그인 화면을 채워 제출한다.
 * @param {object} o { page, url, creds:{loginId,password}, log, channel, timeoutMs }
 * @returns {Promise<{ok:boolean, why:string}>} ok 는 "제출까지 했다" 는 뜻이다 —
 *          **로그인이 됐는지는 부르는 쪽이 isLoggedIn 으로 확인한다.** 여기서 단정하지 않는다.
 */
export async function loginByForm({ page, url, creds, log, channel, timeoutMs = 15000 }) {
  if (!creds || !creds.loginId || !creds.password) return { ok: false, why: '저장된 아이디·비밀번호가 없다' };
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1200);                      // 화면이 자바스크립트로 그려지는 판

  const fields = (await page.evaluate(readFields).catch(() => null)) || [];
  const pw = pickPasswordField(fields);
  if (pw < 0) return { ok: false, why: '이 화면에 비밀번호 칸이 없다(로그인 화면이 아닐 수 있다)' };
  const id = pickIdField(fields, pw);
  if (id < 0) return { ok: false, why: '아이디 칸을 못 찾았다' };

  const inputs = page.locator('input');
  await inputs.nth(id).fill(creds.loginId, { timeout: timeoutMs });
  await inputs.nth(pw).fill(creds.password, { timeout: timeoutMs });
  log?.info(`${channel}: 로그인 화면을 채웠다 — 제출한다(칸 ${id}·${pw})`);

  /* 제출은 두 가지로 해 본다. 버튼 글자·클래스를 찍어 두면 화면이 바뀔 때 못 쓴다 —
     Enter 는 어느 로그인 폼에서나 통하고, 안 통할 때만 제출 버튼을 찾는다. */
  await inputs.nth(pw).press('Enter').catch(() => {});
  await page.waitForTimeout(1500);
  if ((await page.locator('input[type=password]:visible').count().catch(() => 0)) > 0) {
    const btn = page.locator('button[type=submit], input[type=submit], form button').first();
    if (await btn.count().catch(() => 0)) {
      await btn.click({ timeout: timeoutMs }).catch(() => {});
      await page.waitForTimeout(1500);
    }
  }
  await page.waitForLoadState('networkidle', { timeout: timeoutMs }).catch(() => {});
  return { ok: true, why: '제출했다' };
}
