/* 메뉴 — 파트너센터가 스스로 알려 주는 자기 지도. 화면에 있는 같은 사이트 링크를 글자와 함께 줍는다.
   왜: 예약 화면 주소를 우리가 추측해 넣으면 배포가 바뀔 때마다 빗나간다(실제로 후보 6개가 전부
   빗나갔다 — I-024). 사람은 그때도 왼쪽 메뉴의 '예약 내역' 을 누른다. 그 자리를 글자로 찾는다.

   개인정보: 여기서 남기는 것은 **메뉴 글자와 주소뿐**이다. 예약자 이름·연락처가 링크 글자에 들어갈
   자리는 아니지만, 찍어 보여 줄 때는 부르는 쪽에서 maskPii 를 한 번 더 통과시킨다. */

/** 브라우저 안에서 도는 함수 — 같은 사이트 링크만 { text, href }. */
export const GRAB_LINKS = () => {
  const out = [];
  const seen = new Set();
  for (const a of document.querySelectorAll('a[href]')) {
    const raw = a.getAttribute('href') || '';
    if (!raw || raw.startsWith('#') || /^(javascript|mailto|tel):/i.test(raw)) continue;
    let href = raw;
    try {
      const u = new URL(raw, location.href);
      if (u.origin !== location.origin) continue;          // 바깥 사이트는 안 따라간다
      href = u.pathname + u.search;
    } catch { continue; }
    const text = (a.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 40);
    const key = text + '|' + href;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ text, href });
    if (out.length >= 300) break;
  }
  return out;
};

/** 화면에서 링크를 줍는다. 실패하면 빈 배열(메뉴가 없다고 해서 죽을 일은 아니다). */
export async function readLinks(page) {
  try { return await page.evaluate(GRAB_LINKS); } catch { return []; }
}

/* ★ 여기어때 파트너센터의 메뉴는 `<a href>` 가 아니었다 — 실계정에서 링크가 딱 하나 잡혔다(1:1문의).
     버튼을 눌러 자바스크립트가 화면을 바꾸는 방식이다. 그래서 길이 둘 더 필요하다:
       (1) Next.js 가 화면 안에 들고 있는 **경로 목록**(빌드 목록) — 사이트의 모든 주소가 여기 있다
       (2) 사람이 누르는 **글자 그대로의 버튼** — 그걸 눌러 어디로 가는지 본다 */

/** 브라우저 안에서 도는 함수 — Next.js 가 들고 있는 경로 목록. 없으면 빈 배열. */
export const GRAB_ROUTES = () => {
  const out = [];
  const push = (p) => { if (typeof p === 'string' && p.startsWith('/') && !out.includes(p)) out.push(p); };
  try { for (const p of (self.__BUILD_MANIFEST && self.__BUILD_MANIFEST.sortedPages) || []) push(p); } catch { /* 없으면 그만 */ }
  try {
    const el = document.getElementById('__NEXT_DATA__');
    const j = el ? JSON.parse(el.textContent) : null;
    if (j && j.page) push(j.page);
  } catch { /* 없으면 그만 */ }
  return out.slice(0, 400);
};

/** 브라우저 안에서 도는 함수 — 눌러 볼 만한 자리의 **글자**. 주소가 없는 메뉴는 이것으로 찾는다. */
export const GRAB_CLICKABLES = () => {
  const out = [];
  const seen = new Set();
  const sel = 'button, [role="button"], [role="menuitem"], [role="tab"], nav li, aside li,' +
    ' [class*="gnb" i] li, [class*="lnb" i] li, [class*="menu" i] li, [class*="side" i] li';
  for (const el of document.querySelectorAll(sel)) {
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) continue;                      // 안 보이는 것은 못 누른다
    const text = (el.textContent || '').replace(/\s+/g, ' ').trim();
    if (!text || text.length > 24) continue;                  // 긴 글자는 메뉴가 아니라 문단이다
    if (seen.has(text)) continue;
    seen.add(text);
    out.push({ text });
    if (out.length >= 200) break;
  }
  return out;
};

/** 지금 **실제로 그려진** 화면의 경로(Next.js). 우리가 부른 주소와 다르면 딴 데로 보내진 것이다. */
export async function readRenderedPage(page) {
  try {
    return await page.evaluate(() => {
      try { return JSON.parse(document.getElementById('__NEXT_DATA__').textContent).page || null; } catch { return null; }
    });
  } catch { return null; }
}

/** 화면의 경로 목록. 실패하면 빈 배열. */
export async function readRoutes(page) {
  try { return await page.evaluate(GRAB_ROUTES); } catch { return []; }
}

/** 눌러 볼 만한 자리의 글자. 실패하면 빈 배열. */
export async function readClickables(page) {
  try { return await page.evaluate(GRAB_CLICKABLES); } catch { return []; }
}

/**
 * 경로 목록에서 예약 화면일 만한 것을 고른다. 값이 든 자리([id] 같은 것)는 그대로 열 수 없으니 뺀다.
 * @param {string[]} routes
 * @param {RegExp} re  예: /reserv|booking/i
 */
export function pickRoutes(routes, re, max = 4) {
  const ok = (routes || []).filter((p) => re.test(p) && !p.includes('[') && !AVOID.test(p));
  /* 짧은 것이 목록 화면이다 — /reservation 이 /reservation/detail/print 보다 먼저다. */
  return ok.sort((a, b) => a.split('/').length - b.split('/').length || a.length - b.length).slice(0, max);
}

const norm = (t) => String(t || '').replace(/\s+/g, '');

/* 눌러서는 안 되는 자리. 로그아웃이 첫째다 — 세션이 날아가면 그 뒤 모든 일이 실패한다. */
const AVOID = /로그아웃|logout|signout|탈퇴|삭제|withdraw/i;

/**
 * 찾는 글자와 맞는 링크를 **글자 순서대로** 고른다. 앞의 말이 더 정확한 말이다.
 * @param {{text:string, href:string}[]} links
 * @param {string[]} words  ['예약 내역', '예약관리', '예약', …]
 * @param {number} max
 * @returns {string[]} 주소들(중복 없이)
 */
export function pickLinks(links, words, max = 4) {
  return rank(links, words, (l) => l.href, max);
}

/** 같은 규칙으로 **누를 자리의 글자**를 고른다(주소가 없는 메뉴용). */
export function pickClickTexts(items, words, max = 3) {
  return rank(items, words, (i) => i.text, max);
}

/** 찾는 말 순서 → 정확히 같은 글자 먼저 → 품은 글자. 로그아웃류는 뺀다. */
function rank(items, words, valueOf, max) {
  const out = [];
  const push = (v) => { if (v && !out.includes(v) && out.length < max) out.push(v); };
  const skip = (i) => AVOID.test(i.text || '') || AVOID.test(i.href || '');
  for (const w of words || []) {
    const nw = norm(w);
    if (!nw) continue;
    /* 정확히 그 글자인 것이 먼저다 — '예약' 으로 찾을 때 '예약' 메뉴가
       '예약 취소 정책 안내' 보다 앞이어야 한다. */
    for (const i of items) if (!skip(i) && norm(i.text) === nw) push(valueOf(i));
    for (const i of items) if (!skip(i) && norm(i.text).includes(nw)) push(valueOf(i));
    if (out.length >= max) break;
  }
  return out;
}
