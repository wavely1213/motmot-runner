#!/usr/bin/env node
/* 탐색 — 로그인된 브라우저로 파트너센터 화면을 돌며 XHR/JSON 응답과 HTML 을 기록한다.
   채널 JSON(config/selectors/<채널>.json)의 '확인 안 됨' 값을 실제 값으로 바꾸는 근거가 된다.
     npm run discover -- yeogi                     JSON 의 discover.urls 를 돈다
     npm run discover -- yeogi /sales/status /reservations   주소를 직접
     npm run discover -- yeogi --headed            창을 보면서
     npm run discover -- yeogi --headed --watch    창을 열어 두고 **사장님이 직접 눌러 볼 동안** 계속 기록
       (방막기처럼 '누를 때만 나가는 요청'은 이 방법으로만 잡힌다 — 다 눌렀으면 터미널에서 Enter)
   결과: artifacts/discover/<채널>/<시각>/  (요약 summary.json, 응답 NNN.json, 화면 NNN.html·png)
   ⚠ 개인정보: 전화·안심번호·이메일·카드번호는 기록할 때 지운다(maskPii). 그러나 **예약자 이름은
     형태로 가릴 수 없어 그대로 남고, 화면 사진(PNG)에는 아무것도 가려지지 않는다.**
     셀렉터를 채운 뒤 폴더를 지울 것. 남에게(AI 포함) 넘길 때는 README 의 안내를 따를 것. */
import fs from 'node:fs';
import readline from 'node:readline';
import path from 'node:path';
import { loadEnvFile, loadConfig } from '../lib/config.js';
import { createLogger, scrubSecrets, redactSecret, maskPii } from '../lib/log.js';
import { ChannelSession } from '../browser/session.js';
import { loadSpec } from '../adapters/spec.js';
import { JsonAdapter } from '../adapters/json-adapter.js';

const MAX_BODY = 300 * 1024;

/** 기록으로 남기기 전에 비밀값과 개인정보를 둘 다 지운다. */
const clean = (t) => maskPii(scrubSecrets(t));

export async function discover(argv = process.argv.slice(2)) {
  loadEnvFile();
  const cfg = loadConfig(process.env, { requireDashboard: false });
  const log = createLogger('탐색', { level: cfg.logLevel });
  const channel = argv.find((a) => !a.startsWith('--') && !a.startsWith('/') && !/^https?:/.test(a));
  if (!channel) { console.log('어느 채널인지 적어 주세요: npm run discover -- yeogi [주소…] [--headed]'); return 2; }
  const spec = loadSpec(channel);
  const urls = argv.filter((a) => a.startsWith('/') || /^https?:/.test(a));
  const targets = urls.length ? urls : (spec.discover && spec.discover.urls) || [spec.login.checkUrl || spec.login.url];
  const headed = argv.includes('--headed') || argv.includes('--watch');
  const watch = argv.includes('--watch');

  const session = new ChannelSession({ channel, stateDir: cfg.paths.stateDir, secret: cfg.stateSecret, headless: !headed, browser: cfg.browser, log });
  const page = await session.open({ headless: !headed });
  const creds = session.loadCreds();
  if (creds) { redactSecret(creds.password); redactSecret(creds.loginId); }
  const adapter = new JsonAdapter({ spec, page, log, artifactsDir: cfg.paths.artifactsDir, creds });
  const outDir = path.join(cfg.paths.artifactsDir, 'discover', channel, new Date().toISOString().replace(/[:.]/g, '-'));
  fs.mkdirSync(outDir, { recursive: true });

  const seen = [];
  let n = 0;
  page.on('response', async (res) => {
    try {
      const ct = res.headers()['content-type'] || '';
      const type = res.request().resourceType();
      if (!/json|xhr|fetch/.test(ct + ' ' + type)) return;
      const body = await res.text().catch(() => '');
      const idx = String(++n).padStart(3, '0');
      const rec = { idx, url: clean(res.url()), status: res.status(), method: res.request().method(), contentType: ct,
        postData: clean(res.request().postData() || '') || null, size: body.length };
      if (rec.method !== 'GET') log.info(`기록: ${rec.method} ${rec.url.replace(/\?.*$/, '')} [${rec.status}]`);
      fs.writeFileSync(path.join(outDir, `${idx}.json`), clean(JSON.stringify({ ...rec, body: body.slice(0, MAX_BODY) }, null, 1)));
      seen.push(rec);
    } catch { /* 무시 */ }
  });

  if (!(await adapter.ensureLoggedIn())) {
    log.error(`${channel}: 로그인이 안 돼 있다 — 먼저 npm run pair -- ${channel}`);
    await session.close();
    return 1;
  }
  const pages = [];
  for (const u of targets) {
    const url = /^https?:/.test(u) ? u : spec.baseUrl + u;
    log.info(`여는 중: ${url}`);
    try {
      await page.goto(url, { waitUntil: 'domcontentloaded' });
      await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});
      await page.waitForTimeout(1500);
      const idx = String(pages.length + 1).padStart(3, '0');
      fs.writeFileSync(path.join(outDir, `page-${idx}.html`), clean(await page.content()));
      await page.screenshot({ path: path.join(outDir, `page-${idx}.png`), fullPage: true }).catch(() => {});
      pages.push({ idx, url, finalUrl: page.url(), title: await page.title() });
    } catch (e) {
      pages.push({ url, error: e.message });
    }
  }
  if (watch) {
    console.log('\n창을 열어 두었습니다. 지금 파트너센터에서 **실제로 눌러 보세요**(예: 안 쓰는 날 하루 방막기 → 다시 열기).');
    console.log('누를 때 나가는 요청을 그대로 기록합니다. 다 하셨으면 여기로 돌아와 Enter 를 누르세요.\n');
    await new Promise((res) => {
      const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
      rl.question('다 눌렀으면 Enter… ', () => { rl.close(); res(); });
    });
    const idx = String(pages.length + 1).padStart(3, '0');
    fs.writeFileSync(path.join(outDir, `page-${idx}.html`), clean(await page.content()));
    pages.push({ idx, url: '(사람이 조작한 뒤)', finalUrl: page.url(), title: await page.title().catch(() => '') });
  }
  const endpoints = [...new Set(seen.map((s) => `${s.method} ${s.url.replace(/\?.*$/, '')}`))];
  fs.writeFileSync(path.join(outDir, 'summary.json'), clean(JSON.stringify({ channel, at: new Date().toISOString(), pages, endpoints, responses: seen }, null, 1)));
  console.log(`\n기록: ${outDir}`);
  console.log(`화면 ${pages.length}개, JSON 응답 ${seen.length}개, 엔드포인트 ${endpoints.length}개:`);
  for (const e of endpoints) console.log('  ' + e);
  console.log('\n이 기록을 보고 config/selectors/' + channel + '.json 의 단계·셀렉터를 채운 뒤 "verified": true 로 바꾸세요.');
  console.log('⚠ 전화·이메일·카드번호는 지웠지만 예약자 이름은 남아 있고, page-*.png 에는 아무것도 가려지지 않았습니다.');
  console.log('  남에게(AI 포함) 보여 줄 때는 summary.json 과 *.json 만, 그것도 훑어본 뒤에 주세요. 다 쓴 폴더는 지우세요.');
  await session.saveStorage().catch(() => {});
  await session.close();
  return 0;
}

if (process.argv[1] && /cli[\\/]discover\.js$/.test(process.argv[1])) {
  discover().then((c) => process.exit(c), (e) => { console.error(scrubSecrets(e.stack || e.message)); process.exit(1); });
}
