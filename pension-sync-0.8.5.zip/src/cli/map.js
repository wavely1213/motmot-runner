#!/usr/bin/env node
/* 지도 — 파트너센터를 한 바퀴 돌며 **어느 화면이 어느 API 를 부르는지** 한 장으로 찍는다.
     npm run map -- yeogi              (야놀자는 yanolja)
     npm run map -- yeogi --headed     창을 보면서
     npm run map -- yeogi --max 40     더 많은 화면을 돈다(기본 25)
     npm run map -- yeogi /a /b        화면을 직접 지정
   읽기만 한다. 누르지 않고, 저장하지 않고, 아무것도 바꾸지 않는다.

   왜 있나: 예약 화면 주소를 한 번에 하나씩 맞춰 보는 대신 사이트가 스스로 들고 있는 경로 목록을
   따라 돌면서 오간 JSON 을 전부 본다. 그러면 채널 JSON(주소·필드 이름)을 추측 없이 채울 수 있다.

   찍는 것: 화면 주소, 그 화면이 부른 API 주소, 응답 속 배열 자리와 **칸 이름**, 줄 수.
            예약 목록으로 보이는 자리는 ★ 로 표시한다.
   안 찍는 것: 값 — 예약자 이름·연락처·금액은 한 글자도 안 나온다. 그래서 그대로 붙여 넣어도 된다. */
import { loadEnvFile, loadConfig } from '../lib/config.js';
import { createLogger, scrubSecrets, redactSecret, maskPii } from '../lib/log.js';
import { ChannelSession } from '../browser/session.js';
import { loadSpec } from '../adapters/spec.js';
import { JsonAdapter } from '../adapters/json-adapter.js';
import { readRoutes, readLinks, readClickables, pickRoutes, readRenderedPage } from '../adapters/menu.js';
import { shortUrl, summarize, reservationish } from '../adapters/apimap.js';
import { handoff, handoffNote } from '../lib/handoff.js';

const quiet = { debug() {}, info() {}, warn() {}, error() {} };

/** 볼 만한 화면을 고른다 — 경로 목록이 있으면 그것, 없으면 링크. 값이 든 자리([id])는 뺀다. */
function screensFrom(routes, links, max) {
  const out = [];
  const push = (p) => { if (p && !out.includes(p) && out.length < max) out.push(p); };
  push('/');
  /* 예약처럼 보이는 것을 앞에 둔다 — 도중에 끊겨도 가장 필요한 것은 봤게 된다. */
  for (const r of pickRoutes(routes, /reserv|booking|order/i, 8)) push(r);
  for (const r of routes) if (!r.includes('[') && !/logout|signout|withdraw/i.test(r)) push(r);
  for (const l of links) if (!/logout|signout|withdraw/i.test(l.href)) push(l.href);
  return out;
}

export async function map(argv = process.argv.slice(2), { out = console.log } = {}) {
  loadEnvFile();
  const cfg = loadConfig(process.env, { requireDashboard: false });
  const channel = argv.find((a) => !a.startsWith('--') && !a.startsWith('/'));
  if (!channel) { out('어느 채널인지 적어 주세요: npm run map -- yeogi'); return 2; }
  const given = argv.filter((a) => a.startsWith('/'));
  const at = argv.indexOf('--max');
  const max = at >= 0 && argv[at + 1] ? Number(argv[at + 1]) : 25;
  const headed = argv.includes('--headed');
  const spec = loadSpec(channel);
  const sniff = (spec.reservations.steps.find((s) => s.sniff) || {}).sniff || {};

  const log = createLogger('지도', { level: cfg.logLevel });
  const session = new ChannelSession({ channel, stateDir: cfg.paths.stateDir, secret: cfg.stateSecret, headless: !headed, browser: cfg.browser, log });
  const page = await session.open({ headless: !headed });
  const creds = session.loadCreds();
  if (creds) { redactSecret(creds.password); redactSecret(creds.loginId); }
  const adapter = new JsonAdapter({ spec, page, log: quiet, artifactsDir: cfg.paths.artifactsDir, creds });

  const lines = [];
  const say = (s) => { lines.push(s); out(s); };
  /* 어디로 빠져나가든 결과는 같은 자리에 둔다(늘 같은 파일 이름 + 클립보드). */
  const finish = (code) => {
    say('');
    say('이 출력에는 값(예약자 이름·연락처·금액)이 들어 있지 않다 — 그대로 붙여 넣어도 된다.');
    for (const line of handoffNote(handoff(`map-${channel}`, lines.join('\n'), { dir: cfg.paths.artifactsDir }))) out(line);
    return code;
  };
  say(`# ${spec.name || channel} 지도 — 읽기만 했고 아무것도 바꾸지 않았다`);
  try {
    if (!(await adapter.ensureLoggedIn())) {
      say(`✗ 로그인이 안 돼 있다 — 먼저: npm run pair -- ${channel}`);
      return finish(1);
    }
    say('✓ 로그인 되어 있다');

    const base = spec.baseUrl.replace(/\/+$/, '');
    const routes = await readRoutes(page);
    const links = await readLinks(page);
    const clicks = await readClickables(page);
    say(`   화면이 들고 있는 경로 ${routes.length}개 · 링크 ${links.length}개 · 누를 자리 ${clicks.length}개`);
    const hitRoutes = routes.filter((r) => /reserv|booking|order|sales|pms/i.test(r));
    if (hitRoutes.length) {
      say(`   그중 예약·판매처럼 보이는 경로 ${hitRoutes.length}개:`);
      for (const r of hitRoutes.slice(0, 40)) say(`     ${r}`);
    }
    /* ★ 계정 화면도 함께 짚는다. 여기어때는 한 계정 동시 로그인이 안 되므로(I-010) **실행기 전용
         계정**을 하나 더 만드는 것이 정공법인데, 그 화면이 어느 주소인지 우리가 모른다.
         메뉴 글자로도, 경로 이름으로도 잡아 둔다 — 사장님이 한 번만 돌리면 자리가 나온다. */
    const acctRe = /account|member|manager|staff|user|employee|operator|admin|myinfo|my-?page|setting|config|권한/i;
    const acctRoutes = routes.filter((r) => acctRe.test(r) && !/logout|signout|withdraw/i.test(r));
    const acctClicks = clicks.filter((c) => /계정|아이디|담당자|직원|사용자|권한|관리자|회원정보|내 정보/.test(c.text || ''));
    if (acctRoutes.length || acctClicks.length) {
      say('   ▣ 계정·담당자처럼 보이는 자리 (실행기 전용 계정을 만들 곳):');
      for (const r of acctRoutes.slice(0, 20)) say(`     경로 ${r}`);
      for (const c of acctClicks.slice(0, 20)) say(`     메뉴 ${maskPii(c.text)}`);
    } else {
      say('   ▣ 계정·담당자처럼 보이는 자리는 경로·메뉴 이름에서 안 보인다 — 숙소 관리 안쪽일 수 있다');
    }
    if (!routes.length && !links.length) {
      say('   ⚠ 경로 목록도 링크도 없다 — 이 화면만 보고 끝난다. 누를 자리 글자:');
      say('     ' + clicks.slice(0, 60).map((c) => maskPii(c.text)).join(' · '));
    }
    const screens = given.length ? given : screensFrom(routes, links, max);
    say(`   ${screens.length}개 화면을 돈다 (--max 로 조절)\n`);

    const found = [];
    for (const path of screens) {
      const seen = new Map();                        // 주소 → { status, method, json }
      const other = [];                              // JSON 이 아닌 것들(무엇이 오갔는지는 알아야 한다)
      const pending = [];
      /* ★ 주소에 '/api/' 가 들어갈 거라고 가정하면 안 된다 — 실계정에서 그 가정 때문에 정작 예약을
           부르는 응답을 통째로 놓쳤다(프리페치 2개만 잡혔다). **JSON 으로 오는 것은 전부** 본다. */
      const onResponse = (res) => {
        const url = res.url();
        const req = res.request();
        const ct = (res.headers()['content-type'] || '').toLowerCase();
        const looksJson = ct.includes('json') || /\.json(\?|$)/.test(url);
        const xhr = ['xhr', 'fetch'].includes(req.resourceType());
        if (!looksJson && !xhr) return;
        pending.push(res.text().then((t) => {
          const key = `${req.method()} ${shortUrl(url)}`;
          if (seen.has(key)) return;
          try { seen.set(key, { status: res.status(), json: JSON.parse(t) }); }
          catch { other.push(`${key} [${res.status()}] ${ct || '형식 모름'} ${t.length}바이트`); }
        }).catch(() => {}));
      };
      page.on('response', onResponse);
      let status = null;
      try {
        const gone = await page.goto(base + path, { waitUntil: 'domcontentloaded' });
        status = gone ? gone.status() : null;
        if (!status || status < 400) {
          await page.waitForLoadState('networkidle', { timeout: 10000 }).catch(() => {});
          /* 화면이 거르개를 세운 **뒤에** 목록을 부르는 판이 있다 — 조금 더 기다린다. */
          await page.waitForTimeout(2500);
        }
      } catch (e) {
        status = `열지 못함(${String(e.message).slice(0, 40)})`;
      } finally {
        page.off('response', onResponse);
      }
      await Promise.all(pending);

      if (status >= 400) { say(`## ${path}   [${status}] — 없는 화면`); continue; }
      /* ★ 200 이라고 해서 그 화면이 그려진 것은 아니다 — 파트너센터가 로그인 화면을 대신 주면서도
           200 을 준다(I-034). Next.js 가 들고 있는 '실제로 그려진 경로' 를 함께 적는다. */
      const drawn = await readRenderedPage(page);
      const moved = drawn && drawn !== path ? `  ← 실제로 그려진 화면: ${drawn}` : '';
      say(`## ${path}   [${status ?? '?'}]   JSON 응답 ${seen.size}개${other.length ? ` (+ JSON 아닌 것 ${other.length}개)` : ''}${moved}`);
      if (drawn && /login|find|signin/i.test(drawn)) {
        say('   ⚠ 로그인 화면으로 보내졌다 — 세션이 풀렸다. npm run pair -- ' + channel + ' 로 다시 로그인할 것');
      }
      for (const [url, { status: st, json }] of seen) {
        const hit = reservationish(json, sniff.candidates, sniff.require);
        const { lists, topKeys } = summarize(json);
        say(`   ${hit ? '★ ' : '  '}${url}  [${st}]${topKeys.length ? '  최상위: ' + topKeys.join(',') : ''}`);
        for (const l of lists) say(`       ${l.path} (${l.count}줄): ${l.fields.join(', ')}`);
        if (hit) {
          say(`       ★ 예약 목록으로 보인다 — ${Object.entries(hit.fields).map(([k, v]) => `${k}=${v}`).join(' ')}`);
          found.push({ path, url, hit });
        }
      }
      for (const o of other.slice(0, 10)) say(`     · ${o}`);
      say('');
    }

    if (found.length) {
      say('## 찾았다 — 채널 JSON 에 이대로 넣으면 된다');
      for (const f of found) say(`   화면 ${f.path} · API ${f.url} · ${f.hit.count}줄 · ${Object.entries(f.hit.fields).map(([k, v]) => `${k}=${v}`).join(' ')}`);
    } else {
      say('## 예약 목록으로 보이는 응답이 없었다');
      say('   → 이 출력을 그대로 붙여 주면 어느 API 가 예약인지 골라 채널 JSON 에 넣는다.');
      say('   → 화면이 눌러야만 목록을 부르는 경우도 있다: npm run discover -- ' + channel + ' --headed --watch');
    }
  } finally {
    await session.saveStorage().catch(() => {});
    await session.close();
  }
  return finish(0);
}

if (process.argv[1] && /cli[\\/]map\.js$/.test(process.argv[1])) {
  map().then((c) => process.exit(c), (e) => { console.error(scrubSecrets(e.stack || e.message)); process.exit(1); });
}
