#!/usr/bin/env node
/* 점검 — 사장님 PC 에서 실행기가 돌 준비가 됐는지 한 번에 본다. 고치는 건 없고 보기만 한다.
     npm run doctor            설정·브라우저·대시보드 로그인·채널 JSON·페어링 상태
     npm run doctor -- --write 생존 신호를 실제로 한 번 써 본다(RLS 확인용, 콘솔에 "실행기 연결됨" 이 뜬다) */
import fs from 'node:fs';
import { loadEnvFile, loadConfig } from '../lib/config.js';
import { createLogger, scrubSecrets } from '../lib/log.js';
import { DashboardClient } from '../dashboard/client.js';
import { loadSpec } from '../adapters/spec.js';
import { ChannelSession } from '../browser/session.js';

const OK = '✓', BAD = '✗', WARN = '△';

/**
 * 생존 신호가 막혔을 때 **어느 자물쇠에 걸렸는지** 문구로 가른다.
 * 포스트그레스에는 자물쇠가 둘이라 안내가 달라진다(I-047):
 *   GRANT       "이 표를 만질 수 있나"  → permission denied for table/relation/sequence
 *   RLS 정책     "어느 줄을 만질 수 있나" → new row violates row-level security policy
 * 둘을 같은 문장으로 안내하면, 74 SQL 을 이미 넣은 사람이 "또 넣으라" 는 말을 듣고 길을 잃는다.
 * @param {string} message
 * @returns {string}
 */
export function heartbeatHint(message = '') {
  const m = String(message);
  if (/permission denied for (table|relation|sequence|schema)/i.test(m)) {
    return '표 권한(GRANT)이 없다 — 정책이 아니라 권한이다. sql/supabase-74-executor.sql 을 (다시) 적용할 것'
      + ' (정책 9개만 들어가 있다면 GRANT 단계가 없던 옛 판이다)';
  }
  if (/row-level security|row level security/i.test(m)) {
    return '권한은 있으나 정책이 막았다 — 이 계정이 admin_users 에 있고 그 숙소 담당자(is_staff_of)인지 볼 것';
  }
  return 'sql/supabase-74-executor.sql 적용 또는 .env 에 MOTMOT_SERVICE_ROLE_KEY';
}

export async function doctor(argv = process.argv.slice(2), { out = console.log } = {}) {
  const rows = [];
  const add = (mark, what, hint = '') => { rows.push({ mark, what, hint }); out(`${mark} ${what}${hint ? `  → ${hint}` : ''}`); };
  const write = argv.includes('--write');

  // 1) Node
  const major = Number(process.versions.node.split('.')[0]);
  add(major >= 22 ? OK : BAD, `Node ${process.versions.node}`, major >= 22 ? '' : 'Node 22 이상을 설치할 것');

  // 2) .env
  const hadEnv = loadEnvFile();
  let cfg = null;
  try {
    cfg = loadConfig();
    add(OK, `.env 읽음${hadEnv ? '' : '(파일 없음 — 환경변수로 대신)'} — 채널 ${cfg.channels.join(', ')}, 쓰기 ${cfg.dashboard.writeMode}`);
    if (!cfg.stateSecret) add(WARN, 'STATE_SECRET 이 비어 있다', '파트너센터 비밀번호가 평문으로 저장된다 — .env 에 긴 문장을 넣을 것');
  } catch (e) {
    add(BAD, `.env: ${e.message}`, 'env.example 을 .env 로 복사해 채울 것');
  }

  // 3) 브라우저
  try {
    const pw = await import('playwright');
    const exe = (cfg && cfg.browser.executablePath) || pw.chromium.executablePath();
    if (cfg && cfg.browser.channel) add(OK, `브라우저: 설치된 ${cfg.browser.channel} 사용`);
    else if (fs.existsSync(exe)) add(OK, `Chromium 있음 (${exe})`);
    else add(BAD, `Chromium 이 없다 (${exe})`, 'npx playwright install chromium');
  } catch (e) {
    add(BAD, `playwright 를 불러오지 못했다: ${e.message}`, 'npm install');
  }

  // 4) 대시보드
  if (cfg) {
    const log = createLogger('점검', { level: 'error' });
    try {
      const dash = await new DashboardClient(cfg.dashboard, { log }).init();
      add(OK, `대시보드 로그인 됨 (${cfg.dashboard.email}) — 숙소 ${cfg.dashboard.propertyId}`);
      try {
        const accounts = await dash.channelAccounts();
        for (const c of cfg.channels) {
          const a = accounts.find((x) => x.channel_code === c);
          if (!a) add(WARN, `${c}: 콘솔 '채널 계정 상태' 에 줄이 없다`, '콘솔 채널 탭 → 계정 상태를 "운영 중(live)" 으로');
          else add(a.status === 'live' ? OK : WARN, `${c}: 계정 상태 ${a.status}`, a.status === 'live' ? '' : 'live 가 아니면 이 채널은 다루지 않는다(BR-008)');
          const map = await dash.roomMap(c);
          add(map.length ? OK : WARN, `${c}: 객실 매핑 ${map.length}건`, map.length ? '' : '콘솔 채널 탭 → 객실 매핑을 넣어야 마감을 옮길 수 있다');
        }
      } catch (e) {
        add(BAD, `대시보드 표 읽기 실패: ${e.message}`, '실행기 계정이 admin_users 에 있고 숙소 담당자인지 확인');
      }
      if (write) {
        try {
          for (const c of cfg.channels) await dash.heartbeat(c);
          add(OK, '생존 신호 쓰기 됨 — 콘솔 채널 탭에 "실행기 연결됨" 이 떠야 한다');
        } catch (e) {
          add(BAD, `생존 신호 쓰기 실패: ${e.message}`, heartbeatHint(e.message));
        }
      } else {
        add(WARN, '생존 신호 쓰기는 시험하지 않았다', 'npm run doctor -- --write 로 한 번 써 볼 수 있다');
      }
    } catch (e) {
      add(BAD, `대시보드 로그인 실패: ${e.message}`, 'MOTMOT_EXECUTOR_EMAIL/PASSWORD 확인, 계정이 관리자 명부에 있어야 한다');
    }
  }

  // 5) 채널 JSON 과 페어링
  if (cfg) {
    for (const c of cfg.channels) {
      let spec;
      try { spec = loadSpec(c); } catch (e) { add(BAD, `${c}: ${e.message}`); continue; }
      add(spec.verified ? OK : WARN, `${c}: 채널 JSON ${spec.verified ? '확인됨' : '아직 초안(verified:false)'}`,
        spec.verified ? '' : `npm run pair -- ${c} → npm run discover -- ${c} 로 기록을 만들어 JSON 을 채울 것`);
      const s = new ChannelSession({ channel: c, stateDir: cfg.paths.stateDir, secret: cfg.stateSecret });
      const paired = s.hasProfile();
      let creds = null;
      try { creds = s.loadCreds(); } catch (e) { add(BAD, `${c}: 자격증명을 열지 못했다 — ${e.message}`, 'STATE_SECRET 이 바뀌었으면 npm run pair -- ' + c + ' --wipe'); }
      add(paired ? OK : BAD, `${c}: 페어링 ${paired ? '됨' : '안 됨'}${creds ? ' + 자격증명 저장됨' : ''}`, paired ? '' : `npm run pair -- ${c}`);
    }
  }

  const bad = rows.filter((r) => r.mark === BAD).length;
  const warn = rows.filter((r) => r.mark === WARN).length;
  out(`\n${bad ? `막힌 것 ${bad}건` : '막힌 것 없음'}${warn ? `, 확인할 것 ${warn}건` : ''}`);
  return bad ? 1 : 0;
}

if (process.argv[1] && /cli[\\/]doctor\.js$/.test(process.argv[1])) {
  doctor().then((c) => process.exit(c), (e) => { console.error(scrubSecrets(e.stack || e.message)); process.exit(1); });
}
