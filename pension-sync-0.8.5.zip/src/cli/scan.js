#!/usr/bin/env node
/* 훑어보기 — 파트너센터를 한 번 열어 **잘 읽히는지만** 확인하고, 그대로 공유해도 되는 결과를 찍는다.
     npm run scan -- yeogi            (야놀자는 yanolja)
     npm run scan -- yeogi --headed   창을 보면서
     npm run scan -- yeogi --menu     파트너센터 메뉴(글자 + 주소)를 늘 함께 찍는다
   아무것도 막지 않고, 아무것도 저장하지 않는다. 읽기만 한다.

   찍는 것: 예약을 **어디서 어떻게** 잡았는지(주소·칸 이름), 몇 건인지, 상태 문구가 무엇인지,
            객실 목록(우리 것), 앞으로 2주 판매 상태 개수, 손님 정보가 몇 건 잡혔는지(건수만).
            예약을 못 잡으면 메뉴 전체를 찍는다 — 예약 화면이 어느 주소인지 거기서 고른다(D-010).
   안 찍는 것: 예약자 이름·연락처·금액 — 한 글자도 안 찍는다. 그래서 이 출력은 붙여 넣어도 된다. */
import { loadEnvFile, loadConfig } from '../lib/config.js';
import { createLogger, scrubSecrets, redactSecret, maskPii } from '../lib/log.js';
import { ChannelSession } from '../browser/session.js';
import { loadSpec } from '../adapters/spec.js';
import { JsonAdapter } from '../adapters/json-adapter.js';
import { addDays, todayKst } from '../lib/kst.js';
import { normalizeStatus } from '../dashboard/paste.js';
import { readLinks, readRoutes, readClickables } from '../adapters/menu.js';
import { handoff, handoffNote } from '../lib/handoff.js';

export async function scan(argv = process.argv.slice(2), { out = console.log } = {}) {
  loadEnvFile();
  const cfg = loadConfig(process.env, { requireDashboard: false });
  const channel = argv.find((a) => !a.startsWith('--'));
  if (!channel) { out('어느 채널인지 적어 주세요: npm run scan -- yeogi'); return 2; }
  const headed = argv.includes('--headed');
  const spec = loadSpec(channel);

  /* 러너가 "예약 목록 N건 — 주소 · 칸 …" 을 info 로 남긴다. 그것을 잡아 두었다가 그대로 보여 준다. */
  const caught = [];
  const base = createLogger('훑기', { level: cfg.logLevel });
  const log = {
    debug: (...a) => base.debug(...a),
    info: (...a) => { caught.push(a.join(' ')); base.debug(...a); },
    warn: (...a) => { caught.push('경고: ' + a.join(' ')); base.debug(...a); },
    error: (...a) => base.error(...a),
  };

  const session = new ChannelSession({ channel, stateDir: cfg.paths.stateDir, secret: cfg.stateSecret, headless: !headed, browser: cfg.browser, log: base });
  const page = await session.open({ headless: !headed });
  const creds = session.loadCreds();
  if (creds) { redactSecret(creds.password); redactSecret(creds.loginId); }
  const adapter = new JsonAdapter({ spec, page, log, artifactsDir: cfg.paths.artifactsDir, creds });

  const lines = [];
  const say = (s) => { lines.push(s); out(s); };
  /* 어디로 빠져나가든 결과는 같은 자리에 둔다 — 로그인이 안 됐을 때가 오히려 붙여 넣을 일이 많다.
     경로를 찾아 헤매지 않게 늘 같은 파일 이름에 쓰고, 되면 클립보드에도 넣는다(값이 없는 출력이라 안전하다). */
  const finish = (code) => {
    say('');
    say('이 출력에는 예약자 이름·연락처·금액이 들어 있지 않다 — 그대로 붙여 넣어도 된다.');
    for (const line of handoffNote(handoff(`scan-${channel}`, lines.join('\n'), { dir: cfg.paths.artifactsDir }))) out(line);
    return code;
  };
  say(`# ${spec.name || channel} 훑어보기 — 읽기만 했고 아무것도 바꾸지 않았다`);
  try {
    const loggedIn = await adapter.ensureLoggedIn();
    /* 확인용 API 가 무엇을 줬는지 늘 적는다 — 이게 없으면 "로그인이 안 됐다" 는 말만 남고
       원인(우리 요청이 틀렸는지, 정말 세션이 풀렸는지)을 가릴 수가 없다. */
    const seen = adapter.lastLoginCheck;
    if (seen) say(`   로그인 확인 API: ${seen.why}${seen.loggedIn === null ? ' → 이걸로는 판단 못 해 화면으로 봤다' : ''}`);
    if (!loggedIn) {
      say(`✗ 로그인이 안 돼 있다 — 먼저: npm run pair -- ${channel}`);
      say(`   자동 로그인이 HTTP 400 으로 거절되면 비밀번호 문제가 아니라 요청 형식 문제다 —`);
      say(`   npm run pair -- ${channel} --wipe --record 로 실제 로그인 요청의 모양을 잡아 주면 맞춰 넣는다`);
      return finish(1);
    }
    say('✓ 로그인 되어 있다');

    // ── 객실 ──
    try {
      const rooms = await adapter.listRooms();
      say(`✓ 객실 ${rooms.length}개 — ${rooms.map((r) => `${r.roomKey}(${r.name})`).join(', ')}`);
      say('   → 콘솔 객실 매핑에 넣을 값은 괄호 앞의 숫자다');
    } catch (e) { say(`✗ 객실 목록을 못 읽었다 — ${e.message}`); }

    // ── 판매 상태 ──
    const today = todayKst();
    try {
      const cells = await adapter.readAvailability({ from: today, to: addDays(today, 14) });
      const by = {};
      for (const c of cells) by[c.state] = (by[c.state] || 0) + 1;
      say(`✓ 앞으로 2주 판매 상태 ${cells.length}칸 — ${Object.entries(by).map(([k, v]) => `${k} ${v}`).join(', ') || '없음'}`);
      if (by.unknown) say(`   ⚠ 못 알아본 상태 ${by.unknown}칸 — 이대로면 그 날은 건드리지 않는다(BR-015)`);
    } catch (e) { say(`✗ 판매 상태를 못 읽었다 — ${e.message}`); }

    // ── 예약 ──
    try {
      const rows = await adapter.listReservations({ from: addDays(today, -7), to: addDays(today, 180) });
      const how = caught.filter((l) => /예약 목록|표를 뜯어/.test(l));
      for (const h of how) say('✓ ' + h.replace(/^\S+:\s*/, ''));
      say(`✓ 예약 ${rows.length}건을 읽었다`);
      const st = {};
      for (const r of rows) {
        const k = `${r.raw?.status ?? ''} → ${r.status}`;
        st[k] = (st[k] || 0) + 1;
      }
      say(`   상태 문구: ${Object.entries(st).map(([k, v]) => `${k} (${v}건)`).join(' / ') || '없음'}`);
      const unknown = rows.filter((r) => normalizeStatus(r.raw?.status) === '' || !r.status);
      if (unknown.length) say(`   ⚠ 못 알아본 상태 ${unknown.length}건 — 이대로면 저장이 막힌다(BR-015)`);
      const badDate = rows.filter((r) => !r.checkIn || !r.checkOut).length;
      if (badDate) say(`   ⚠ 날짜를 못 읽은 줄 ${badDate}건`);
      const noRoom = rows.filter((r) => !r.roomName).length;
      if (noRoom) say(`   ⚠ 객실명이 빈 줄 ${noRoom}건 — 대시보드가 어느 방인지 못 맞춘다`);
      /* 손님 정보는 **몇 건 잡혔는지만** 적는다. 값(이름·연락처·금액)은 여기에 한 글자도 안 나온다. */
      const got = (k) => rows.filter((r) => r[k] !== '' && r[k] != null).length;
      say(`   손님 정보(건수만): 이름 ${got('guestName')} · 연락처 ${got('guestPhone')} · 인원 ${got('partySize')} · 금액 ${got('amount')} · 요청사항 ${got('memo')}`);
      say('   → 대시보드로 이 넷을 함께 보내려면 .env 의 PASTE_COLUMNS=extended (첫 실행은 npm run once -- --preview)');
    } catch (e) {
      say(`✗ 예약 목록을 못 잡았다 — ${e.message}`);
      say('   → 이 줄을 그대로 붙여 주면 후보 이름·주소를 맞춰 넣는다');
      /* ★ 못 잡았을 때 가장 필요한 것은 "그럼 그 화면이 어디냐" 다. 주소를 더 추측하는 대신
           파트너센터가 스스로 들고 있는 메뉴를 그대로 옮겨 적는다 — 이건 사이트의 지도다.
           메뉴 글자와 주소뿐이라 이 목록도 그대로 붙여 넣어도 된다. */
      await showMenu(page, spec, say);
    }
    if (argv.includes('--menu')) await showMenu(page, spec, say);
  } finally {
    await session.saveStorage().catch(() => {});
    await session.close();
  }
  return finish(0);
}

/** 파트너센터가 스스로 들고 있는 지도를 그대로 옮겨 적는다 — 경로 목록·링크·누를 자리.
    글자와 주소뿐이라 이 목록도 그대로 붙여 넣어도 된다. */
async function showMenu(page, spec, say) {
  try {
    await page.goto(spec.baseUrl.replace(/\/+$/, '') + '/', { waitUntil: 'domcontentloaded' });
    await page.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => {});
  } catch { /* 첫 화면을 못 열면 아래가 전부 비어 나온다 */ }

  /* (1) 화면 안에 든 경로 목록(Next.js). 있으면 이게 제일 확실하다 — 사이트가 말해 준 주소다. */
  const routes = await readRoutes(page);
  if (routes.length) {
    const hit = routes.filter((r) => /reserv|booking|order|sales/i.test(r));
    say(`   화면이 들고 있는 경로 ${routes.length}개 (예약처럼 보이는 것 ${hit.length}개):`);
    for (const r of hit.slice(0, 40)) say(`     ${r}`);
    if (!hit.length) for (const r of routes.slice(0, 60)) say(`     ${r}`);
  }

  /* (2) 링크 */
  const links = await readLinks(page);
  if (links.length) {
    say(`   링크 ${links.length}개:`);
    for (const l of links.slice(0, 40)) say(`     ${maskPii(l.text) || '(글자 없음)'}  →  ${l.href}`);
    if (links.length > 40) say(`     … 그 밖 ${links.length - 40}개`);
  }

  /* (3) 주소가 없는 메뉴 — 눌러야 가는 자리. 여기어때 파트너센터가 이쪽이다. */
  const clicks = await readClickables(page);
  if (clicks.length) {
    say(`   눌러 볼 만한 자리 ${clicks.length}개 (주소가 없는 메뉴):`);
    say('     ' + clicks.slice(0, 60).map((c) => maskPii(c.text)).join(' · '));
  }
  if (!routes.length && !links.length && !clicks.length) say('   메뉴: 아무것도 못 찾았다 — 로그인이 풀렸는지 볼 것');
}

if (process.argv[1] && /cli[\\/]scan\.js$/.test(process.argv[1])) {
  scan().then((c) => process.exit(c), (e) => { console.error(scrubSecrets(e.stack || e.message)); process.exit(1); });
}
