#!/usr/bin/env node
/* 상태 옮기기 — 파트너센터 세션·자격증명·실행기 기억을 클라우드에 맡기고 받는다.
   "어떤 PC 에서 켜도 이어지게" 가 목적이다(소유자 요청, 2026-09-09).

     npm run state -- status        지금 무엇이 어디에 있나 (값은 안 보여 준다)
     npm run state -- push          이 PC 것을 클라우드에 올린다
     npm run state -- pull          클라우드 것을 이 PC 로 받는다
     npm run state -- pull --force  이 PC 것이 더 새것이어도 덮어쓴다

   새 PC 에서 처음 켤 때:
     git clone → npm install → npx playwright install chromium
     → .env 를 손으로 옮긴다(STATE_SECRET 이 같아야 한다 — 그것이 봉인을 여는 열쇠다)
     → npm run state -- pull        ← 페어링 없이 로그인이 이어진다
     → npm start

   무엇이 나가나: 봉인된 글자뿐이다. 대시보드 DB 는 열쇠를 모르니 못 읽는다(BR-010).
   무엇이 안 나가나: 브라우저 프로필 폴더, artifacts/(화면 사진), .env 자체. */
import { loadEnvFile, loadConfig } from '../lib/config.js';
import { createLogger, scrubSecrets, redactSecret } from '../lib/log.js';
import { DashboardClient } from '../dashboard/client.js';
import { CloudState } from '../lib/cloud-state.js';

export async function stateCli(argv = process.argv.slice(2), { out = console.log } = {}) {
  loadEnvFile();
  const cfg = loadConfig();
  const log = createLogger('상태', { level: cfg.logLevel });
  redactSecret(cfg.stateSecret);
  const force = argv.includes('--force');
  const what = argv.find((a) => ['status', 'push', 'pull'].includes(a)) || 'status';

  if (!cfg.stateSecret) {
    out('✗ .env 의 STATE_SECRET 이 비어 있다 — 그것이 세션·비밀번호를 봉인하는 열쇠다.');
    out('  비어 있으면 평문이 대시보드 DB 로 나가므로 클라우드 저장을 켜지 않는다(BR-010).');
    return 2;
  }

  const dashboard = new DashboardClient(cfg.dashboard, { log });
  await dashboard.init();
  const cloud = new CloudState({
    db: dashboard.db, propertyId: cfg.dashboard.propertyId, secret: cfg.stateSecret,
    stateDir: cfg.paths.stateDir, channels: cfg.channels, log,
  });

  if (what === 'status') {
    out('# 상태 현황 — 값은 한 글자도 안 나온다');
    for (const r of await cloud.status()) {
      out(`  ${r.name.padEnd(18)} 이 PC ${String(r.이_PC).padEnd(26)} 클라우드 ${String(r.클라우드).padEnd(26)} ${r.올린_PC}`);
    }
    out('');
    out('  받으려면: npm run state -- pull    올리려면: npm run state -- push');
    return 0;
  }

  if (what === 'pull') {
    const r = await cloud.pull({ force });
    out(`받음 ${r.pulled.length}개${r.pulled.length ? ' — ' + r.pulled.join(', ') : ''}`);
    if (r.kept.length) out(`그대로 둔 것 ${r.kept.length}개 — ${r.kept.join(', ')} (이 PC 것이 더 새것이거나 같다)`);
    if (r.missing.length) out(`클라우드에 없는 것 — ${r.missing.join(', ')}`);
    if (!r.pulled.length && r.missing.length === cloud.files().length) {
      out('→ 아직 아무것도 안 올려 뒀다. 원래 쓰던 PC 에서 npm run state -- push 를 한 번 돌릴 것.');
    }
    return 0;
  }

  const r = await cloud.push({ force });
  out(`올림 ${r.pushed.length}개${r.pushed.length ? ' — ' + r.pushed.join(', ') : ''}`);
  if (r.skipped.length) out(`바뀐 것 없어 넘어감 — ${r.skipped.join(', ')}`);
  if (r.blocked.length) {
    out(`✗ 막힘 — ${r.blocked.join(', ')} (그 사이 다른 PC 가 더 새로 올렸다)`);
    out('  먼저 npm run state -- pull 로 받고, 그래도 이 PC 것을 올리려면 --force');
    return 1;
  }
  return 0;
}

if (process.argv[1] && /cli[\\/]state\.js$/.test(process.argv[1])) {
  /* 스택 트레이스는 사장님에게 아무것도 알려 주지 않는다 — 한 줄 안내만 낸다.
     자세히 봐야 하면 LOG_LEVEL=debug 로 돌린다(개발자용). */
  stateCli().then((c) => process.exit(c), (e) => {
    console.error(scrubSecrets(e.message || String(e)));
    if (/^debug$/i.test(process.env.LOG_LEVEL || '')) console.error(scrubSecrets(e.stack || ''));
    process.exit(1);
  });
}
