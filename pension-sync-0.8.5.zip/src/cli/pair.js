#!/usr/bin/env node
/* 페어링 — 사장님이 실행기 PC 에서 파트너센터에 한 번 직접 로그인한다(2단계 인증까지). 그 상태가 프로필에 남는다.
     npm run pair -- yeogi          (야놀자는 yanolja)
     npm run pair -- yeogi --wipe   처음부터 다시
     npm run pair -- yeogi --record 로그인하는 동안 오간 **로그인 요청의 모양**을 적어 준다
                                    (자동 로그인이 HTTP 400 으로 거절될 때 무엇이 빠졌는지 보는 용도.
                                     값은 안 찍고 칸 이름만 찍으므로 그대로 공유해도 된다)
   원하면 아이디·비밀번호를 저장해 세션이 풀렸을 때 스스로 다시 로그인하게 한다(STATE_SECRET 로 잠근다). */
import readline from 'node:readline';
import { loadEnvFile, loadConfig } from '../lib/config.js';
import { createLogger, scrubSecrets } from '../lib/log.js';
import { ChannelSession } from '../browser/session.js';
import { loadSpec } from '../adapters/spec.js';
import { JsonAdapter } from '../adapters/json-adapter.js';

/* 로그인처럼 보이는 요청인가 — 주소로 고른다. */
const LOOKS_LIKE_LOGIN = /login|signin|auth|account|token|session/i;

/** 값을 빼고 칸 이름만 남긴다(겹겹이 든 것도). 비밀번호가 어디 있는지는 이름으로 충분히 안다. */
function keysOnly(v, depth = 0) {
  if (v === null || depth > 4) return null;
  if (Array.isArray(v)) return v.length ? [keysOnly(v[0], depth + 1)] : [];
  if (typeof v === 'object') {
    const out = {};
    for (const k of Object.keys(v).slice(0, 40)) out[k] = keysOnly(v[k], depth + 1);
    return out;
  }
  return typeof v;
}

function ask(q, { hidden = false } = {}) {
  /* ★ 사람이 없는 자리(예약 작업·클라우드)에서 부르면 stdin 을 영원히 기다린다.
       그러면 실행기가 살아 있는 채로 아무것도 안 한다 — 바로 그 상태를 없애는 중이다. */
  if (!process.stdin.isTTY) {
    throw new Error('페어링은 사람이 직접 창에서 해야 한다 (화면 없는 자리에서는 CHANNEL_CREDS 를 쓸 것)');
  }
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
  if (hidden) {
    rl._writeToOutput = function (s) { if (/[\r\n]/.test(s)) rl.output.write(s); else rl.output.write('*'); };
    process.stdout.write(q);
  }
  return new Promise((res) => rl.question(hidden ? '' : q, (a) => { rl.close(); if (hidden) process.stdout.write('\n'); res(a.trim()); }));
}

export async function pair(argv = process.argv.slice(2)) {
  loadEnvFile();
  const cfg = loadConfig(process.env, { requireDashboard: false });
  const log = createLogger('페어링', { level: cfg.logLevel });
  const channel = argv.find((a) => !a.startsWith('--'));
  if (!channel) { console.log('어느 채널인지 적어 주세요: npm run pair -- yeogi | yanolja'); return 2; }
  const spec = loadSpec(channel);
  const session = new ChannelSession({ channel, stateDir: cfg.paths.stateDir, secret: cfg.stateSecret, headless: false, browser: cfg.browser, log });
  if (argv.includes('--wipe')) { session.wipe(); log.info(`${channel}: 저장돼 있던 프로필·자격증명을 지웠다`); }
  if (!cfg.stateSecret) log.warn('STATE_SECRET 이 비어 있다 — 자격증명을 저장하면 평문으로 남는다. .env 에 긴 문장을 넣어 두는 것이 좋다.');

  const bail = async () => { await session.close().catch(() => {}); process.exit(130); };
  process.once('SIGINT', bail);
  const page = await session.open({ headless: false });
  const adapter = new JsonAdapter({ spec, page, log, artifactsDir: cfg.paths.artifactsDir });

  /* ★ --record: 사장님이 손으로 로그인하는 동안 **파트너센터가 실제로 보내는 로그인 요청**을 본다.
       우리가 흉내 낸 요청이 HTTP 400 으로 거절될 때, 무엇이 빠졌는지 알 길이 이것뿐이다.
       값(아이디·비밀번호)은 찍지 않는다 — 주소·방식·칸 이름·상태 코드만 남긴다. */
  const recorded = [];
  if (argv.includes('--record')) {
    page.on('request', (req) => {
      const u = req.url();
      if (req.method() === 'GET' || !LOOKS_LIKE_LOGIN.test(u)) return;
      let shape = null;
      const post = req.postData();
      if (post) { try { shape = keysOnly(JSON.parse(post)); } catch { shape = '(JSON 아님) ' + String(post).replace(/=[^&]*/g, '=…').slice(0, 200); } }
      recorded.push({ method: req.method(), url: u.replace(/\?.*$/, ''), query: u.includes('?') ? u.split('?')[1].replace(/=[^&]*/g, '=…').slice(0, 200) : null, shape });
    });
    page.on('response', (res) => {
      const rec = recorded.find((r) => r.url === res.url().replace(/\?.*$/, '') && r.status === undefined);
      if (rec) rec.status = res.status();
    });
    console.log('기록 모드: 로그인하는 동안 오간 로그인 요청의 **모양만** 적습니다(값은 안 적습니다).');
  }
  await page.goto(spec.baseUrl + spec.login.url, { waitUntil: 'domcontentloaded' });
  console.log(`\n브라우저 창에서 ${spec.name || channel} 에 직접 로그인하세요(문자 인증까지 끝까지).`);
  console.log('로그인이 끝나 첫 화면이 보이면 여기로 돌아와 Enter 를 누르세요.\n');
  let ok = false;
  for (let i = 0; i < 3 && !ok; i++) {
    await ask('로그인이 끝났으면 Enter… ');
    await page.goto(spec.baseUrl + (spec.login.checkUrl || spec.login.url), { waitUntil: 'domcontentloaded' }).catch(() => {});
    if (spec.login.loggedIn.waitMs) await page.waitForTimeout(spec.login.loggedIn.waitMs);
    ok = await adapter.isLoggedIn();
    /* ★ 왜 아니라고 봤는지 같이 보여 준다. 이유 없이 "아직 아닙니다" 만 반복하면
         사장님은 멀쩡히 로그인해 놓고 뭘 더 해야 하는지 알 수가 없다. */
    if (!ok) {
      const seen = adapter.lastLoginCheck;
      console.log('아직 로그인된 화면이 아닙니다. 브라우저에서 로그인을 마친 뒤 다시 Enter.' +
        (seen ? `\n  (확인용 API: ${seen.why} · 지금 주소: ${page.url()})` : `\n  (지금 주소: ${page.url()})`));
    }
  }
  if (!ok) { await session.close(); console.log('페어링을 마치지 못했습니다.'); return 1; }
  await session.saveStorage();
  log.info(`${channel}: 로그인 상태를 저장했다 (${session.profileDir})`);

  /* 여기서 저장을 건너뛰면 세션이 풀릴 때마다(파트너센터는 심심찮게 풀린다) 사장님이 다시 붙어야 한다.
     상주 실행기의 뜻이 없어지므로 기본을 '저장' 으로 둔다 — PC 밖으로는 나가지 않는다. */
  const existing = (() => { try { return !!session.loadCreds(); } catch { return false; } })();
  console.log('\n세션이 풀렸을 때 실행기가 스스로 다시 로그인하려면 아이디·비밀번호가 필요합니다.');
  console.log(`이 PC 안(${session.credsFile})에만 ${cfg.stateSecret ? '잠가서 ' : ''}저장되고 대시보드·저장소·로그로는 절대 나가지 않습니다.`);
  if (existing) console.log('(이미 저장돼 있습니다. 그냥 Enter 를 누르면 그대로 둡니다.)');
  const ans = (await ask(`아이디·비밀번호를 ${existing ? '새로 ' : ''}저장할까요? (${existing ? 'y/N' : 'Y/n'}) `)).toLowerCase();
  const save = existing ? ans === 'y' : ans !== 'n';
  if (save) {
    const loginId = await ask('아이디: ');
    const password = await ask('비밀번호: ', { hidden: true });
    session.saveCreds({ loginId, password });
    log.info(`${channel}: 자격증명을 ${cfg.stateSecret ? '잠가서' : '평문으로'} 저장했다`);
  } else if (!existing) {
    log.warn(`${channel}: 저장하지 않았다 — 세션이 풀리면 실행기가 멈추고 사장님이 다시 페어링해야 한다`);
  }
  if (recorded.length) {
    console.log('\n── 로그인하는 동안 오간 요청(값 없음, 그대로 공유해도 됩니다) ──');
    for (const r of recorded.slice(0, 12)) {
      console.log(`  ${r.method} ${r.url}${r.status !== undefined ? ` [${r.status}]` : ''}`);
      if (r.query) console.log(`     질의: ?${r.query}`);
      if (r.shape) console.log('     보낸 칸: ' + (typeof r.shape === 'string' ? r.shape : JSON.stringify(r.shape)));
    }
    console.log('  ↑ 이 출력을 주시면 자동 로그인 요청을 실제 모양에 맞춥니다.');
  } else if (argv.includes('--record')) {
    console.log('\n기록된 로그인 요청이 없습니다 — 이미 로그인돼 있어서 폼을 거치지 않았을 수 있습니다.');
    console.log('그 경우 npm run pair -- ' + channel + ' --wipe --record 로 처음부터 다시 해 보세요.');
  }
  await session.close();
  console.log(`\n페어링 완료. 이제 'npm run once' 로 한 바퀴 돌려 보고, 'npm start' 로 상주시키세요.`);
  return 0;
}

if (process.argv[1] && /cli[\\/]pair\.js$/.test(process.argv[1])) {
  pair().then((c) => process.exit(c), (e) => { console.error(scrubSecrets(e.stack || e.message)); process.exit(1); });
}
