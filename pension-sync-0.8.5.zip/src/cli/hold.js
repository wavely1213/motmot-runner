#!/usr/bin/env node
/* 손막음 — 여기어때에서 **방 하나를 직접 막는다.** 그리고 **우리가 다시 열지 않는다.**

   왜 있나 (2026-09-11 소유자 사례):
     여기어때로 결제한 손님이 전화로 객실 변경을 요청했다. 그런데 파트너센터는 **취소만 되고
     객실 이동이 안 된다.** 취소하면 받은 돈이 날아가므로, 예약은 원래 방에 그대로 둔 채
     **실제 묵는 방을 따로 막아** 두 방이 다 안 팔리게 하는 수밖에 없다.
       원래 방 → 여기어때 예약이 물고 있어 자동으로 안 팔린다
       실제 방 → 이 명령으로 막는다

   ★ 우리가 막은 날 기억(closedByUs)에 **넣지 않는다.** 넣으면 캘린더 대조가
     "우리가 막았는데 대시보드에 그 예약이 없네" 하고 **그 방을 다시 연다.** 손막음은
     대시보드 원장에 없는 사정(객실 변경·공사·개인 사용)이라, 사람이 풀기 전까지 그대로 둬야 한다.
     `calendar.js` 의 `diffRoom` 이 `wasClosedByUs(d)` 인 날만 되돌리므로 이대로면 안전하다.

     npm run hold -- list                                       지금 잡아 둔 손막음
     npm run hold -- yeogi 621392 2026-09-12 2026-09-13         무엇을 할지 보여만 준다
     npm run hold -- yeogi 621392 2026-09-12 2026-09-13 --yes   실제로 막는다
     npm run hold -- yeogi 621392 2026-09-12 2026-09-13 --release --yes   다시 연다
     --why "김훈 객실변경"   왜 막는지 남긴다(나중에 목록에서 보인다)

   날짜는 **입실일 ~ 퇴실일** 이다(퇴실일은 안 막는다). 위 예는 9/12 하룻밤을 막는다.
   객실 번호(621392)는 `npm run scan -- yeogi` 의 객실 목록에서 볼 수 있다. */
import { loadEnvFile, loadConfig } from '../lib/config.js';
import { createLogger, redactSecret, scrubSecrets } from '../lib/log.js';
import { ChannelSession } from '../browser/session.js';
import { loadSpec } from '../adapters/spec.js';
import { JsonAdapter } from '../adapters/json-adapter.js';
import { LocalState } from '../engine/state.js';
import { SingleInstanceLock } from '../lib/lock.js';
import { eachDate, todayKst } from '../lib/kst.js';

/** 막을 밤들. 퇴실일은 빼고, 지난 날도 뺀다(지난 밤은 막을 이유가 없다). */
export function nightsToHold(from, to, today) {
  return eachDate(from, to).filter((d) => d !== to && d >= today);
}

/** 사람이 보는 한 줄. 값은 예약자 정보가 아니라 객실·날짜뿐이라 그대로 붙여도 된다. */
export function holdLine(key, h) {
  const [channel, roomKey] = key.split('|');
  return `  ${channel} ${roomKey.padEnd(10)} ${h.from} ~ ${h.to}  ${h.why || ''}`.trimEnd();
}

export async function holdCli(argv = process.argv.slice(2), { out = console.log } = {}) {
  loadEnvFile();
  const cfg = loadConfig(process.env, { requireDashboard: false });
  const state = new LocalState(cfg.paths.stateDir);

  if (argv[0] === 'list' || !argv.length) {
    const holds = state.holds();
    if (!Object.keys(holds).length) {
      out('잡아 둔 손막음이 없다.');
      out('  막으려면: npm run hold -- yeogi <객실번호> <입실일> <퇴실일> --why "사유" --yes');
      return 0;
    }
    out('# 손막음 — 우리가 다시 열지 않는 날들');
    for (const [k, h] of Object.entries(holds)) out(holdLine(k, h));
    out('');
    out('  풀려면 같은 날짜에 --release --yes 를 붙여 다시 부를 것.');
    return 0;
  }

  const rest = argv.filter((a) => !a.startsWith('--'));
  const [channel, roomKey, from, to] = rest;
  const release = argv.includes('--release');
  const yes = argv.includes('--yes');
  const whyAt = argv.indexOf('--why');
  const why = whyAt >= 0 ? String(argv[whyAt + 1] || '') : '';

  if (!channel || !roomKey || !from || !to) {
    out('이렇게 적어 주세요:');
    out('  npm run hold -- yeogi 621392 2026-09-12 2026-09-13 --why "김훈 객실변경" --yes');
    out('  (입실일 ~ 퇴실일. 퇴실일은 안 막는다 — 위 예는 9/12 하룻밤)');
    return 2;
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to)) {
    out('✗ 날짜는 2026-09-12 꼴로 적어 주세요.');
    return 2;
  }
  if (to <= from) { out('✗ 퇴실일이 입실일보다 뒤여야 한다.'); return 2; }

  const today = todayKst();
  const nights = nightsToHold(from, to, today);
  if (!nights.length) { out(`✗ 막을 밤이 없다 — ${from}~${to} 는 이미 지났다.`); return 2; }

  /* ★ 상주 실행기가 브라우저 프로필을 쥐고 있으면 둘이 같은 프로필을 열어 한쪽이 깨진다.
       여기서 걸러 내지 않으면 "왜 안 되지" 로 한참 헤맨다. */
  const lock = new SingleInstanceLock(cfg.paths.stateDir);
  const got = lock.acquire();
  if (!got.ok) {
    out(`✗ 실행기가 지금 돌고 있다(pid ${got.pid}) — 브라우저를 같이 못 쓴다.`);
    out('  먼저:  Stop-ScheduledTask -TaskName "pension-sync-executor"');
    out('  끝나면: Start-ScheduledTask -TaskName "pension-sync-executor"');
    return 1;
  }

  const what = release ? '다시 연다' : '막는다';
  out(`${channel} · 객실 ${roomKey} · ${nights.length}밤(${nights[0]} ~ ${nights[nights.length - 1]}) 을 ${what}`);
  if (!yes) {
    out('');
    out('  아직 아무것도 안 했다. 실제로 하려면 끝에 --yes 를 붙여 다시 부를 것.');
    lock.release();
    return 0;
  }

  const log = createLogger('손막음', { level: cfg.logLevel });
  const session = new ChannelSession({ channel, stateDir: cfg.paths.stateDir, secret: cfg.stateSecret, headless: true, browser: cfg.browser, log });
  try {
    const page = await session.open({ headless: true });
    const creds = session.loadCreds();
    if (creds) { redactSecret(creds.password); redactSecret(creds.loginId); }
    const adapter = new JsonAdapter({
      spec: loadSpec(channel), page, log, artifactsDir: cfg.paths.artifactsDir, creds,
      yieldMs: cfg.relogin?.yieldMs,
    });
    if (!(await adapter.ensureLoggedIn())) {
      out(`✗ 로그인이 안 돼 있다 — 먼저: npm run pair -- ${channel}`);
      return 1;
    }
    const r = await adapter.setClosed({ roomKey, dates: nights, closed: !release });
    out(`${release ? '연' : '막은'} 밤 ${r.applied}개`);
    for (const s of r.skipped) out(`  건너뜀 ${s.date} — ${s.why}`);

    /* 기록은 **실제로 손댄 것이 있을 때만** 남긴다. 하나도 못 했는데 기록만 남으면
       목록이 사실과 어긋나고, 사장님은 막혔다고 믿는다. */
    if (r.applied > 0 || r.skipped.some((s) => s.why === '이미 그 상태')) {
      if (release) state.releaseHold(channel, roomKey, from);
      else {
        /* ★ 손막음을 얹는 순간 **'우리가 막았다' 기억을 지운다.**
           안 지우면 캘린더 대조가 그 날을 '우리가 막았는데 원장에 예약이 없다' 로 읽고
           **다시 열어 버린다**(diffRoom 은 holds 를 아예 안 본다). 손막음은 원장에 없는
           사정으로 막는 것이라, 사람이 풀기 전까지 그대로 둬야 한다(2026-09-18 검토). */
        state.forgetClosedByUs(channel, roomKey, nights);
        state.addHold(channel, roomKey, from, to, why);
      }
    }
    out('');
    out(release
      ? '  이 방은 이제 여기어때에서 다시 팔린다.'
      : '  ★ 이 막음은 우리가 다시 열지 않는다. 풀려면 같은 날짜에 --release --yes 를 붙일 것.');
    return 0;
  } finally {
    await session.close().catch(() => {});
    lock.release();
  }
}

if (process.argv[1] && /cli[\\/]hold\.js$/.test(process.argv[1])) {
  holdCli().then((c) => process.exit(c), (e) => {
    console.error(scrubSecrets(e.message || String(e)));
    if (/^debug$/i.test(process.env.LOG_LEVEL || '')) console.error(scrubSecrets(e.stack || ''));
    process.exit(1);
  });
}
