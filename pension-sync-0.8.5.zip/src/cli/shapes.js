#!/usr/bin/env node
/* 모양 보기 — 탐색 기록(artifacts/discover/<채널>/<시각>/)의 JSON 응답에서 **키 이름만** 뽑는다.
     npm run shapes -- yeogi              가장 최근 기록
     npm run shapes -- yeogi --all        오래된 기록까지 전부 훑어 합친다
     npm run shapes -- yeogi --dir <경로> 폴더를 직접 지정
   값(예약자 이름·전화·금액)은 한 글자도 찍지 않는다. 그래서 이 출력은 그대로 공유해도 된다 — 채널 JSON 의
   fromJson 필드 매핑을 채우는 데 필요한 것은 "어떤 키가 어디 있는지" 뿐이다. */
import fs from 'node:fs';
import path from 'node:path';
import { loadEnvFile, loadConfig } from '../lib/config.js';
import { scrubSecrets } from '../lib/log.js';

const MAX_KEYS = 60;      // 한 노드에서 보여 줄 키 수
const MAX_DEPTH = 8;   // products 안쪽까지 봐야 판매 상태 필드가 보인다

/** 값을 빼고 모양만 남긴다. 배열은 첫 원소의 모양으로 대표하고 길이만 적는다. */
function shapeOf(v, depth = 0) {
  if (v === null) return 'null';
  if (Array.isArray(v)) {
    if (!v.length) return '[]';
    if (depth >= MAX_DEPTH) return '[…]';
    return [`[${v.length}개]`, shapeOf(v[0], depth + 1)];
  }
  if (typeof v === 'object') {
    if (depth >= MAX_DEPTH) return '{…}';
    const out = {};
    for (const k of Object.keys(v).slice(0, MAX_KEYS)) out[k] = shapeOf(v[k], depth + 1);
    if (Object.keys(v).length > MAX_KEYS) out['…'] = `그 밖 ${Object.keys(v).length - MAX_KEYS}개`;
    return out;
  }
  return typeof v;   // string | number | boolean — 값은 안 찍는다
}

/* 상태·구분처럼 '정해진 몇 값' 만 도는 칸은 값까지 알아야 매핑할 수 있다(판매중 ↔ 판매중지).
   이름이 이 목록에 있는 칸만 값을 모은다 — 이름·전화가 들어갈 이름이 아니다. */
const ENUM_KEYS = /^(status|statusLabel|state|saleType|saleTypeLabel|blockType|rateBase|planType|type|code|label|name)$/;

function collectEnums(v, key = '', out = new Map(), depth = 0) {
  if (depth >= MAX_DEPTH || v == null) return out;
  if (Array.isArray(v)) { for (const x of v.slice(0, 200)) collectEnums(x, key, out, depth + 1); return out; }
  if (typeof v === 'object') {
    for (const [k, val] of Object.entries(v)) {
      if (ENUM_KEYS.test(k) && (typeof val === 'string' || typeof val === 'number')) {
        if (!out.has(k)) out.set(k, new Set());
        if (out.get(k).size < 12) out.get(k).add(val);
      }
      collectEnums(val, k, out, depth + 1);
    }
    return out;
  }
  return out;
}

/** 리스트로 보이는 자리를 찾아 준다 — fromJson 의 list 에 쓸 경로. */
function listPaths(v, prefix = '', out = [], depth = 0) {
  if (depth >= MAX_DEPTH || !v || typeof v !== 'object') return out;
  if (Array.isArray(v)) {
    if (v.length && typeof v[0] === 'object' && !Array.isArray(v[0])) {
      out.push({ path: prefix || '(최상위)', count: v.length, fields: Object.keys(v[0]).slice(0, MAX_KEYS) });
    }
    return out;
  }
  for (const k of Object.keys(v)) listPaths(v[k], prefix ? `${prefix}.${k}` : k, out, depth + 1);
  return out;
}

function newestDir(base) {
  const dirs = fs.readdirSync(base, { withFileTypes: true })
    .filter((e) => e.isDirectory()).map((e) => path.join(base, e.name))
    .sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs);
  return dirs[0];
}

export function shapes(argv = process.argv.slice(2), { out = console.log } = {}) {
  loadEnvFile();
  const cfg = loadConfig(process.env, { requireDashboard: false });
  const channel = argv.find((a) => !a.startsWith('--'));
  if (!channel) { out('어느 채널인지 적어 주세요: npm run shapes -- yeogi'); return 2; }

  const at = argv.indexOf('--dir');
  const base = path.join(cfg.paths.artifactsDir, 'discover', channel);
  let dirs;
  if (at >= 0 && argv[at + 1]) dirs = [path.resolve(argv[at + 1])];
  else if (!fs.existsSync(base)) { out(`탐색 기록이 없다: ${base}\n먼저 npm run discover -- ${channel} 를 돌리세요.`); return 1; }
  else if (argv.includes('--all')) {
    dirs = fs.readdirSync(base, { withFileTypes: true }).filter((e) => e.isDirectory()).map((e) => path.join(base, e.name));
  } else dirs = [newestDir(base)];

  const seen = new Map();   // "METHOD /경로" → { status, shape, lists }
  let files = 0;
  for (const dir of dirs) {
    if (!dir || !fs.existsSync(dir)) continue;
    for (const f of fs.readdirSync(dir).filter((f) => /^\d+\.json$/.test(f)).sort()) {
      let rec;
      try { rec = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')); } catch { continue; }
      files++;
      /* ★ 응답이 JSON 이 아니어도(빈 응답·텍스트) 버리지 않는다. 쓰기 요청은 **보낸 몸통**이 핵심인데
           예전엔 여기서 continue 해서 PUT close/open 이 통째로 사라졌다. */
      let body = null, bodyIsJson = true;
      try { body = JSON.parse(rec.body); } catch { bodyIsJson = false; }
      const key = `${rec.method} ${String(rec.url).replace(/\?.*$/, '')}`;
      if (seen.has(key)) continue;                                // 같은 주소는 한 번만
      /* ★ 쓰기 요청(PUT/POST)은 **보낸 몸통**이 핵심이다 — 방막기가 어떤 객실·날짜를 어떤 형식으로
           보내는지가 거기 있다. 값에 개인정보가 들어갈 자리가 아니므로(객실 id·날짜·수량) 값까지 남긴다. */
      let sent = null;
      if (rec.method !== 'GET' && rec.postData) {
        try { sent = JSON.parse(rec.postData); } catch { sent = String(rec.postData).slice(0, 800); }
      }
      const q = String(rec.url).includes('?') ? String(rec.url).split('?')[1].slice(0, 400) : null;
      seen.set(key, {
        status: rec.status, sent, q,
        shape: bodyIsJson ? shapeOf(body) : `(JSON 아님, ${rec.size ?? 0}바이트)`,
        lists: bodyIsJson ? listPaths(body) : [],
        enums: bodyIsJson ? collectEnums(body) : new Map(),
      });
    }
  }

  if (!seen.size) { out(`JSON 응답을 찾지 못했다(파일 ${files}개를 봤다). 폴더가 맞는지 확인할 것: ${dirs.join(', ')}`); return 1; }

  out(`# ${channel} 응답 모양 — 값은 빼고 키 이름만. 이 출력은 그대로 공유해도 된다.`);
  out(`# 기록: ${dirs.join(', ')}  (JSON 응답 ${seen.size}종)\n`);
  for (const [key, v] of [...seen].sort()) {
    out(`## ${key}   [${v.status}]`);
    if (v.q) out(`   질의: ?${v.q}`);
    if (v.sent !== null) out('   보낸 것: ' + scrubSecrets(JSON.stringify(v.sent)).slice(0, 2000));
    if (v.enums && v.enums.size) {
      const parts = [...v.enums].map(([k, set]) => `${k}=${[...set].map((x) => JSON.stringify(x)).join('|')}`);
      out('   정해진 값들: ' + parts.join('  '));
    }
    if (v.lists.length) {
      out('   목록으로 쓸 만한 자리:');
      for (const l of v.lists) out(`     - ${l.path}  (${l.count}개)  ${l.fields.join(', ')}`);
    }
    out('   ' + scrubSecrets(JSON.stringify(v.shape)).slice(0, 4000));
    out('');
  }
  out('이 출력을 그대로 붙여 주면 config/selectors/' + channel + '.json 의 fromJson 매핑을 채울 수 있다.');
  return 0;
}

if (process.argv[1] && /cli[\\/]shapes\.js$/.test(process.argv[1])) {
  process.exit(shapes());
}
