#!/usr/bin/env node
/* 왜 이런가 — **어떤 날 어떤 방이 왜 그 상태인지**를 한 장으로 찍는다.

   왜 있나 (2026-09-17 소유자: "202호가 왜 마감인지 로그 뜯어보던지 이유 설명해"):
     판매현황의 `마감` 은 세 곳에서 온다 — 우리가 막았거나, 사장님이 파트너센터에서 직접 막았거나,
     손막음(`npm run hold`)이다. 로그는 **우리가 한 일**만 남기므로 나머지 둘은 로그에 아예 없다.
     그래서 "예약도 없는데 왜 마감이냐" 는 로그를 아무리 뒤져도 답이 안 나온다.
     이 명령은 그 날의 네 가지를 한 줄에 나란히 놓는다:
       우리 원장이 뭐라 하나 · 파트너센터가 뭐라 하나 · 우리가 막았다고 기억하나 · 그래서 다음 주기에 뭘 하나

     npm run why -- yeogi 2026-10-04            그 하루
     npm run why -- yeogi 2026-10-04 --days 3   그 날부터 사흘
     npm run why -- yeogi                       오늘

   읽기만 한다. 막지도, 열지도, 저장하지도 않는다.
   예약자 이름·연락처·금액은 한 글자도 안 찍는다(BR-020) — 그대로 붙여 넣어도 된다. */
import { loadEnvFile, loadConfig } from '../lib/config.js';
import { createLogger, redactSecret, scrubSecrets } from '../lib/log.js';
import { ChannelSession } from '../browser/session.js';
import { loadSpec } from '../adapters/spec.js';
import { JsonAdapter } from '../adapters/json-adapter.js';
import { DashboardClient } from '../dashboard/client.js';
import { LocalState } from '../engine/state.js';
import { heldByOther } from '../lib/lock.js';
import { blockedDates, closedByRate } from '../engine/calendar.js';
import { roomLabeler } from '../engine/room-label.js';
import { addDays, eachDate, isYmd, todayKst } from '../lib/kst.js';
import { handoff, handoffNote } from '../lib/handoff.js';

/** 판매현황 한 칸을 사람 말로. */
export const CELL_WORD = { open: '판매중', closed: '마감', sold: '예약완료', unknown: '모르는 문구' };

/** 그 방 그 날에 손막음이 걸려 있나. holds 는 `channel|roomKey|from` 로 들어 있다(state.js). */
export function heldOn(holds, channel, roomKey, date) {
  for (const [k, h] of Object.entries(holds || {})) {
    if (!k.startsWith(`${channel}|${roomKey}|`)) continue;
    if (h && h.from <= date && date < h.to) return h;
  }
  return null;
}

/**
 * 한 칸의 판정 — 순수 계산이라 그대로 시험한다.
 * @param {object} o
 *   want        우리 원장이 "막아야 할 날" 이라 했나
 *   rateClosed  그 막을 이유가 만실(rate_calendar.closed)인가
 *   cell        파트너센터 판매현황 상태 (open|closed|sold|unknown|undefined)
 *   closedByUs  우리가 막았다고 기억하나
 *   held        손막음이 걸려 있나
 * @returns {{verdict:string, next:string}} verdict = 왜 그런가 · next = 다음 주기에 무엇을 하나
 */
export function judgeCell({ want, rateClosed, cell, closedByUs, held }) {
  if (cell === undefined) return { verdict: '판매현황에 이 날이 없다 — 매핑이나 판매기간을 볼 것(I-021)', next: '아무것도 안 한다' };
  if (cell === 'sold') return { verdict: '여기어때에 예약이 들어 있다', next: '손대지 않는다 — 채널 예약이 든 날은 어떤 경우에도 안 건드린다(BR-018)' };
  if (cell === 'unknown') return { verdict: '상태 문구를 못 알아봤다', next: '건드리지 않는다(BR-015)' };
  if (want) {
    const because = rateClosed ? '원장에 만실이 걸려 있다' : '원장에 예약이 있다';
    return cell === 'closed'
      ? { verdict: `${because} — 막혀 있는 것이 맞다`, next: '그대로 둔다' }
      : { verdict: `${because} — 아직 열려 있다`, next: '다음 주기에 막는다' };
  }
  if (cell === 'open') return { verdict: '원장이 비어 있고 팔고 있다', next: '그대로 둔다' };
  /* ★ 사유(`held.why`)는 **찍지 않는다.** 사장님이 "김훈 객실변경" 처럼 손님 이름을 적어 두는 자리라
     이 출력(붙여 넣어도 된다고 말하는 글)에 실리면 안 된다(BR-020). 사유는 `npm run hold -- list` 에서 본다. */
  if (held) return { verdict: '손막음이다 — 사유는 npm run hold -- list 에서 본다', next: '사람이 풀기 전까지 안 연다 (npm run hold -- release)' };
  if (closedByUs) return { verdict: '우리가 막았는데 원장이 비었다', next: '다음 주기에 원장을 두 번 읽고 다시 연다' };
  return {
    verdict: '우리가 막은 것이 아니다 — 파트너센터에서 직접 막혔거나, 막은 기억이 지워졌다',
    next: '열지 않는다(BR-018) — 팔려면 파트너센터에서 직접 열어야 한다',
  };
}

const pad = (s, n) => String(s ?? '').padEnd(n - [...String(s ?? '')].filter((c) => /[가-힣]/.test(c)).length);

export async function whyCli(argv = process.argv.slice(2), { out = console.log } = {}) {
  loadEnvFile();
  const cfg = loadConfig();
  const bare = argv.filter((a) => !a.startsWith('--'));
  const channel = bare.find((a) => !isYmd(a)) || cfg.channels[0];
  const from = bare.find((a) => isYmd(a)) || todayKst();
  const at = argv.indexOf('--days');
  const days = at >= 0 && argv[at + 1] ? Math.max(1, Number(argv[at + 1])) : 1;
  /* ★ 틀린 인자를 조용히 넘기지 않는다. 날짜를 잘못 적으면 '오늘' 을 조사해 놓고 사장님은
     그 날을 본 줄 안다 — 틀린 답을 자신 있게 주는 것이 가장 나쁘다(2026-09-18 검토). */
  if (!Number.isFinite(days)) { out(`✗ --days 는 숫자여야 합니다 — 받은 값: ${argv[at + 1]}`); return 2; }
  const stray = bare.filter((a) => a !== channel && !isYmd(a));
  if (stray.length) { out(`✗ 날짜는 2026-10-04 꼴로 적어 주세요 — 못 알아본 값: ${stray.join(', ')}`); return 2; }
  const to = addDays(from, days);
  const headed = argv.includes('--headed');

  const log = createLogger('왜', { level: cfg.logLevel });
  const spec = loadSpec(channel);
  const lines = [];
  const say = (s) => { lines.push(s); out(s); };
  const finish = (code) => {
    say('');
    say('이 출력에는 예약자 이름·연락처·금액이 들어 있지 않다 — 그대로 붙여 넣어도 된다.');
    for (const line of handoffNote(handoff(`why-${channel}-${from}`, lines.join('\n'), { dir: cfg.paths.artifactsDir }))) out(line);
    return code;
  };

  say(`# ${spec.name || channel} — ${from}${days > 1 ? ` ~ ${addDays(to, -1)}` : ''} 이 왜 이런가 (읽기만 했다)`);

  /* ★ 상주가 돌고 있으면 파트너센터를 같이 못 연다 — 브라우저 프로필이 하나뿐이라 한쪽이 실패한다(I-064).
     자물쇠를 **잡지는 않는다**(잡으면 상주가 다음에 못 뜬다). 보기만 하고 물러난다. */
  const running = heldByOther(cfg.paths.stateDir);
  if (running.held) {
    say(`✗ 실행기가 지금 돌고 있습니다(pid ${running.pid}) — 전원을 잠깐 끄고 다시 돌려 주세요.`);
    say('  (파트너센터 로그인 자리가 하나라, 둘이 같이 열면 한쪽이 실패합니다)');
    return finish(2);
  }

  const dashboard = new DashboardClient(cfg.dashboard, { log });
  await dashboard.init();
  const pairs = new Map();
  for (const m of await dashboard.roomMap(channel)) {
    if (!pairs.has(m.resource_id)) pairs.set(m.resource_id, []);
    pairs.get(m.resource_id).push(m.channel_room_key);
  }
  if (!pairs.size) { say('✗ 객실 매핑이 하나도 없다 — 콘솔 채널 탭에서 붙여야 한다'); return finish(1); }
  const label = roomLabeler(await dashboard.resources().catch(() => []), pairs);

  const book = await dashboard.bookings(from, to);
  if (!book.ok) { say(`✗ 원장을 못 읽었다 — ${book.why}`); return finish(1); }
  const rateCal = await dashboard.rateCalendar(from, to).catch(() => []);
  const want = blockedDates({ bookings: book.rows, cols: book.cols, rateCal, from, to });
  const rate = closedByRate({ rateCal, from, to });

  const session = new ChannelSession({ channel, stateDir: cfg.paths.stateDir, secret: cfg.stateSecret, headless: !headed, browser: cfg.browser, log });
  const page = await session.open({ headless: !headed });
  const creds = session.loadCreds();
  if (creds) { redactSecret(creds.password); redactSecret(creds.loginId); }
  const adapter = new JsonAdapter({ spec, page, log, artifactsDir: cfg.paths.artifactsDir, creds });
  const state = new LocalState(cfg.paths.stateDir);
  const holds = state.holds();

  try {
    if (!(await adapter.ensureLoggedIn())) { say(`✗ 로그인이 안 돼 있다 — 먼저: npm run pair -- ${channel}`); return finish(1); }
    /* 상품 이름은 파트너센터에만 있다(매핑표에는 코드뿐이다). 사장님이 보는 화면의 이름과
       맞춰 보려면 이것이 있어야 한다 — "펜션 더블룸C 가 어느 방이냐" 가 이 명령의 절반이다. */
    const rooms = await adapter.listRooms().catch(() => []);
    const nameOf = new Map(rooms.map((r) => [String(r.roomKey), r.name]));
    const cells = await adapter.readAvailability({ from, to });
    const byKey = new Map();
    for (const c of cells) {
      if (!byKey.has(c.roomKey)) byKey.set(c.roomKey, new Map());
      byKey.get(c.roomKey).set(c.date, c.state);
    }

    for (const date of eachDate(from, to)) {
      say('');
      say(`## ${date}`);
      say(`  ${pad('우리 객실', 14)}${pad('여기어때 상품', 22)}${pad('원장', 8)}${pad('판매현황', 10)}판정`);
      for (const [resourceId, keys] of pairs) {
        for (const roomKey of keys) {
          const cell = (byKey.get(roomKey) || new Map()).get(date);
          const w = (want.get(resourceId) || new Set()).has(date);
          const rateClosed = (rate.get(resourceId) || new Set()).has(date);
          const j = judgeCell({
            want: w, rateClosed, cell,
            closedByUs: state.wasClosedByUs(channel, roomKey, date),
            held: heldOn(holds, channel, roomKey, date),
          });
          say(`  ${pad(label.forResource(resourceId), 14)}${pad(`${nameOf.get(String(roomKey)) || '?'}(${roomKey})`, 22)}` +
            `${pad(w ? (rateClosed ? '만실' : '예약') : '비었다', 8)}${pad(CELL_WORD[cell] || '없다', 10)}${j.verdict}`);
          say(`  ${' '.repeat(54)}→ ${j.next}`);
        }
      }
    }

    const unmapped = rooms.filter((r) => ![...pairs.values()].flat().some((k) => String(k) === String(r.roomKey)));
    if (unmapped.length) say(`\n매핑 안 된 채널 상품 ${unmapped.length}개 — ${unmapped.map((r) => `${r.name}(${r.roomKey})`).join(', ')} (이 상품들은 우리가 아예 안 건드린다)`);
    return finish(0);
  } catch (e) {
    say(`✗ ${scrubSecrets(e.message)}`);
    return finish(1);
  } finally {
    await session.close().catch(() => {});
  }
}

/* ★ 다른 CLI 와 **같은 방식**으로 검사한다. `import.meta.url` 은 URL(`file:///C:/...`)이고
   `process.argv[1]` 은 OS 경로(`C:\...`)라, 윈도우에서는 둘이 절대 같지 않아
   `왜.cmd`·`npm run why` 가 아무 말도 없이 끝났다(2026-09-18 검토). */
if (process.argv[1] && /cli[\\/]why\.js$/.test(process.argv[1])) {
  whyCli().then((c) => process.exit(c)).catch((e) => { console.error(scrubSecrets(e.message)); process.exit(1); });
}
