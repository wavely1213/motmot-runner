/* 채널 하나를 맡는 일꾼. 브라우저 하나, 작업은 줄 세워 하나씩(BR-011).
   주기: 생존 신호 → 객실 확인(드물게) → 유입 → 반영(할 일) → 캘린더 대조 → 요금. 새 할 일을 보면 반영을 앞당긴다.
   반영과 캘린더 대조는 둘 다 '방을 막는' 쪽이다 — 앞은 서버가 만든 할 일을 처리하고, 뒤는 원장을 직접 보고 차이를 메운다(D-008). */
import { redactSecret } from '../lib/log.js';
import { loadSpec } from '../adapters/spec.js';
import { JsonAdapter, NeedsHumanError, SessionYieldError } from '../adapters/json-adapter.js';
import { ChannelSession } from '../browser/session.js';
import { runInbound } from './inbound.js';
import { runOutbound } from './outbound.js';
import { runCalendar } from './calendar.js';
import { runRates } from './rates.js';
import { runRooms } from './rooms.js';
import { deadline, soft } from '../lib/deadline.js';
import { gapSince } from './state.js';

const RESTART_BROWSER_EVERY = 40;   // 작업 N번마다 브라우저를 새로 띄운다(메모리)
/* 사람이 필요한 상태(2단계 인증·페어링 안 됨)에서 다시 로그인해 보는 간격.
   매 주기(60초)마다 시도하면 파트너센터가 인증 문자를 계속 보내고 계정이 잠긴다. */
const RETRY_WHEN_PAUSED_MS = 15 * 60000;

export class NotPairedError extends Error {
  constructor(channel) { super(`${channel}: 파트너센터 로그인이 안 돼 있다 — npm run pair -- ${channel}`); this.name = 'NotPairedError'; this.channel = channel; }
}

export class ChannelWorker {
  /** @param {object} o { channel, cfg, dashboard, log, state, spec?, baseUrl?, playwright? } */
  constructor(o) {
    this.channel = o.channel;
    this.cfg = o.cfg;
    this.dashboard = o.dashboard;
    this.log = o.log.child ? o.log.child(o.channel) : o.log;
    this.state = o.state;
    this.spec = o.spec || loadSpec(o.channel);
    this.baseUrl = o.baseUrl || this.spec.baseUrl;
    this.session = new ChannelSession({
      channel: o.channel, stateDir: o.cfg.paths.stateDir, secret: o.cfg.stateSecret, headless: o.cfg.headless,
      browser: o.cfg.browser, log: this.log, playwright: o.playwright,
    });
    this.adapter = null;
    this.queue = Promise.resolve();
    this.pending = new Set();
    this.runs = 0;
    this.timers = [];
    this.stopped = false;
    this.paused = null;   // 사람이 필요한 상태면 이유
    /* 첫 설치 확인용 — 켜면 예약 목록을 읽어 서버가 읽는지까지만 보고 저장하지 않는다.
       상태 문구·객실명이 어긋난 채로 원장에 들어가는 것이 가장 되돌리기 어렵다. */
    this.previewOnly = !!o.previewOnly;
    this.lastResults = {};
    /* ★ 마지막으로 **무언가를 끝낸** 시각. 죽은 사람 스위치(main.js)가 이것만 본다.
         "살아 있다" 가 아니라 "나아가고 있다" 를 재야 한다 — 2026-09-14 에 프로세스는
         멀쩡히 살아 있으면서 76분 동안 한 칸도 못 끝냈다. */
    this.lastProgressAt = Date.now();
  }

  /* 칸마다 이만큼 안에는 끝나야 한다. 넘으면 그 판만 버리고 다음 판으로 간다.
     ★ 줄이 직렬이라 한 작업이 안 끝나면 **그 뒤 전부**가 안 돈다(2026-09-14, 76분).
       그래서 개별 호출의 시간제한과 별개로, 칸 단위로도 한 번 더 막아 둔다.
       숫자는 주기의 몇 배 — 죽은 사람 스위치(20분)보다는 짧아야 스스로 풀린다. */
  static DEADLINE_MS = { inbound: 300000, outbound: 300000, calendar: 480000, rooms: 300000, rates: 720000, heartbeat: 60000 };

  /** 같은 종류의 작업이 이미 줄에 있으면 또 넣지 않는다. */
  enqueue(kind, fn) {
    if (this.pending.has(kind)) return this.queue;
    this.pending.add(kind);
    const p = this.queue.then(async () => {
      this.pending.delete(kind);
      if (this.stopped) return null;
      try {
        return await deadline(fn(), ChannelWorker.DEADLINE_MS[kind] ?? 300000, `${kind} 한 판`);
      } catch (e) {
        // 사람을 기다리는 중이라는 것은 고장이 아니다 — 15분마다 한 줄씩만 남긴다
        if (e && e.pausedWaiting) this.log.debug(`${kind}: 사람을 기다리는 중`);
        else this.log.error(`${kind}: ${e.message}`);
        /* ★ 마감으로 버린 작업은 **배경에서 계속 돌고 있다** — 취소할 방법이 없다.
             그대로 두면 다음 판과 같은 브라우저를 놓고 다투다 둘 다 깨진다.
             그래서 브라우저를 닫아 버린다. 다음 판은 새로 띄우고 시작한다. */
        if (e && e.timedOut) await soft(this.session?.close?.(), 10000, null);
        return null;
      } finally {
        // 끝나기만 하면(성공이든 실패든) 나아간 것이다.
        this.lastProgressAt = Date.now();
      }
    });
    this.queue = p.catch(() => {});
    return p;
  }

  /** 브라우저를 열고 로그인을 확인한 뒤 fn(adapter) 를 돈다. 끝나면 세션 백업. */
  async withAdapter(fn) {
    /* ★ 콘솔에서 채널을 '멈춤' 으로 바꾸면 그때부터 파트너센터를 건드리지 않는다(BR-008).
         시작할 때 한 번만 보면, 사장님이 멈춘 뒤에도 계속 조작한다. */
    if (!(await this.isLive())) {
      const err = new Error(`${this.channel}: 계정 상태가 운영 중이 아니다`);
      err.pausedWaiting = true;
      throw err;
    }
    /* ★ 사람이 필요한 상태면 15분에 한 번만 다시 해 본다. 매 주기 시도하면 파트너센터가
         인증 문자를 계속 보내고 계정이 잠긴다. 사장님이 페어링을 다시 하면 자격증명 파일이
         새로 써지므로, 그 시각이 마지막 시도보다 나중이면 기다리지 않고 바로 다시 해 본다. */
    if (this.paused) {
      const since = Date.now() - (this.pausedRetryAt || 0);
      const repaired = this.session.credsChangedAfter(this.pausedRetryAt || 0);
      if (since < RETRY_WHEN_PAUSED_MS && !repaired) {
        const left = Math.ceil((RETRY_WHEN_PAUSED_MS - since) / 60000);
        this.log.debug(`사람이 필요한 상태 — ${left}분 뒤에 다시 해 본다`);
        const err = new NotPairedError(this.channel);
        err.pausedWaiting = true;
        throw err;
      }
      this.pausedRetryAt = Date.now();
    }
    if (this.runs > 0 && this.runs % RESTART_BROWSER_EVERY === 0) await this.session.close();
    /* ★ 브라우저가 아예 안 열리면(설치 안 됨·프로필 잠김·메모리 부족) 지금까지는 로그 한 줄만 남고
         생존 신호는 계속 초록이었다 — 콘솔에는 "정상" 인데 아무 일도 안 하는 상태다. 경보로 올린다. */
    let page;
    try {
      page = await this.session.open();
    } catch (e) {
      await this.needsHuman(`브라우저를 열지 못했다 — ${String(e.message).slice(0, 180)}`);
      throw e;
    }
    if (!this.adapter || this.adapter.page !== page) {
      /* 브라우저를 다시 열어도 "세션을 언제 빼앗겼나" 는 이어 간다 — 안 그러면 5분 비켜 주기가
         브라우저 재시작 때마다 처음부터 시작해 사장님을 계속 밀어낸다. */
      const lostAt = this.adapter?.sessionLostAt || 0;
      const wasIn = !!this.adapter?.wasLoggedIn;
      this.adapter = new JsonAdapter({
        spec: this.spec, page, log: this.log, baseUrl: this.baseUrl, artifactsDir: this.cfg.paths.artifactsDir, creds: this.session.loadCreds(),
        yieldMs: this.cfg.relogin?.yieldMs,
      });
      this.adapter.sessionLostAt = lostAt;
      this.adapter.wasLoggedIn = wasIn;
    }
    // 자격증명은 매번 다시 읽는다 — 사장님이 도는 중에 페어링을 다시 했을 수 있다
    this.adapter.creds = this.loadCreds();
    this.runs++;
    let loggedIn;
    try {
      loggedIn = await this.adapter.ensureLoggedIn();
    } catch (e) {
      /* 비켜 주는 중은 고장이 아니다 — 경보를 열지 않고, 사장님이 알아볼 수 있게 한 줄만 남긴다. */
      if (e instanceof SessionYieldError) { this.log.info(e.message); throw e; }
      if (e instanceof NeedsHumanError) { await this.needsHuman(e.message); throw e; }
      throw e;
    }
    if (!loggedIn) {
      const err = new NotPairedError(this.channel);
      await this.needsHuman(err.message);
      throw err;
    }
    if (this.paused) {
      this.paused = null;
      this.pausedRetryAt = 0;
      this.log.info('로그인이 돌아왔다 — 다시 돈다');
      await this.dashboard.resolveAlerts({ kind: 'sync_stale', channel: this.channel, source: 'worker' }).catch(() => 0);
    }
    try {
      return await fn(this.adapter);
    } finally {
      await this.session.saveStorage().catch(() => {});
    }
  }

  /** 자격증명을 읽고, 로그에 찍히지 않게 가림 목록에 넣는다.
      STATE_SECRET 이 바뀌면 여기서 던지는데, 그것을 삼키면 "생존 신호는 초록인데 아무 일도 안 함" 이 된다. */
  loadCreds() {
    try {
      const c = this.session.loadCreds();
      if (c) { redactSecret(c.password); redactSecret(c.loginId); }
      /* ★ 환경변수로 받은 자격증명이 있으면 그것이 기준이다 — **화면 없는 컨테이너에서 돌리기 위한 자리**다.
           `npm run pair` 는 사람이 브라우저로 들어가는 절차라 클라우드에서는 할 수 없다.
           봉인해 state/ 에 넣어 두면 그 뒤로는 자동 로그인이 알아서 쓴다. 로그에는 안 남는다. */
      const fromEnv = this.cfg.channelCreds && this.cfg.channelCreds[this.channel];
      if (fromEnv) {
        redactSecret(fromEnv.password); redactSecret(fromEnv.loginId);
        if (!c || c.loginId !== fromEnv.loginId || c.password !== fromEnv.password) {
          this.session.saveCreds(fromEnv);
          this.log.info(`파트너센터 자격증명을 환경변수에서 받아 봉인했다 — 페어링 없이 시작한다`);
          return this.session.loadCreds();
        }
      }
      return c;
    } catch (e) {
      this.needsHuman(`저장된 자격증명을 열지 못했다 — STATE_SECRET 이 바뀌었으면 npm run pair -- ${this.channel} --wipe (${e.message})`);
      return null;
    }
  }

  /** 콘솔의 채널 계정 상태(BR-008). 5분 캐시 — 운영 중에 '멈춤' 으로 바꾸면 그때 멈춘다. */
  async isLive(now = Date.now()) {
    if (this._accountsAt && now - this._accountsAt < 5 * 60000) return this._live;
    try {
      const rows = await this.dashboard.channelAccounts();
      const a = rows.find((x) => x.channel_code === this.channel);
      const live = !a || a.status === 'live';       // 줄이 없으면 다룬다(콘솔에 아직 안 넣은 것)
      if (this._accountsAt && live !== this._live) {
        this.log.info(live ? '계정 상태가 운영 중으로 바뀌었다 — 다시 돈다' : `계정 상태가 '${a.status}' 라 멈춘다`);
      }
      this._live = live;
      this._accountsAt = now;
      return live;
    } catch (e) {
      this.log.warn(`채널 계정 상태를 못 읽었다 — 하던 대로 간다 (${e.message})`);
      return this._live !== false;
    }
  }

  async needsHuman(reason) {
    if (this.paused === reason) return;
    this.paused = reason;
    this.pausedRetryAt = Date.now();
    this.log.warn(reason);
    await this.dashboard.openAlert({ kind: 'sync_stale', channel: this.channel, detail: { reason: reason.slice(0, 200), source: 'worker' } }).catch(() => {});
  }

  // ── 작업 ──
  /* ★ 생존 신호는 브라우저 큐에 세우지 않는다. 긴 요금 반영(수백 번 클릭) 뒤에 줄을 서면
       30분을 넘겨 콘솔이 "실행기 꺼짐" 으로 본다(BR-007). 대시보드 쓰기 한 번이라 병렬로 안전하다. */
  heartbeat() {
    /* ★ 살아 있다는 것을 이 PC 에도 적는다. 두 가지를 위해서다:
         1) 다음에 켤 때 '얼마나 비었나' 를 말한다(main.js).
         2) **깨어남을 잡는다** — PC 가 자면 프로세스는 그대로 있고 타이머만 안 돈다.
            그래서 화면은 '돌고 있습니다' 인데 실제로는 몇 시간을 아무것도 안 한다.
            30분을 기준으로 삼는다(이 자리는 5분에 한 번만 쓰므로 그만큼은 정상 여유다). */
    const gap = gapSince(this.state.lastAlive?.(), new Date(), 30 * 60000);
    if (gap) {
      this.log.warn(`이 PC 가 ${gap.text} 동안 아무것도 안 돌렸다(마지막 생존 ${gap.at})` +
        ' — 절전이거나 멈춰 있었다. 그 사이 들어온 예약·취소와 파트너센터 변화는 반영되지 않았다');
    }
    this.state.markAlive?.();
    return this.dashboard.heartbeat(this.channel).then((r) => {
      this.state.markHeartbeat?.(this.channel, true);
      return r;
    }).catch((e) => {
      /* 닿았는지를 적어 둔다 — 이 PC 가 도는 것과 콘솔이 그것을 아는 것은 다른 일이다(state.js). */
      this.state.markHeartbeat?.(this.channel, false, e.message);
      this.log.error(`생존 신호 실패 — ${e.message}`);
      return null;
    });
  }
  inbound(force = false) {
    /* 꺼 두면 아무것도 안 한다 — 첫 바퀴도 안 돈다. 끈 이유는 config.js 의 inboundOn 주석에. */
    if (this.cfg.dashboard?.inboundOn === false) {
      if (!this.saidInboundOff) { this.saidInboundOff = true; this.log.warn('유입은 꺼져 있다(.env 의 INBOUND=off) — 반영·캘린더·요금은 그대로 돈다'); }
      return Promise.resolve({ ok: true, skipped: '유입 꺼짐' });
    }
    return this.enqueue('inbound', () => this.withAdapter((adapter) =>
      runInbound({
        channel: this.channel, adapter, dashboard: this.dashboard, cfg: this.cfg, log: this.log,
        state: this.state, force, previewOnly: this.previewOnly,
      }).then((r) => (this.lastResults.inbound = r))));
  }
  outbound() {
    return this.enqueue('outbound', async () => {
      // 할 일이 없으면 브라우저를 열지 않는다
      const todos = await this.dashboard.openTodos(this.channel).catch((e) => { this.log.error(e.message); return null; });
      if (todos && !todos.length) {
        await this.dashboard.recordRun({ channel: this.channel, kind: 'outbound', startedAt: new Date(), ok: true, detail: { todos: 0 } }).catch(() => {});
        return (this.lastResults.outbound = { ok: true, done: 0, cleaned: 0, failed: 0, skipped: 0, unmapped: [] });
      }
      return this.withAdapter((adapter) =>
        runOutbound({ channel: this.channel, adapter, dashboard: this.dashboard, log: this.log, state: this.state,
        notSold: this.cfg.notSold?.[this.channel] || [] })
          .then((r) => (this.lastResults.outbound = r)));
    });
  }
  /* 대시보드 캘린더를 파트너센터에 맞춘다 — 사람이 아무것도 안 눌러도 도는 쪽(요구 1·2의 닫는 고리). */
  calendar() {
    if (!this.cfg.calendar?.enabled) return Promise.resolve((this.lastResults.calendar = { ok: true, closed: 0, opened: 0, rooms: 0, skipped: '꺼짐(CALENDAR_SYNC=false)' }));
    return this.enqueue('calendar', () => this.withAdapter((adapter) =>
      runCalendar({ channel: this.channel, adapter, dashboard: this.dashboard, log: this.log, state: this.state, cfg: this.cfg })
        .then((r) => (this.lastResults.calendar = r))));
  }
  rates() {
    return this.enqueue('rates', () => this.withAdapter((adapter) =>
      runRates({
        channel: this.channel, adapter, dashboard: this.dashboard, log: this.log, state: this.state,
        horizonDays: this.cfg.rates?.horizonDays ?? 180, budget: this.cfg.rates?.budgetPerPass ?? 200,
      })
        .then((r) => (this.lastResults.rates = r))));
  }
  rooms() {
    return this.enqueue('rooms', () => this.withAdapter((adapter) =>
      runRooms({ channel: this.channel, adapter, dashboard: this.dashboard, log: this.log, state: this.state, autoMapExact: !!this.cfg.rooms?.autoMapExact })
        .then((r) => (this.lastResults.rooms = r))));
  }

  /** 지금 다섯 칸이 어떤지 한 줄로. 사람이 로그에서 읽고, 리모컨 화면이 이 줄을 본다.
   *
   * ★ 상주는 칸마다 주기가 달라서(유입 2분·반영 1분·요금 15분) "한 바퀴" 라는 것이 없다.
   *   그래서 --once 의 요약 줄이 상주 로그에는 영영 안 나온다 — 리모컨이 "아직 한 바퀴를
   *   못 돌았습니다" 를 계속 보여 준 까닭이다(2026-09-14). 아직 차례가 안 온 칸은
   *   '못 돎' 이 아니라 '대기' 다. 그 둘을 섞으면 멀쩡한 것을 고장으로 읽는다. */
  statusLine(kinds = ['rooms', 'inbound', 'outbound', 'calendar', 'rates']) {
    const r = this.lastResults || {};
    return kinds.map((k) => {
      const v = r[k];
      if (v === undefined) return `${k}:대기`;
      if (!v) return `${k}:못 돎`;
      return `${k}:${v.ok === false ? '실패' : '정상'}`;
    }).join(' ');
  }

  /** 한 바퀴 — --once 와 시작 직후에 쓴다. */
  async cycle() {
    await this.heartbeat();
    await this.rooms();
    await this.inbound();
    /* 미리보기 모드는 읽기만 한다 — 파트너센터를 건드리는 반영·요금은 돌리지 않는다.
       설치 확인이 목적인데 잘못된 매핑으로 방을 막아 버리면 그게 사고다. */
    if (this.previewOnly) {
      this.log.info('미리보기 모드 — 반영·요금은 돌리지 않는다');
      return this.lastResults;
    }
    await this.outbound();
    await this.calendar();
    await this.rates();
    return this.lastResults;
  }

  start() {
    const iv = this.cfg.intervals;
    /* ★ unref() 하지 않는다. 전부 unref 면 이벤트 루프를 잡아 주는 것이 브라우저 자식 프로세스뿐이라,
         브라우저가 죽는 순간 실행기가 로그 한 줄 없이 정상 종료(코드 0)로 사라진다. 실측으로 확인했다.
         정지는 stop() 이 clearInterval 로 한다. */
    const every = (sec, fn) => {
      this.timers.push(setInterval(() => { if (!this.stopped) fn(); }, sec * 1000));
    };
    every(iv.heartbeatSec, () => this.heartbeat());
    every(iv.inboundSec, () => this.inbound());
    every(iv.outboundSec, () => this.outbound());
    every(iv.calendarSec, () => this.calendar());
    every(iv.ratesSec, () => this.rates());
    every(6 * 3600, () => this.rooms());
    this.cycle();
  }

  async stop() {
    this.stopped = true;
    for (const t of this.timers) clearInterval(t);
    /* 멈춘 줄을 무한정 기다리지 않는다 — 멈춘 한 판이 곧 멈춘 프로세스가 된다.
       두고 가도 된다: 어차피 이 프로세스는 곧 끝나고, 다음 판이 처음부터 다시 읽는다. */
    await soft(this.queue, 10000, null);
    await soft(this.session.close(), 10000, null);
  }
}
