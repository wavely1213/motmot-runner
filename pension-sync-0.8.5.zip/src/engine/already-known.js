/* 이미 원장에 있는 예약은 다시 안 보낸다 — **새 예약만** 보낸다.

   왜 (2026-09-11 실계정):
     대시보드는 `bookings`(원장)와 `ota_reservations`(채널에서 받은 것)를 **같은 예약으로 안 묶는다.**
     그래서 이미 원장에 있는 예약을 우리가 또 보내면 점유가 둘로 세어져, 실제 예약마다
     오버부킹 경보가 뜬다. 방이 실제로 겹친 건 아니지만 **사장님이 캘린더를 못 믿게 된다.**

     그렇다고 유입을 끄면 이 프로그램의 존재 이유가 없어진다. 새로 들어온 예약을 잡는 것이 본업이다.
     그래서 **가려서 보낸다** — 원장에 이미 있는 것은 빼고, 새 것만.

   ★ 취소는 예외다. 원장에 있어도 **취소는 보내야** 대시보드가 그 밤을 다시 열 수 있다.
     "이미 아는 예약" 이라고 취소를 빼면, 손님이 취소한 밤을 우리가 계속 막아 두게 된다. */

/** 원장 한 줄에서 채널 예약번호를 찾는다. 열 이름을 모르므로 줄 전체 글자에서 찾는다.
    (대시보드는 메모에 "채널 예약 자동 반영 (yeogi · 260908130174E6YE1)" 처럼 적어 둔다.) */
export function knownNosFrom(rows, nos) {
  const found = new Set();
  if (!Array.isArray(rows) || !nos.length) return found;
  for (const row of rows) {
    let text;
    try { text = JSON.stringify(row); } catch { continue; }
    for (const no of nos) if (no && text.includes(no)) found.add(no);
  }
  return found;
}

/**
 * 원장 줄이 이 예약과 **같은 예약인가** — 번호가 없을 때의 두 번째 잣대(기본으로는 안 쓴다).
 *
 * ★ 2026-09-11 실측: 번호로만 맞추면 덜 걸러진다. 원장 줄 중에는 여기어때 번호가 안 적힌 것이
 *   섞여 있었다(만든 경로가 달랐다). 그래서 **입실·퇴실 날짜가 같고 예약자 이름이 그 줄 어딘가에
 *   있으면** 같은 예약으로 보는 길을 뒀다. 객실은 안 본다 — 사장님이 방을 옮겨 둔 예약이 있다.
 *
 * ★★ 2026-09-15: 이 잣대가 **위험하다**는 것이 실제로 드러났다. 같은 손님이 같은 날짜로 방을
 *   여러 개 잡으면(가족·단체) 원장에 한 줄만 있어도 셋 다 "이미 있다"로 걸러져, 나머지 방은
 *   빈 것으로 남아 그 날 또 팔린다 — 오버부킹이다. 그래서 두 가지를 바꿨다:
 *     1) 기본 잣대는 **예약번호**다(DUPE_MATCH=no). 번호가 다르면 다른 예약이다.
 *     2) 이름·날짜 잣대를 켠 판(DUPE_MATCH=stay)에서도 **원장 한 줄은 예약 하나만 흡수한다.**
 *        줄이 하나뿐이면 둘째·셋째는 새 예약으로 보낸다.
 *
 *   이름은 **비교만 하고 어디에도 안 남긴다**(로그·기록물 어디에도 안 찍는다).
 */
export function sameStay(row, cols, item) {
  if (!cols || !cols.checkIn || !cols.checkOut) return false;
  const day = (v) => String(v ?? '').slice(0, 10);
  if (day(row[cols.checkIn]) !== day(item.checkIn)) return false;
  if (day(row[cols.checkOut]) !== day(item.checkOut)) return false;
  const name = String(item.guestName || '').replace(/\s+/g, '');
  if (name.length < 2) return false;                 // 한 글자 이름으로 맞추지 않는다
  let text;
  try { text = JSON.stringify(row).replace(/\s+/g, ''); } catch { return false; }
  return text.includes(name);
}

/**
 * 보낼 것을 가린다.
 * @param {object[]} items 파트너센터에서 읽은 예약
 * @param {Set<string>} known 원장에서 찾은 예약번호
 * @param {(s:any)=>string} normalize 상태를 우리 말로 옮기는 함수
 * @param {{rows?:object[], cols?:object|null, matchBy?:'no'|'stay'}} [opt]
 *        matchBy: 'no' = 예약번호만으로 중복을 본다(기본). 'stay' = 번호에 더해 이름·날짜도 본다.
 * @returns {{send:object[], skipped:object[]}}
 */
const rowHasNo = (row, no) => {
  try { return JSON.stringify(row).includes(no); } catch { return false; }
};

export function pickToSend(items, known, normalize, { rows = [], cols = null, matchBy = 'no' } = {}) {
  const send = [], skipped = [];
  /* ★ 이름·날짜로 맞출 때 **원장 한 줄은 한 번만 쓴다.** 안 그러면 같은 이름·같은 날짜의
       예약 셋이 줄 하나에 모두 걸려, 둘은 원장에 영영 안 들어간다(그 방이 다시 팔린다). */
  const used = new Set();
  for (const it of items) {
    const no = String(it.reservationNo ?? '');
    const cancelled = normalize(it.status) === '예약취소';
    /* 취소는 원장에 있어도 보낸다 — 안 보내면 취소된 밤을 계속 막아 둔다. */
    if (cancelled) { send.push(it); continue; }
    if (no && known.has(no)) {
      /* 번호로 뺀 예약은 **자기 줄을 먹는다** — 그 줄이 남아 있으면 같은 이름·날짜의 다른 방
         예약이 그 줄에 걸려 안 보내진다. 자기 번호가 적힌 줄만 쓴다(없으면 아무 줄도 안 쓴다). */
      if (matchBy === 'stay') {
        const mine = rows.findIndex((r, i) => !used.has(i) && rowHasNo(r, no));
        if (mine >= 0) used.add(mine);
      }
      skipped.push(it);
      continue;
    }
    if (matchBy !== 'stay') { send.push(it); continue; }
    const hit = rows.findIndex((r, i) => !used.has(i) && sameStay(r, cols, it));
    if (hit >= 0) { used.add(hit); skipped.push(it); }
    else send.push(it);
  }
  return { send, skipped };
}

/* 보낼 것을 **취소와 새 예약으로 갈라 센다.**

   왜 (2026-09-17 소유자 로그): 매 주기 "새 예약·취소 6건만 보낸다" 가 똑같이 반복됐다.
   그런데 그 줄만으로는 **정상인지 고장인지 갈리지 않는다** —
     취소라면 정상이다. 취소는 원장에 있어도 늘 보낸다(위 머리말).
     새 예약이라면 고장이다. 한 번 보냈으면 다음 주기엔 원장에서 번호로 걸러져야 하는데,
     계속 나간다는 것은 **원장에 안 앉고 있다**는 뜻이다(2분마다 같은 예약을 다시 꽂는다).
   번호는 주문 식별자라 이름·연락처와 달리 개인정보가 아니므로 눈으로 맞춰 볼 수 있게 찍는다. */
export function sendBreakdown(items = [], normalize = () => '') {
  const cancelled = [], fresh = [];
  for (const it of items) (normalize(it.status) === '예약취소' ? cancelled : fresh).push(String(it.reservationNo ?? ''));
  return { cancelled: cancelled.length, fresh: fresh.length, freshNos: fresh.filter(Boolean) };
}

/** 위 갈라 센 것을 로그 한 조각으로. */
export function breakdownText(b) {
  const head = `취소 ${b.cancelled}건(원장에 있어도 늘 보낸다) · 새 예약 ${b.fresh}건`;
  if (!b.freshNos.length) return head;
  const shown = b.freshNos.slice(0, 5).join(', ');
  return `${head}: ${shown}${b.freshNos.length > 5 ? ` 외 ${b.freshNos.length - 5}건` : ''}` +
    ' ← 다음 주기에도 같은 번호가 나오면 원장에 안 앉고 있는 것이다';
}
