/* 반영 — 대시보드가 만든 "손으로 막아야 할 것" 을 파트너센터에서 대신 한다 (요구 2: 품절 처리 동기화, 요구 1의 차단 방향).
   할 일(manual_close_todos) 하나 = 채널·객실·기간·막기/열기. 처리하면 op=todo_done (BR-003).
   지난 날짜는 파트너센터에서도 못 막으니 실행 없이 정리만 한다(BR-005). 같은 할 일을 계속 실패하면 셋째부터는 경보만 남긴다. */
import { eachDate, isPastRange, todayKst } from '../lib/kst.js';
import { forDashboard } from '../lib/log.js';
import { NeedsHumanError, SKIP_NOT_FOUND } from '../adapters/json-adapter.js';
import { loadRoomLabels } from './room-label.js';

const MAX_ATTEMPTS = 3;
/* 3회 실패한 할 일도 한 시간 뒤에는 다시 해 본다 — 파트너센터가 잠깐 흔들린 것을
   영구 포기로 굳히면 그 방은 계속 팔린다(BR-006). */
const RETRY_COOLDOWN_MS = 60 * 60000;

/**
 * @returns {Promise<{ok:boolean, done:number, cleaned:number, failed:number, skipped:number, unmapped:string[]}>}
 */
export async function runOutbound({ channel, adapter, dashboard, log, state, now = new Date(), notSold = [] }) {
  const startedAt = now;
  const today = todayKst(now);
  const out = { ok: true, done: 0, cleaned: 0, failed: 0, skipped: 0, unmapped: [] };
  try {
    const todos = await dashboard.openTodos(channel);
    if (!todos.length) {
      await dashboard.recordRun({ channel, kind: 'outbound', startedAt, finishedAt: new Date(), ok: true, detail: { todos: 0 } });
      return out;
    }
    /* ★ 한 객실(resource)에 채널 상품이 여럿 붙어 있을 수 있다(같은 방을 여러 상품으로 파는 경우).
         Map 으로 덮어쓰면 마지막 하나만 막고 나머지는 계속 팔린다 — 전부 모아 둔다. */
    /* 안 파는 객실은 사장님이 **이름**으로 적어 둔다(id 를 외울 수 없다). 이름 → id 로 푼다. */
    const skipRooms = new Set(notSold);
    if (notSold.length && dashboard.resources) {
      const norm = (x) => String(x || '').replace(/\s+/g, '').toLowerCase();
      const wanted = new Set(notSold.map(norm));
      for (const r of await dashboard.resources().catch(() => [])) {
        if (wanted.has(norm(r.name)) || wanted.has(norm(r.code)) || wanted.has(norm(r.id))) skipRooms.add(r.id);
      }
    }
    const map = new Map();
    for (const m of await dashboard.roomMap(channel)) {
      if (!map.has(m.resource_id)) map.set(m.resource_id, []);
      map.get(m.resource_id).push(m.channel_room_key);
    }
    /* 보여 줄 때만 이름으로 바꾼다 — 일은 그대로 코드로 한다(room-label.js 머리말). */
    const label = await loadRoomLabels(dashboard, map);
    for (const todo of todos) {
      // 지난 것 정리 — 콘솔의 "지난 것 정리" 와 같은 규칙
      if (isPastRange(todo.to_date, today)) {
        const r = await dashboard.todoDone(todo.id);
        if (r && r.ok) { out.cleaned++; state.markTodoDone(todo.id); }
        continue;
      }
      const roomKeys = map.get(todo.resource_id);
      if (!roomKeys || !roomKeys.length) {
        /* ★ 그 채널에 **아예 안 올린 객실**은 매핑이 없는 것이 정상이다 — 영영 안 고쳐질 줄을
             주기마다 알리면 진짜 미매핑이 생겨도 묻힌다(2026-09-11 소유자 요청).
             할 일 자체는 그대로 둔다 — 날짜가 지나면 위의 '지난 것 정리' 가 알아서 닫는다. */
        if (!skipRooms.has(todo.resource_id)) out.unmapped.push(todo.resource_id);
        continue;
      }
      const mem = state.todoAfterCooldown(todo.id, RETRY_COOLDOWN_MS, now.getTime());
      if (mem.attempts >= MAX_ATTEMPTS) { out.skipped++; continue; }
      const dates = eachDate(todo.from_date, todo.to_date).filter((d) => d >= today);
      const closed = todo.action !== 'open';
      try {
        let applied = 0;
        const skipped = [];
        for (const roomKey of roomKeys) {
          const r = await adapter.setClosed({ roomKey, dates, closed });
          applied += r.applied;
          skipped.push(...r.skipped);
          /* ★ 우리가 막은 날은 반드시 기억해 둔다. 캘린더 대조는 이 기억(wasClosedByUs)이 있는 날만
               다시 연다 — 여기서 안 남기면 할 일로 막은 밤은 예약이 취소돼도 영영 막힌 채로 남는다.
               실제로 그렇게 남은 밤이 있었다(2026-09-25 펜션202). 못 찾은 날은 기억하지 않는다. */
          const took = dates.filter((d) => !r.skipped.some((k) => k.date === d && k.why === SKIP_NOT_FOUND));
          if (closed) state.markClosedByUs(channel, roomKey, took);
          else state.forgetClosedByUs(channel, roomKey, took);
          /* ★ 한 날도 못 찾았으면 완료로 닫지 않는다. 닫아 버리면 대시보드는 "막았다" 고 보고
               서버 크론도 같은 할 일을 다시 만들지 않는데, 파트너센터는 그대로 팔고 있다 → 오버부킹. */
          const notFound = r.skipped.filter((s) => s.why === SKIP_NOT_FOUND);
          if (notFound.length === dates.length && dates.length > 0) {
            throw new Error(`파트너센터에서 ${roomKey} 의 ${notFound.length}일을 찾지 못했다 — 객실 매핑이나 화면 구조를 확인할 것`);
          }
        }
        const done = await dashboard.todoDone(todo.id);
        if (!done || !done.ok) throw new Error(`todo_done 실패: ${(done && done.error) || '응답 오류'}`);
        state.markTodoDone(todo.id);
        out.done++;
        /* 화면의 '방금 한 일' 목록 — 대시보드 → 여기어때 방향(이 PC 에만 남는다, state.js 머리말). */
        if (applied) {
          state.addRecentOutbound?.(channel, roomKeys.map((k) => (
            { roomName: label.forKey(k), dates, action: closed ? '품절처리' : '다시 열기' })));
        }
        log.info(`${channel}: ${roomKeys.map((k) => label.both(k)).join('·')} ${todo.from_date}~${todo.to_date} ${closed ? '마감' : '재개'} — 실행 ${applied}일` +
          (skipped.length ? `, 건너뜀 ${skipped.length}일(${skipped.map((s) => s.why).filter((v, i, a) => a.indexOf(v) === i).join('·')})` : ''));
      } catch (e) {
        if (e instanceof NeedsHumanError) throw e;
        state.markTodoAttempt(todo.id, e.message);
        out.failed++;
        log.error(`${channel}: 할 일 ${todo.id}(${roomKeys.map((k) => label.both(k)).join('·')} ${todo.from_date}~${todo.to_date}) 실패 ${state.todo(todo.id).attempts}회 — ${e.message}`);
        if (state.todo(todo.id).attempts >= MAX_ATTEMPTS) {
          await dashboard.openAlert({ kind: 'sync_stale', channel, resourceId: todo.resource_id, onDate: todo.from_date,
            detail: { reason: `${closed ? '마감' : '재개'}을 ${MAX_ATTEMPTS}번 실패 — 파트너센터에서 직접 확인`, todoId: todo.id, source: 'outbound' } }).catch(() => {});
        }
      }
    }
    if (out.unmapped.length) {
      const uniq = [...new Set(out.unmapped)].sort();
      /* ★ 이 줄은 **영영 안 바뀔 수 있다** — OTA 에 아예 안 올린 객실이면 매핑이 없는 것이 정상이다
           (2026-09-11 소유자 확인). 그런 줄을 1~2분마다 내면 진짜 미매핑이 생겼을 때 묻힌다.
           집합이 바뀔 때만 알린다. 경보(openAlert)도 같은 규칙으로 — 콘솔이 같은 카드를 계속 되살리면
           사장님이 카드를 통째로 무시하게 된다. */
      if (!state.saidBefore(`unmapped:${channel}`, uniq.join(','))) {
        log.warn(`${channel}: 객실 매핑이 없어 못 막는 할 일 — ${uniq.join(', ')}` +
          ' (콘솔 채널 탭에서 매핑할 것. 그 채널에 안 올린 객실이면 이대로 두면 된다)');
        for (const rid of uniq) {
          await dashboard.openAlert({ kind: 'unmapped', channel, resourceId: rid, detail: { roomKey: rid, direction: 'outbound', source: 'outbound' } }).catch(() => {});
        }
      }
    }
    /* ★ 미매핑 경보는 한 번 열리면 스스로 안 닫힌다. 매핑을 넣거나 "안 파는 객실" 로 적어 둔
         뒤에도 카드가 콘솔에 그대로 남아, 사장님은 고쳐도 안 고쳐진 것으로 본다.
         지금도 미매핑인 것만 남기고 나머지는 닫는다. */
    await dashboard.resolveAlerts({ kind: 'unmapped', channel, source: 'outbound', keep: new Set(out.unmapped) })
      .catch(() => 0);
    out.ok = out.failed === 0;
    await dashboard.recordRun({ channel, kind: 'outbound', startedAt, finishedAt: new Date(), ok: out.ok,
      detail: { todos: todos.length, done: out.done, cleaned: out.cleaned, failed: out.failed, unmapped: out.unmapped.length } });
    return out;
  } catch (e) {
    const human = e instanceof NeedsHumanError;
    log.error(`${channel}: 반영 실패 — ${e.message}`);
    await dashboard.recordRun({ channel, kind: 'outbound', startedAt, finishedAt: new Date(), ok: false, detail: { error: String(e.message).slice(0, 300) } }).catch(() => {});
    await dashboard.openAlert({ kind: 'sync_stale', channel, detail: { reason: human ? '2단계 인증 필요 — 페어링 다시' : forDashboard(e.message), source: 'outbound' } }).catch(() => {});
    return { ...out, ok: false, error: e.message, needsHuman: human };
  }
}
