/* 실행기의 로컬 기억(state/executor-state.json) — 재시작해도 이어져야 하는 것만 둔다.
   · 유입: 마지막으로 서버에 저장한 목록의 해시(같으면 다시 안 보낸다)
   · 반영: 할 일별 시도 횟수·마지막 오류(무한 재시도 방지), 요금별 마지막 반영값(같으면 안 누른다)
   비밀값은 여기 없다(그건 browser/session 의 몫). */
import fs from 'node:fs';
import path from 'node:path';

export class LocalState {
  constructor(stateDir, { file = 'executor-state.json' } = {}) {
    this.file = path.join(stateDir, file);
    this.data = { inbound: {}, todos: {}, rates: {}, closedByUs: {}, meta: {} };
    this.load();
  }
  load() {
    try {
      if (fs.existsSync(this.file)) this.data = { ...this.data, ...JSON.parse(fs.readFileSync(this.file, 'utf8')) };
    } catch (e) {
      // 깨진 파일은 옆에 치우고 새로 시작한다 — 실행기가 멈추는 것보다 낫다
      fs.renameSync(this.file, this.file + '.broken-' + Date.now());
    }
  }
  save() {
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    const tmp = this.file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(this.data, null, 1));
    fs.renameSync(tmp, this.file);
  }

  // ── 유입 ──
  lastInbound(channel) { return this.data.inbound[channel] || null; }

  setInbound(channel, rec) { this.data.inbound[channel] = { ...rec, at: new Date().toISOString() }; this.save(); }

  /* ── 방금 한 일 (화면에 보여 주려고만 남긴다) ──
     두 방향을 한 목록에 담는다:
       in  여기어때 → 대시보드   새 예약·취소를 원장에 넣었다
       out 대시보드 → 여기어때   그 날 그 방을 품절(마감)·재개했다
     ★ **executor-state.json 과 다른 파일**에 둔다. 그 파일은 클라우드 상태(D-021)로 올라가는데,
       여기에는 예약자 이름이 들어 있다 — 손님 정보를 서버로 올리지 않는다. 이 파일은 이 PC 에만 있다.
     ★ 로그에도 안 쓴다. 로그는 보고서가 되어 밖으로 나가지만, 이 파일은 화면이 읽을 뿐이다. */
  recentFile() { return path.join(path.dirname(this.file), 'recent-activity.json'); }
  recentActivity() {
    try {
      const rows = JSON.parse(fs.readFileSync(this.recentFile(), 'utf8'));
      return Array.isArray(rows) ? rows : [];
    } catch { return []; }
  }
  /** 같은 일이 또 오면 새 것만 남긴다 — 목록이 같은 줄로 불어나지 않게. */
  #pushRecent(rows, keep) {
    if (!rows.length) return;
    const key = (r) => [r.dir, r.channel, r.reservationNo || '', r.roomName || '', r.checkIn || '', r.checkOut || '', r.action || ''].join('|');
    const old = this.recentActivity();
    /* ★ 같은 일이 또 오면 새 것만 남기되 **몇 번째인지는 센다.** 합치기만 하면 화면에서
         "한 번 있었던 일" 과 "5분마다 되풀이되는 일" 이 똑같아 보인다 — 2026-09-15 에 사장님이
         막았다 열었다 하는 줄을 보고 물으셨는데, 목록이 그 구분을 못 해 줬다. */
    const before = new Map(old.map((r) => [key(r), r.n || 1]));
    const counted = rows.map((r) => ({ ...r, n: (before.get(key(r)) || 0) + 1 }));
    const seen = new Set(counted.map(key));
    const next = [...counted, ...old.filter((r) => !seen.has(key(r)))].slice(0, keep);
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      const tmp = this.recentFile() + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(next, null, 1), { mode: 0o600 });
      fs.renameSync(tmp, this.recentFile());
    } catch { /* 화면에 보여 주려는 것뿐이다 — 못 써도 실행기를 멈추지 않는다 */ }
  }
  /* ── 옛 줄도 이름으로 고쳐 준다 ──
     이름은 **적힐 때** 붙는다. 그래서 새 판을 깔아도 이미 적혀 있던 줄은 코드(621393) 그대로 남았다
     (2026-09-16 소유자: "안바뀌어 있는데"). 새 판이 코드→이름을 알게 됐으면 옛 줄도 같이 고친다.
     `toName` 은 모르는 글자를 **그대로 돌려줘야** 한다 — 이미 이름인 줄을 건드리지 않게. */
  relabelRecent(toName) {
    if (typeof toName !== 'function') return 0;
    const rows = this.recentActivity();
    if (!rows.length) return 0;
    let changed = 0;
    const next = rows.map((r) => {
      const name = String(toName(r.roomName) ?? r.roomName);
      if (!name || name === r.roomName) return r;
      changed++;
      return { ...r, roomName: name };
    });
    if (!changed) return 0;
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      const tmp = this.recentFile() + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(next, null, 1), { mode: 0o600 });
      fs.renameSync(tmp, this.recentFile());
    } catch { return 0; }
    return changed;
  }

  /** 여기어때 → 대시보드. 원장에 넣은 예약들. */
  addRecentInbound(channel, items, { keep = 50, at = new Date() } = {}) {
    if (!Array.isArray(items) || !items.length) return;
    this.#pushRecent(items.map((it) => ({
      dir: 'in',
      channel,
      at: at.toISOString(),
      reservationNo: String(it.reservationNo ?? ''),
      roomName: String(it.roomName ?? ''),
      checkIn: String(it.checkIn ?? ''),
      checkOut: String(it.checkOut ?? ''),
      guestName: String(it.guestName ?? ''),
      status: String(it.status ?? ''),
      amount: it.amount == null ? null : it.amount,
      settleAmount: it.settleAmount == null ? null : it.settleAmount,
    })), keep);
  }
  /** 대시보드 → 여기어때. 그 방 그 날을 품절로 걸었다/풀었다.
      ★ `dates` 는 **실제로 건드린 날들**이다. 첫 날·끝 날만 남기면 띄엄띄엄한 날이 기간처럼 보인다
        (2026-09-15: '09-19 ~ 09-20' 이 이틀인지 두 날인지 화면에서 알 수가 없었다). 며칠인지도 남긴다. */
  addRecentOutbound(channel, moves, { keep = 50, at = new Date() } = {}) {
    if (!Array.isArray(moves) || !moves.length) return;
    this.#pushRecent(moves.map((m) => {
      const dates = Array.isArray(m.dates) ? [...m.dates].sort() : [];
      return {
        dir: 'out',
        channel,
        at: at.toISOString(),
        roomName: String(m.roomName ?? m.roomKey ?? ''),
        /* 그 날을 막게 한 예약자. 화면에만 쓴다 — 없으면 빈칸이다(다시 열기는 그 예약이 사라진 뒤라 모른다). */
        guestName: String(m.guestName ?? ''),
        checkIn: String(dates[0] ?? m.from ?? m.checkIn ?? ''),
        checkOut: String(dates[dates.length - 1] ?? m.to ?? m.checkOut ?? ''),
        days: dates.length || undefined,
        action: String(m.action ?? ''),
      };
    }), keep);
  }

  /* ── 되풀이 알림 줄이기 ──
     상주로 24시간 돌면 **영영 안 고쳐질 것**을 주기마다 알리게 된다. 예: OTA 에 아예 안 올린
     객실은 매핑이 없는 것이 정상인데, 그것을 1~2분마다 경고로 내면 진짜 미매핑이 생겼을 때
     묻힌다. 같은 내용이면 넘기고, **집합이 바뀔 때만** 다시 알린다. */
  saidBefore(topic, text) {
    this.data.meta.said = this.data.meta.said || {};
    if (this.data.meta.said[topic] === text) return true;
    this.data.meta.said[topic] = text;
    this.save();
    return false;
  }

  /* ── 마지막으로 살아 있던 시각 ─────────────────────────────
     왜 (2026-09-17 소유자: "작동을 멈췄다고 2일 동안 알림이 떴었음"):
     실행기가 멈추면 콘솔이 경보를 띄운다. 그런데 **다시 켠 뒤에는 그 사실이 어디에도 안 남는다** —
     로그는 켠 시점부터 시작하므로, 얼마나 비었는지도, 그 사이 무엇을 놓쳤는지도 알 수가 없다.
     그래서 살아 있는 동안 시각을 적어 두고, 켤 때 그 공백을 한 줄로 말한다.
     ★ 5분에 한 번만 쓴다 — 생존 신호는 기본 5분마다 도는데 그때마다 파일을 쓸 이유가 없다.
     ★★ **못 써도 던지지 않는다.** 이 자리는 대시보드로 생존 신호를 보내기 **직전**이라,
        여기서 던지면 신호가 아예 안 나가 콘솔이 '작동을 멈췄다' 로 본다 — 이 커밋이 없애려던
        바로 그 증상이다(디스크 꽉 참·권한·백신이 파일을 잡고 있는 경우, 2026-09-18 검토). */
  markAlive(now = new Date()) {
    const prev = this.data.meta.lastAlive;
    /* 시계가 뒤로 갔거나(시간 동기화) 앞선 값이 적혀 있으면 **다시 쓴다** — 안 그러면
       미래 시각에 얼어붙어 화면이 영영 안 바뀐다. */
    const since = prev ? now - new Date(prev) : Infinity;
    if (prev && since >= 0 && since < 5 * 60000) return false;
    this.data.meta.lastAlive = now.toISOString();
    return this.#saveQuietly();
  }
  lastAlive() { return this.data.meta.lastAlive || null; }

  /* 생존 신호가 **대시보드에 닿았나.** 이 PC 가 도는 것과 콘솔이 그것을 아는 것은 다른 일이다 —
     2026-09-17 소유자: 실행기는 "돌고 있습니다" 인데 콘솔은 이틀째 "작동을 멈췄다" 였다.
     닿았는지를 여기에 적어 두면 실행기 화면이 둘을 갈라 보여 줄 수 있다.
     ★ 결과가 바뀔 때는 바로, 같으면 5분에 한 번만 쓴다(1분마다 도는 자리라 파일을 계속 쓸 이유가 없다). */
  markHeartbeat(channel, ok, why = '', now = new Date()) {
    /* ★ **채널마다 따로 적는다.** 대시보드의 생존 신호도 채널별 줄이다(agent_heartbeats 는
       property_id + channel_code 로 유일하다). 한 칸에 몰아 쓰면 여기어때가 거절당해도
       야놀자가 성공하면서 그것을 덮어, 화면이 '대시보드 받음' 이라고 거짓말한다(2026-09-18 검토). */
    const all = (this.data.meta.heartbeats && typeof this.data.meta.heartbeats === 'object') ? this.data.meta.heartbeats : {};
    const key = String(channel || 'default');
    const prev = all[key];
    const since = prev ? now - new Date(prev.at) : Infinity;
    const same = prev && prev.ok === !!ok && since >= 0 && since < 5 * 60000;
    if (same) return false;
    all[key] = { at: now.toISOString(), ok: !!ok, why: ok ? '' : String(why || '').slice(0, 200) };
    this.data.meta.heartbeats = all;
    /* ★ **옛 판 실행기 화면도 읽을 수 있게** 한 칸짜리(meta.heartbeat)를 함께 남긴다.
       exe 는 돌고 있는 동안 덮어쓸 수 없어서, `src/` 만 새것이고 화면은 옛것인 상태가
       실제로 생긴다(2026-09-18: 그 조합에서 멀쩡한 신호가 '대시보드가 거절' 로 보였다).
       한 칸에는 **가장 나쁜 것**을 둔다 — 하나라도 안 닿았으면 안 닿은 것이다. */
    this.data.meta.heartbeat = worstOf(all);
    return this.#saveQuietly();
  }
  lastHeartbeat(channel) {
    const many = this.data.meta.heartbeats;
    if (many && channel && many[String(channel)]) return many[String(channel)];
    if (many && !channel) return worstOf(many);
    return this.data.meta.heartbeat || null;               // 옛 판이 남긴 한 칸짜리
  }

  /* 저장이 안 돼도 **일은 계속 간다.** 이 두 자리(markAlive·markHeartbeat)는 기록일 뿐이고,
     기록 때문에 생존 신호나 한 바퀴를 못 돌게 하는 것이 훨씬 나쁘다. */
  #saveQuietly() {
    try { this.save(); return true; } catch { return false; }
  }

  /* ── 손막음 ──
     사람이 "이 방 이 날은 대시보드 원장에 없는 사정으로 막아 둔다" 고 정한 것.
     예: 여기어때는 객실 이동이 안 돼서, 예약은 원래 방에 둔 채 실제 묵는 방을 따로 막는 경우.
     ★ closedByUs 와 **일부러 다른 자리**에 둔다. closedByUs 에 넣으면 캘린더 대조가
       "우리가 막았는데 원장에 예약이 없다" 며 그 방을 다시 열어 버린다. 손막음은 사람이
       풀기 전까지 그대로 둬야 한다. */
  holds() { return this.data.holds || {}; }
  holdKey(channel, roomKey) { return `${channel}|${roomKey}`; }
  addHold(channel, roomKey, from, to, why = '') {
    this.data.holds = this.data.holds || {};
    this.data.holds[this.holdKey(channel, roomKey) + `|${from}`] = { from, to, why, at: new Date().toISOString() };
    this.save();
  }
  releaseHold(channel, roomKey, from) {
    if (!this.data.holds) return false;
    const k = this.holdKey(channel, roomKey) + `|${from}`;
    if (!(k in this.data.holds)) return false;
    delete this.data.holds[k];
    this.save();
    return true;
  }
  /** 퇴실일이 지난 손막음은 치운다 — 목록이 옛것으로 불어나지 않게. */
  pruneHolds(today) {
    let gone = 0;
    for (const [k, h] of Object.entries(this.data.holds || {})) {
      if (h.to && h.to <= today) { delete this.data.holds[k]; gone++; }
    }
    if (gone) this.save();
    return gone;
  }

  // ── 할 일 ──
  todo(id) { return this.data.todos[id] || { attempts: 0 }; }
  /** 마지막 시도가 오래됐으면 시도 횟수를 잊는다. 3분짜리 장애로 마감이 영영 굳으면 안 된다(BR-006). */
  todoAfterCooldown(id, cooldownMs = 60 * 60000, now = Date.now()) {
    const t = this.todo(id);
    if (t.attempts && t.lastAt && now - Date.parse(t.lastAt) > cooldownMs) {
      this.data.todos[id] = { ...t, attempts: 0, cooledAt: new Date(now).toISOString() };
      this.save();
      return this.data.todos[id];
    }
    return t;
  }
  markTodoAttempt(id, error) {
    const t = this.todo(id);
    this.data.todos[id] = { ...t, attempts: (t.attempts || 0) + 1, lastError: error ? String(error).slice(0, 300) : null, lastAt: new Date().toISOString() };
    this.save();
  }
  markTodoDone(id) { this.data.todos[id] = { ...this.todo(id), doneAt: new Date().toISOString() }; this.save(); }
  forgetTodo(id) { delete this.data.todos[id]; this.save(); }
  /** 오래된 할 일 기억을 치운다(기본 30일). */
  pruneTodos(days = 30) {
    const cutoff = Date.now() - days * 86400000;
    for (const [id, t] of Object.entries(this.data.todos)) {
      const at = Date.parse(t.doneAt || t.lastAt || 0);
      if (at && at < cutoff) delete this.data.todos[id];
    }
    this.save();
  }

  /* ── 캘린더 대조: 우리가 막은 날 ──
     되돌리기(재개)를 안전하게 하려고 남긴다. **우리가 막은 날만** 우리가 연다 —
     사장님이 파트너센터에서 직접 막아 둔 날(공사·개인 사용)을 대시보드가 모른다고 열어 버리면
     팔면 안 되는 방이 팔린다. 열쇠는 채널·객실·날짜. */
  closedKey(channel, roomKey, date) { return `${channel}|${roomKey}|${date}`; }
  wasClosedByUs(channel, roomKey, date) { return !!this.data.closedByUs[this.closedKey(channel, roomKey, date)]; }
  markClosedByUs(channel, roomKey, dates) {
    for (const d of dates) this.data.closedByUs[this.closedKey(channel, roomKey, d)] = new Date().toISOString();
    this.save();
  }
  forgetClosedByUs(channel, roomKey, dates) {
    for (const d of dates) delete this.data.closedByUs[this.closedKey(channel, roomKey, d)];
    this.save();
  }
  pruneClosedByUs(today) {
    for (const k of Object.keys(this.data.closedByUs)) if (k.split('|')[2] < today) delete this.data.closedByUs[k];
    this.save();
  }

  // ── 요금 ──
  rateKey(channel, roomKey, date) { return `${channel}|${roomKey}|${date}`; }
  lastRate(channel, roomKey, date) { return this.data.rates[this.rateKey(channel, roomKey, date)] || null; }
  setRate(channel, roomKey, date, hash) { this.data.rates[this.rateKey(channel, roomKey, date)] = hash; }
  pruneRates(today) {
    for (const k of Object.keys(this.data.rates)) if (k.split('|')[2] < today) delete this.data.rates[k];
    this.save();
  }
}

/** 비어 있던 동안을 사람 말로. 1시간 미만이면 null — 정상적인 껐다 켬은 말할 것이 없다. */
export function gapSince(lastAlive, now = new Date(), minMs = 60 * 60000) {
  if (!lastAlive) return null;
  const then = new Date(lastAlive);
  const ms = now - then;
  if (!(ms > minMs)) return null;
  const h = Math.floor(ms / 3600000);
  const text = h >= 24 ? `${Math.floor(h / 24)}일 ${h % 24}시간`
    : h >= 1 ? `${h}시간` : `${Math.floor(ms / 60000)}분`;
  return { ms, text, at: then.toISOString() };
}

/** 채널별 기록 중 **가장 나쁜 것**. 하나라도 안 닿았으면 안 닿은 것이다. 같으면 오래된 쪽. */
export function worstOf(all = {}) {
  let best = null;
  for (const h of Object.values(all || {})) {
    if (!h || !h.at) continue;
    if (!best) { best = h; continue; }
    if (best.ok && !h.ok) { best = h; continue; }
    if (best.ok === h.ok && h.at < best.at) best = h;
  }
  return best;
}
