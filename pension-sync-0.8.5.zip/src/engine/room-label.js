/* 객실을 **화면에는 이름으로** 보여 준다.

   일은 코드로 한다 — 파트너센터 마감 API 가 받는 것이 상품 코드(621393)이고, 대시보드 매핑표의
   열쇠도 그 코드다. 그 자리를 이름으로 바꾸면 아무것도 안 맞는다.

   그런데 **사장님이 보는 화면과 로그까지 코드로 두면 확인을 할 수가 없다**(2026-09-15 소유자:
   "일이야 코드로 하지만, 우리가 보는건 객실명으로 봐야할 듯"). 621393 이 어느 방인지는 아무도 모른다.

   그래서 보여 줄 때만 이름을 붙인다. 이름을 못 찾으면 **코드를 그대로 쓴다** — 빈칸으로 두거나
   그럴듯한 다른 이름을 지어내지 않는다. 모르는 것은 모르는 채로 보여야 한다. */

/**
 * @param {object[]} resources 대시보드 객실 목록 [{id, name, code}]
 * @param {Iterable<[string, string[]]>} pairs  [resource_id, [channel_room_key, …]] 짝
 */
export function roomLabeler(resources = [], pairs = []) {
  const byResource = new Map();
  for (const r of resources || []) {
    if (!r || r.id == null) continue;
    /* 이름이 **공백뿐인** 객실이 있다. `r.name || r.code` 로 받으면 공백이 이름 행세를 해서
       코드까지 못 쓰게 된다 — 다듬고 나서 비었는지 본다. */
    const name = String(r.name ?? '').trim() || String(r.code ?? '').trim();
    if (name) byResource.set(String(r.id), name);
  }
  const byKey = new Map();
  for (const [resourceId, keys] of pairs || []) {
    const name = byResource.get(String(resourceId));
    if (!name) continue;
    for (const k of keys || []) byKey.set(String(k), name);
  }
  return {
    /** 채널 상품 코드 → 우리 객실명. 모르면 코드 그대로. */
    forKey: (key) => byKey.get(String(key)) || String(key ?? ''),
    /** 대시보드 객실 id → 객실명. 모르면 id 그대로. */
    forResource: (id) => byResource.get(String(id)) || String(id ?? ''),
    /** 로그용 — 이름과 코드를 같이 적는다. 이름이 없으면 코드만. */
    both: (key) => {
      const name = byKey.get(String(key));
      return name ? `${name}(${key})` : String(key ?? '');
    },
    size: byKey.size,
  };
}

/** 대시보드에서 객실 이름을 받아 온다. 못 받아도 일은 그대로 돈다(코드로 보여 줄 뿐). */
export async function loadRoomLabels(dashboard, pairs = []) {
  let resources = [];
  try {
    if (typeof dashboard?.resources === 'function') resources = (await dashboard.resources()) || [];
  } catch { /* 이름을 못 읽는 것으로 일을 멈추지 않는다 */ }
  return roomLabeler(resources, pairs);
}
