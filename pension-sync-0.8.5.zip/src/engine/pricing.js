/* 요금 계산 — 대시보드 규칙 그대로(BR-012).
   rate_calendar(날짜 지정) 가 있으면 그 값, 없으면 rate_plans 기본가 × 요일 배수.
   금요일·토요일 배수(fri_rate/sat_rate) 또는 고정가(fri_price/sat_price, supabase-56). 공휴일 전날은 토요일로 본다. */

/** 'YYYY-MM-DD' 의 요일. 0=일 … 6=토 */
export function dow(date) {
  return new Date(date + 'T00:00:00Z').getUTCDay();
}

/**
 * @param {object} plan  rate_plans 행 {base_price, fri_rate, sat_rate, fri_price, sat_price, min_nights}
 * @param {object|null} dayRow  rate_calendar 행 {price, min_nights, closed} 또는 null
 * @param {string} date
 * @param {Set<string>} holidays  공휴일 'YYYY-MM-DD' 집합
 * @returns {{price:number|null, minNights:number, closed:boolean, source:string}}
 */
export function priceFor(plan, dayRow, date, holidays = new Set()) {
  const closed = !!(dayRow && dayRow.closed);
  if (dayRow && dayRow.price != null && dayRow.price !== '') {
    return { price: Number(dayRow.price), minNights: Number(dayRow.min_nights ?? plan?.min_nights ?? 1), closed, source: 'calendar' };
  }
  if (!plan || plan.base_price == null) return { price: null, minNights: Number(dayRow?.min_nights ?? 1), closed, source: 'none' };
  const base = Number(plan.base_price);
  const d = dow(date);
  const next = new Date(Date.parse(date + 'T00:00:00Z') + 86400000).toISOString().slice(0, 10);
  const eveOfHoliday = holidays.has(next);
  let price = base;
  let source = 'base';
  if (d === 6 || eveOfHoliday) {           // 토요일 또는 공휴일 전날
    price = plan.sat_price != null ? Number(plan.sat_price) : Math.round(base * Number(plan.sat_rate ?? 1));
    source = eveOfHoliday && d !== 6 ? 'holiday-eve' : 'sat';
  } else if (d === 5) {                     // 금요일
    price = plan.fri_price != null ? Number(plan.fri_price) : Math.round(base * Number(plan.fri_rate ?? 1));
    source = 'fri';
  }
  return { price, minNights: Number(dayRow?.min_nights ?? plan.min_nights ?? 1), closed, source };
}

/** 여러 날짜의 요금표. dayRows 는 rate_calendar 행 배열(on_date 로 찾는다). */
export function priceTable(plan, dayRows, dates, holidays) {
  const by = new Map((dayRows || []).map((r) => [r.on_date, r]));
  return dates.map((date) => ({ date, ...priceFor(plan, by.get(date) || null, date, holidays) }));
}
