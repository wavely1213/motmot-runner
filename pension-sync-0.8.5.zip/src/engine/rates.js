/* 요금 반영 — 대시보드 요금(rate_plans + rate_calendar)을 파트너센터에 넣는다 (요구 2의 객실 정보 방향).
   "여기서 정한 값이 곧 채널에 밀 값이다"(콘솔). 값이 바뀐 날만 누른다(로컬 기억). 만실(closed)은 여기서 다루지 않는다 —
   그것은 서버 reconcile 이 할 일로 만들어 outbound 가 처리한다(두 길로 가면 어긋난다). */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { addDays, eachDate, todayKst } from '../lib/kst.js';
import { channelTargetRooms } from '../dashboard/client.js';
import { priceTable } from './pricing.js';
import { NeedsHumanError } from '../adapters/json-adapter.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));

export function loadHolidays(file = path.resolve(HERE, '../../config/holidays.json')) {
  try {
    const j = JSON.parse(fs.readFileSync(file, 'utf8'));
    return new Set(Object.entries(j).filter(([k]) => /^\d{4}$/.test(k)).flatMap(([, v]) => v));
  } catch { return new Set(); }
}

/**
 * @param {object} o { channel, adapter, dashboard, log, state, now, horizonDays=180, holidays, budget }
 * @returns {Promise<{ok:boolean, pushed:number, unchanged:number, rooms:number, skipped?:string}>}
 */
export async function runRates({ channel, adapter, dashboard, log, state, now = new Date(), horizonDays = 180, holidays = loadHolidays(), budget = 0 }) {
  const startedAt = now;
  const today = todayKst(now);
  if (!adapter.canSetRates) {
    log.debug(`${channel}: 요금 입력 단계가 채널 JSON 에 없어 건너뛴다`);
    return { ok: true, pushed: 0, unchanged: 0, rooms: 0, skipped: '채널 JSON 에 rates 절 없음' };
  }
  const out = { ok: true, pushed: 0, unchanged: 0, rooms: 0, failed: 0, moreLeft: false };
  try {
    const to = addDays(today, horizonDays);
    const [plans, cal, resources, map] = await Promise.all([
      dashboard.ratePlans(), dashboard.rateCalendar(today, to), dashboard.resources(), dashboard.roomMap(channel),
    ]);
    /* ★ 한 객실에 채널 상품이 여럿 붙어 있을 수 있다. Map 으로 덮어쓰면 마지막 상품에만 요금이 들어가고
         나머지 상품은 파트너센터에 있던 옛 값으로 계속 팔린다(outbound 와 같은 성격의 결함). 전부 모은다. */
    const keysOf = new Map();
    for (const m of map) {
      if (!keysOf.has(m.resource_id)) keysOf.set(m.resource_id, []);
      keysOf.get(m.resource_id).push(m.channel_room_key);
    }
    const planOf = new Map(plans.map((p) => [p.resource_id, p]));
    const dates = eachDate(today, to);
    for (const room of channelTargetRooms(resources)) {
      const roomKeys = keysOf.get(room.id);
      const plan = planOf.get(room.id) || null;
      const mine = cal.filter((c) => c.resource_id === room.id);
      // 기본 요금이 없어도 날짜 지정 요금이 있으면 그 날은 넣는다 — rate_calendar 가 계산을 이긴다(BR-012)
      if (!roomKeys || !roomKeys.length || (!plan && !mine.length)) continue;
      out.rooms++;
      const rows = priceTable(plan, mine, dates, holidays);
      for (const roomKey of roomKeys) {
        for (const r of rows) {
          if (r.price == null) continue;
          const hash = `${r.price}|${r.minNights}`;
          if (state.lastRate(channel, roomKey, r.date) === hash) { out.unchanged++; continue; }
          /* ★ 첫 실행은 넣을 날이 (객실 × 180일) 이라 몇 시간이 걸린다. 그동안 브라우저 줄을
               혼자 쓰면 예약 유입이 그만큼 늦는다 — 한 번에 이만큼만 넣고 다음 주기에 이어서 한다.
               어디까지 했는지는 state.lastRate 가 기억하므로 다음 주기는 남은 날부터 시작한다. */
          if (budget > 0 && out.pushed >= budget) { out.moreLeft = true; break; }
          try {
            await adapter.setRate({ roomKey, date: r.date, price: r.price, minNights: r.minNights });
            state.setRate(channel, roomKey, r.date, hash);
            out.pushed++;
            if (out.pushed % 20 === 0) state.save();   // 도중에 죽어도 넣은 것까지는 기억한다
          } catch (e) {
            if (e instanceof NeedsHumanError) throw e;
            out.failed++;
            log.error(`${channel}: ${roomKey} ${r.date} 요금 ${r.price} 입력 실패 — ${e.message}`);
            if (out.failed >= 5) throw new Error(`요금 입력이 연달아 실패해 멈춘다(${out.failed}회): ${e.message}`);
          }
        }
        if (out.moreLeft) break;
      }
      if (out.moreLeft) break;
    }
    state.pruneRates(today);
    state.save();
    out.ok = out.failed === 0;
    if (out.pushed) log.info(`${channel}: 요금 ${out.pushed}건 입력(변화 없음 ${out.unchanged}건, 객실 ${out.rooms})${out.moreLeft ? ' — 남은 날은 다음 주기에 이어서 넣는다' : ''}`);
    await dashboard.recordRun({ channel, kind: 'rates', startedAt, finishedAt: new Date(), ok: out.ok, detail: { pushed: out.pushed, unchanged: out.unchanged, failed: out.failed, moreLeft: out.moreLeft } });
    return out;
  } catch (e) {
    state.save();
    const human = e instanceof NeedsHumanError;
    log.error(`${channel}: 요금 반영 실패 — ${e.message}`);
    await dashboard.recordRun({ channel, kind: 'rates', startedAt, finishedAt: new Date(), ok: false, detail: { error: String(e.message).slice(0, 300) } }).catch(() => {});
    await dashboard.openAlert({ kind: 'sync_stale', channel, detail: { reason: human ? '2단계 인증 필요 — 페어링 다시' : `요금: ${String(e.message).slice(0, 180)}`, source: 'rates' } }).catch(() => {});
    return { ...out, ok: false, error: e.message, needsHuman: human };
  }
}
