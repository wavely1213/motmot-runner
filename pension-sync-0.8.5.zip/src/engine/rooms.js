/* 객실 정보 — 파트너센터의 객실 목록을 읽어 대시보드 객실 매핑(channel_room_map)과 맞춰 본다 (요구 2의 객실 정보).
   붙이지 못한 채널 객실은 콘솔의 '객실 미매핑' 경보로 알리고(콘솔에 '매핑하기' 버튼이 있다), 이름이 정확히 같은 것은
   자동으로 붙일 수 있다(autoMapExact). 파트너센터 쪽 객실 이름·정원 편집은 두 OTA 모두 운영팀 문의 사항이라 하지 않는다. */
import { channelTargetRooms } from '../dashboard/client.js';
import { NeedsHumanError } from '../adapters/json-adapter.js';

const norm = (s) => String(s || '').replace(/\s+/g, '').toLowerCase();

/** 순수 계산 — 채널 객실과 대시보드 객실을 이름으로 짝지어 본다. */
export function suggestMapping(channelRooms, resources, existingMap) {
  const mapped = new Set(existingMap.map((m) => m.channel_room_key));
  const byName = new Map(resources.map((r) => [norm(r.name), r]));
  const suggestions = [], unmatched = [];
  for (const cr of channelRooms) {
    if (mapped.has(cr.roomKey) || mapped.has(cr.name)) continue;
    const exact = byName.get(norm(cr.name)) || byName.get(norm(cr.roomKey));
    if (exact) suggestions.push({ channel_room_key: cr.roomKey, name: cr.name, resource_id: exact.id, resource_name: exact.name, exact: true });
    else {
      // 부분 일치(한쪽이 다른 쪽을 포함) 는 제안만 한다
      /* ★ 채널 이름이 비면 부분 일치를 하지 않는다. ''.includes('') 는 늘 참이라,
           이름을 못 읽은 객실이 전부 첫 번째 우리 객실에 붙어 버린다(실계정에서 7개가 그랬다). */
      const cn = norm(cr.name);
      const partial = cn && resources.find((r) => norm(r.name) && (cn.includes(norm(r.name)) || norm(r.name).includes(cn)));
      if (partial) suggestions.push({ channel_room_key: cr.roomKey, name: cr.name, resource_id: partial.id, resource_name: partial.name, exact: false });
      else unmatched.push(cr);
    }
  }
  const staleMap = existingMap.filter((m) => !channelRooms.some((cr) => cr.roomKey === m.channel_room_key || cr.name === m.channel_room_key));
  return { suggestions, unmatched, staleMap };
}

/**
 * @param {object} o { channel, adapter, dashboard, log, state, now, autoMapExact=false, propertyId }
 */
export async function runRooms({ channel, adapter, dashboard, log, state, now = new Date(), autoMapExact = false }) {
  const startedAt = now;
  try {
    const [channelRooms, resources, map] = await Promise.all([adapter.listRooms(), dashboard.resources(), dashboard.roomMap(channel)]);
    const targets = channelTargetRooms(resources);
    const { suggestions, unmatched, staleMap } = suggestMapping(channelRooms, targets, map);
    let inserted = 0;
    for (const s of suggestions) {
      if (autoMapExact && s.exact && dashboard.insertRoomMap) {
        await dashboard.insertRoomMap({ channel, channelRoomKey: s.channel_room_key, resourceId: s.resource_id });
        inserted++;
        log.info(`${channel}: 객실 자동 매핑 — '${s.name}' ↔ ${s.resource_name}`);
      } else {
        log.info(`${channel}: 매핑 제안 — 채널 '${s.name}' ↔ 우리 '${s.resource_name}'${s.exact ? '' : ' (부분 일치)'} → 콘솔 채널 탭에서 붙일 것`);
      }
    }
    for (const cr of [...unmatched, ...suggestions.filter((s) => !(autoMapExact && s.exact))]) {
      /* 콘솔의 '매핑하기' 는 channel_room_key 로 붙인다 — 경보에도 그 값을 담아야
         사장님이 콘솔에서 만든 매핑을 실행기가 그대로 쓴다. 이름은 읽기 좋으라고 곁들인다. */
      const key = cr.channel_room_key || cr.roomKey || cr.name;
      await dashboard.openAlert({ kind: 'unmapped', channel, detail: { roomKey: key, name: cr.name, source: 'rooms' } }).catch(() => {});
    }
    if (staleMap.length) log.warn(`${channel}: 파트너센터에 더 이상 없는 매핑 ${staleMap.length}건 — ${staleMap.map((m) => m.channel_room_key).join(', ')}`);
    state.data.meta[`rooms:${channel}`] = { at: new Date().toISOString(), channelRooms, suggestions, unmatched: unmatched.map((u) => u.name) };
    state.save();
    await dashboard.recordRun({ channel, kind: 'rooms', startedAt, finishedAt: new Date(), ok: true,
      detail: { channelRooms: channelRooms.length, mapped: map.length, suggestions: suggestions.length, unmatched: unmatched.length, inserted } });
    return { ok: true, channelRooms, suggestions, unmatched, staleMap, inserted };
  } catch (e) {
    const human = e instanceof NeedsHumanError;
    log.error(`${channel}: 객실 목록 실패 — ${e.message}`);
    await dashboard.recordRun({ channel, kind: 'rooms', startedAt, finishedAt: new Date(), ok: false, detail: { error: String(e.message).slice(0, 300) } }).catch(() => {});
    return { ok: false, error: e.message, needsHuman: human };
  }
}
