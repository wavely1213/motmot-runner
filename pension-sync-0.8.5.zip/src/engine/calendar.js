/* 캘린더 대조 — 대시보드 캘린더와 파트너센터 판매현황을 **매 주기 맞춘다**(양방향 동기화의 닫는 쪽).
   반영(outbound)은 대시보드 서버가 만들어 준 할 일(manual_close_todos)을 처리한다. 그 길은 서버 크론이
   15분마다 도는 것에 매여 있고, 다른 경로로 들어온 예약(전화·워크인·다른 OTA)은 할 일이 안 만들어질 수도 있다.
   여기서는 **원장을 직접 보고** 차이를 메운다 — 사람이 아무것도 누르지 않아도 된다는 요구가 이 파일이다.

   무엇을 막는가:  대시보드에 예약이 있는 날 + rate_calendar.closed 인 날(만실 걸기, I-006)
   무엇을 여는가:  **우리가 막았던 날인데** 대시보드에서 그 이유가 사라진 날(취소·기간 변경)
   무엇을 안 건드리는가:
     · 파트너센터가 'sold'(예약완료)로 표시한 날 — 그 채널에 든 예약이다. 우리가 열면 곧바로 오버부킹이다.
     · 사장님이 파트너센터에서 직접 막아 둔 날 — 우리 기록에 없으므로 열지 않는다(공사·개인 사용).
   원장을 못 읽으면(열 이름을 못 알아보면) 아무것도 하지 않고 경보만 남긴다 — 잘못 읽고 막거나 여는 것보다 낫다(D-004). */
import { addDays, dayKst, eachDate, todayKst } from '../lib/kst.js';
import { forDashboard } from '../lib/log.js';
import { bookingIsLive } from '../dashboard/client.js';
import { NeedsHumanError, SKIP_NOT_FOUND } from '../adapters/json-adapter.js';
import { loadRoomLabels } from './room-label.js';

/** 예약·만실에서 "막아야 할 날" 을 뽑는다. @returns Map<resourceId, Set<date>> */
export function blockedDates({ bookings, cols, rateCal, from, to }) {
  const want = new Map();
  const add = (rid, date) => {
    if (!rid || date < from || date >= to) return;
    if (!want.has(rid)) want.set(rid, new Set());
    want.get(rid).add(date);
  };
  for (const b of bookings || []) {
    if (!bookingIsLive(b, cols)) continue;
    /* ★ 앞 열 자를 그냥 자르면 안 된다 — 예약표가 시각까지 들고 있으면(starts_at) UTC 기준으로
         하루가 밀린다. KST 하루로 옮겨 읽는다(dayKst). */
    const ci = dayKst(b[cols.checkIn]);
    const co = dayKst(b[cols.checkOut]);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(ci)) continue;
    /* 묵는 밤만 막는다 — 퇴실일은 비어 있다. 대실(입실 == 퇴실)은 그 하루를 막는다(BR-016). */
    const end = /^\d{4}-\d{2}-\d{2}$/.test(co) && co > ci ? co : addDays(ci, 1);
    for (const d of eachDate(ci, end)) add(b[cols.resourceId], d);
  }
  for (const r of rateCal || []) {
    if (r && r.closed) add(r.resource_id, dayKst(r.on_date));
  }
  return want;
}

/* 그 방 그 날을 **만실 걸기**(rate_calendar.closed)로 막았나. 예약이 아니라 사장님이 걸어 둔 것이라
   예약자가 있을 수 없다 — 화면에 빈칸으로 두면 "이름을 못 읽었나?" 로 보인다. `만실` 이라고 적는다. */
export function closedByRate({ rateCal, from, to }) {
  const m = new Map();
  for (const r of rateCal || []) {
    if (!r || !r.closed) continue;
    const d = dayKst(r.on_date);
    if (!d || d < from || d >= to) continue;
    if (!m.has(r.resource_id)) m.set(r.resource_id, new Set());
    m.get(r.resource_id).add(d);
  }
  return m;
}

/** 이 날들이 **전부** 만실로 막은 날인가. */
export function allFromRate(rate, resourceId, dates) {
  const s = rate && rate.get ? rate.get(resourceId) : null;
  if (!s || !dates.length) return false;
  return dates.every((d) => s.has(d));
}

/* 한 예약을 화면에 뭐라고 적을까.
   ★ **단체는 단체명만** 적는다 — 단체 하나에 예약이 여러 줄이라 개인 이름을 다 늘어놓으면
     화면이 이름 목록이 되고, 그것도 손님 정보다. 단체명 칸이 없는 판이면 `단체` 라고만 적는다.
     개인 이름으로 대신하지 않는다. */
export function guestLabel(row, cols) {
  const c = cols || {};
  const group = c.groupName ? String(row[c.groupName] ?? '').trim() : '';
  if (group) return group;
  if (c.groupId && row[c.groupId] != null && String(row[c.groupId]).trim() !== '') return '단체';
  return c.guestName ? String(row[c.guestName] ?? '').trim() : '';
}

/* 그 방 그 날을 **누구 때문에** 막는가 — 화면에 보여 주려고만 쓴다(막을 날을 정하는 데는 안 쓴다).
   이름은 이 PC 의 화면 기록에만 남는다. 로그·보고서·클라우드로는 안 나간다(state.js 머리말). */
export function stayGuests({ bookings, cols, from, to }) {
  const who = new Map();
  if (!cols || !(cols.guestName || cols.groupName || cols.groupId)) return who;
  for (const b of bookings || []) {
    if (!bookingIsLive(b, cols)) continue;
    const name = guestLabel(b, cols);
    if (!name) continue;
    const ci = dayKst(b[cols.checkIn]);
    const co = dayKst(b[cols.checkOut]);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(ci)) continue;
    const end = /^\d{4}-\d{2}-\d{2}$/.test(co) && co > ci ? co : addDays(ci, 1);
    const rid = b[cols.resourceId];
    if (!rid) continue;
    if (!who.has(rid)) who.set(rid, new Map());
    for (const d of eachDate(ci, end)) {
      if (d < from || d >= to) continue;
      who.get(rid).set(d, name);
    }
  }
  return who;
}

/** 그 날들을 막게 한 예약자들을 한 줄로. 둘까지 적고 나머지는 세어서 줄인다. */
export function guestsFor(who, resourceId, dates) {
  const m = who && who.get ? who.get(resourceId) : null;
  if (!m) return '';
  const names = [...new Set(dates.map((d) => m.get(d)).filter(Boolean))];
  if (!names.length) return '';
  return names.length <= 2 ? names.join(', ') : `${names.slice(0, 2).join(', ')} 외 ${names.length - 2}명`;
}

/**
 * 한 객실의 차이를 낸다.
 * @param {object} o { want:Set<date>, have:Map<date,state>, dates:string[], wasClosedByUs:(date)=>boolean }
 * @returns {{toClose:string[], toOpen:string[], sold:string[], notFound:string[]}}
 */
export function diffRoom({ want, have, dates, wasClosedByUs }) {
  const toClose = [], toOpen = [], sold = [], notFound = [];
  for (const d of dates) {
    const state = have.get(d);
    if (state === undefined) { notFound.push(d); continue; }
    if (state === 'sold') { sold.push(d); continue; }        // 채널에 든 예약 — 손대지 않는다
    if (state === 'unknown') { notFound.push(d); continue; }  // 못 알아본 상태 문구 — 건드리지 않는다(BR-015)
    if (want.has(d)) { if (state === 'open') toClose.push(d); continue; }
    if (state === 'closed' && wasClosedByUs(d)) toOpen.push(d);
  }
  return { toClose, toOpen, sold, notFound };
}

/* 날짜를 달별로 묶는다. `setClosed` 는 반영 뒤 확인하려고 **첫 날~끝 날 전체**를 다시 읽으므로,
   9월 3일과 이듬해 2월 1일을 한 번에 넘기면 여섯 달 치를 두 번 읽는다. 달별로 나눠 부른다. */
export function byMonth(dates) {
  const groups = new Map();
  for (const d of dates) {
    const k = d.slice(0, 7);
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(d);
  }
  return [...groups.values()];
}

/**
 * @returns {Promise<{ok:boolean, closed:number, opened:number, rooms:number, skipped?:string, error?:string}>}
 */
export async function runCalendar({ channel, adapter, dashboard, log, state, cfg, now = new Date() }) {
  const startedAt = now;
  const today = todayKst(now);
  const horizon = cfg?.calendar?.horizonDays ?? 180;
  const from = today;
  const to = addDays(today, horizon);
  const out = { ok: true, closed: 0, opened: 0, rooms: 0 };
  try {
    const map = new Map();
    for (const m of await dashboard.roomMap(channel)) {
      if (!map.has(m.resource_id)) map.set(m.resource_id, []);
      map.get(m.resource_id).push(m.channel_room_key);
    }
    if (!map.size) return { ...out, skipped: '객실 매핑이 없다' };
    /* 일은 코드로 하고 **보여 주는 것만 이름으로** 한다(room-label.js 머리말).
       621393 이 어느 방인지는 사장님이 알 수 없다 — 화면에도 로그에도 이름을 붙인다. */
    const label = await loadRoomLabels(dashboard, map);
    /* 화면에 이미 적혀 있는 옛 줄도 이름으로 고친다 — 이름은 적힐 때 붙어서, 새 판을 깔아도
       옛 줄은 코드 그대로 남아 있었다(2026-09-16). 여기가 주기마다 도는 자리라 곧 다 고쳐진다. */
    state.relabelRecent?.((v) => label.forKey(v));

    const book = await dashboard.bookings(from, to);
    if (!book.ok) {
      log.error(`${channel}: 캘린더 대조를 건너뛴다 — ${book.why}`);
      await dashboard.openAlert({ kind: 'sync_stale', channel,
        detail: { reason: book.why.slice(0, 200), source: 'calendar' } }).catch(() => {});
      return { ...out, ok: false, skipped: book.why };
    }
    const rateCal = await dashboard.rateCalendar(from, to).catch((e) => { log.warn(`${channel}: 날짜 요금을 못 읽었다 — ${e.message}`); return []; });
    const want = blockedDates({ bookings: book.rows, cols: book.cols, rateCal, from, to });
    const who = stayGuests({ bookings: book.rows, cols: book.cols, from, to });
    const rate = closedByRate({ rateCal, from, to });
    /* ★ 이름 칸을 못 알아봤으면 **한 번 말한다.** 안 그러면 화면에 이름이 영영 안 뜨는데
         사장님은 왜인지 알 수가 없다(2026-09-16 실제로 그랬다). 값은 안 찍는다 — 칸 이름만. */
    if (book.rows?.length && !book.cols?.guestName && !book.cols?.groupName) {
      const seen = Object.keys(book.rows[0] || {}).join(', ');
      if (!state.saidBefore?.('bookingGuestCol', seen)) {
        log.warn(`${channel}: 예약표에서 예약자 이름 칸을 못 알아봤다 — 화면의 '품절처리' 줄에 이름이 안 나온다.` +
          ` 줄에 있던 칸 이름: ${seen}`);
      }
    }

    /* 판매현황은 한 번만 읽는다(달마다 한 번씩 부른다). 객실 수만큼 다시 읽으면 주기를 넘긴다. */
    const cells = await adapter.readAvailability({ from, to });
    const byKey = new Map();
    for (const c of cells) {
      if (!byKey.has(c.roomKey)) byKey.set(c.roomKey, new Map());
      byKey.get(c.roomKey).set(c.date, c.state);
    }
    const dates = eachDate(from, to);

    /* ★ **다시 여는 것만** 한 번 더 확인한다.
         막는 쪽은 틀려도 그 밤을 못 파는 것으로 끝나지만, 여는 쪽은 틀리면 **그 밤이 또 팔린다**(오버부킹).
         원장을 한 번 짧게 읽으면(조회가 흔들리거나 한 페이지만 오면) 예약이 사라진 것처럼 보이는데,
         지금까지는 그대로 열었다 — 유입에는 있는 '갑자기 줄었으면 멈춘다' 가 여기엔 없었다(2026-09-15).

         그래서 열기 직전에 **원장을 한 번 더 읽어** 정말 사라졌는지 본다. 한 주기에 한 번만 읽고
         (열 것이 있을 때만) 그 결과를 돌려 쓴다. 두 번째 읽기가 "아직 막을 날" 이라고 하면 이번 판은
         안 열고 경보를 남긴다 — 다음 주기가 새로 읽어 다시 판단하므로 정상 취소가 막히지는 않는다.
         두 번째 읽기 자체가 실패해도 안 연다. 확인 못 한 것을 여는 것이 가장 나쁘다(D-004). */
    let recheck;   // undefined = 아직 안 읽음 · false = 못 읽음 · Map = 두 번째로 읽은 '막을 날'
    const confirmOpen = async (resourceId, wantOpen) => {
      if (recheck === undefined) {
        const again = await dashboard.bookings(from, to).catch((e) => ({ ok: false, why: e.message }));
        if (!again || !again.ok) recheck = false;
        else {
          const rc = await dashboard.rateCalendar(from, to).catch(() => []);
          recheck = blockedDates({ bookings: again.rows, cols: again.cols, rateCal: rc, from, to });
        }
      }
      if (recheck === false) return { ok: false, why: '원장을 다시 읽지 못했다' };
      const still = wantOpen.filter((x) => (recheck.get(resourceId) || new Set()).has(x));
      if (still.length) {
        return { ok: false, why: `다시 읽은 원장에는 ${still.length}일이 아직 막을 날이다(${still.slice(0, 3).join(', ')})` };
      }
      return { ok: true };
    };

    for (const [resourceId, roomKeys] of map) {
      const w = want.get(resourceId) || new Set();
      for (const roomKey of roomKeys) {
        const have = byKey.get(roomKey);
        if (!have || !have.size) { log.warn(`${channel}: ${label.both(roomKey)} 가 파트너센터 판매현황에 없다 — 매핑을 확인할 것(I-021)`); continue; }
        out.rooms++;
        const d = diffRoom({ want: w, have, dates, wasClosedByUs: (date) => state.wasClosedByUs(channel, roomKey, date) });
        if (d.toClose.length) {
          let applied = 0;
          for (const chunk of byMonth(d.toClose)) {
            const r = await adapter.setClosed({ roomKey, dates: chunk, closed: true });
            // 파트너센터에서 못 찾은 날은 "우리가 막았다" 로 기억하지 않는다 — 나중에 그 날을 열어 버리면 안 된다
            state.markClosedByUs(channel, roomKey, chunk.filter((x) => !r.skipped.some((s) => s.date === x && s.why === SKIP_NOT_FOUND)));
            applied += r.applied;
          }
          out.closed += applied;
          /* 화면의 '방금 한 일' 목록 — 대시보드 → 여기어때 방향(이 PC 에만 남는다, state.js 머리말). */
          if (applied) {
            const by = guestsFor(who, resourceId, d.toClose)
              || (allFromRate(rate, resourceId, d.toClose) ? '만실' : '');
            state.addRecentOutbound?.(channel, [{ roomName: label.forKey(roomKey), dates: d.toClose,
              guestName: by, action: '품절처리' }]);
          }
          log.info(`${channel}: ${label.both(roomKey)} ${applied}일 막음 (대시보드에 예약·만실) — ${d.toClose.slice(0, 5).join(', ')}${d.toClose.length > 5 ? ` 외 ${d.toClose.length - 5}일` : ''}`);
        }
        if (d.toOpen.length) {
          /* 여기서만 두 번 읽는다 — 되돌리기 어려운 쪽이라서다(위 머리말). */
          const sure = await confirmOpen(resourceId, d.toOpen);
          if (!sure.ok) {
            log.warn(`${channel}: ${label.both(roomKey)} ${d.toOpen.length}일을 다시 열지 않았다 — ${sure.why}` +
              ' (잘못 열면 그 밤이 또 팔린다. 다음 주기에 새로 읽어 다시 본다)');
            await dashboard.openAlert({ kind: 'sync_stale', channel, resourceId, onDate: d.toOpen[0],
              detail: { reason: `다시 열기를 멈췄다 — ${sure.why}`, source: 'calendar' } }).catch(() => {});
            continue;
          }
          const opening = d.toOpen;
          let applied = 0;
          for (const chunk of byMonth(opening)) {
            const r = await adapter.setClosed({ roomKey, dates: chunk, closed: false });
            state.forgetClosedByUs(channel, roomKey, chunk);
            applied += r.applied;
          }
          out.opened += applied;
          if (applied) state.addRecentOutbound?.(channel, [{ roomName: label.forKey(roomKey), dates: opening, action: '다시 열기' }]);
          log.info(`${channel}: ${label.both(roomKey)} ${applied}일 다시 열었다 (대시보드에서 사라진 예약 — 원장을 두 번 읽어 확인했다) — ${opening.slice(0, 5).join(', ')}${opening.length > 5 ? ` 외 ${opening.length - 5}일` : ''}`);
        }
      }
    }
    state.pruneClosedByUs(today);
    if (out.closed || out.opened) {
      await dashboard.recordRun({ channel, kind: 'outbound', startedAt, finishedAt: new Date(), ok: true,
        detail: { mode: 'calendar', closed: out.closed, opened: out.opened, rooms: out.rooms } }).catch(() => {});
    }
    return out;
  } catch (e) {
    const human = e instanceof NeedsHumanError;
    log.error(`${channel}: 캘린더 대조 실패 — ${e.message}`);
    await dashboard.recordRun({ channel, kind: 'outbound', startedAt, finishedAt: new Date(), ok: false,
      detail: { mode: 'calendar', error: String(e.message).slice(0, 300) } }).catch(() => {});
    await dashboard.openAlert({ kind: 'sync_stale', channel,
      detail: { reason: human ? '2단계 인증 필요 — 페어링 다시' : forDashboard(e.message), source: 'calendar' } }).catch(() => {});
    return { ...out, ok: false, error: e.message, needsHuman: human };
  }
}
