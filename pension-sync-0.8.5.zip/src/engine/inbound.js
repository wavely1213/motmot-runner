/* 유입 — 파트너센터 예약 목록을 대시보드로 보낸다 (요구 1: 캘린더 공유).
   흐름: 목록 읽기 → TSV → op=paste 미리보기로 서버가 읽는지 확인 → op=paste commit → op=reconcile (BR-001, BR-002).
   같은 목록을 또 보내지 않도록 마지막 저장 해시를 기억한다. 취소·변경도 목록에 상태로 실려 가므로 같은 길이다. */
import crypto from 'node:crypto';
import { addDays, todayKst } from '../lib/kst.js';
import { buildPasteText, dedupeByReservationNo, looksLikeShrink, previewLooksSane, summarizeStatuses, normalizeStatus } from '../dashboard/paste.js';
import { forDashboard } from '../lib/log.js';
import { knownNosFrom, pickToSend, sendBreakdown, breakdownText } from './already-known.js';
import { loadRoomLabels } from './room-label.js';
import { NeedsHumanError } from '../adapters/json-adapter.js';

const hashOf = (s) => crypto.createHash('sha256').update(s).digest('hex').slice(0, 16);


/**
 * @returns {Promise<{ok:boolean, sent:number, saved?:number, unmapped?:number, unchanged?:boolean, error?:string}>}
 */
export async function runInbound({ channel, adapter, dashboard, cfg, log, state, now = new Date(), force = false, previewOnly = false }) {
  const startedAt = now;
  const today = todayKst(now);
  const from = addDays(today, -cfg.inbound.lookbackDays);
  const to = addDays(today, cfg.inbound.horizonDays);
  let result;
  let shrinkWhy = null;   // 건수가 확 줄었을 때의 사유(경보를 열고, 그 주기에는 경보를 닫지 않는다)
  try {
    const raw = await adapter.listReservations({ from, to });
    /* ★ 대실(day-use)은 입실일 == 퇴실일이다. checkOut > checkIn 으로 거르면 대실 예약이
         "날짜를 못 읽었다" 로 조용히 빠져 그 날을 우리가 계속 판다. 같은 날은 통과시키고,
         거꾸로 된 것(퇴실이 입실보다 앞)만 버린다. */
    const uniq = dedupeByReservationNo(raw);
    const items = uniq.filter((r) => r.checkIn && r.checkOut && r.checkOut >= r.checkIn);
    /* ★ 겹쳐 읽은 것(같은 예약이 두 창에 걸침)과 날짜를 못 읽은 것은 다른 일이다. 한 숫자로 묶어
         "날짜를 못 읽었다" 고 말하면 멀쩡한 판을 고장으로 읽는다 — 실제로 그렇게 헷갈렸다. */
    const overlapped = raw.length - uniq.length;
    const badDate = uniq.length - items.length;
    if (overlapped) log.debug(`${channel}: 같은 예약 ${overlapped}건이 겹쳐 읽혔다(한 건으로 친다)`);
    if (badDate) {
      /* ★ 몇 건인지만 말하면 고칠 수가 없다. **날짜 값 그대로**를 붙인다 — 날짜는 개인정보가 아니고,
           이걸 봐야 파트너센터가 어떤 꼴로 주는지 알아 parseLooseDate 를 맞출 수 있다. */
      const bad = uniq.filter((r) => !(r.checkIn && r.checkOut && r.checkOut >= r.checkIn)).slice(0, 3);
      /* raw 는 sniff 가 고른 그대로다(칸 이름은 우리 말로 붙어 있고 값은 파트너센터가 준 원본). */
      const how = bad.map((r) => `입실=${JSON.stringify(r.raw?.checkIn ?? null)} 퇴실=${JSON.stringify(r.raw?.checkOut ?? null)}`).join(' / ');
      log.warn(`${channel}: 날짜를 못 읽은 예약 ${badDate}건은 보내지 않는다 — 온 모양: ${how || '(비어 있다)'}`);
      /* ★ 읽긴 했는데 **한 건도 안 남았다**면 그건 "예약이 없다" 가 아니라 "날짜를 못 읽었다" 다.
           지금까지는 이 자리가 성공 0건으로 흘러가 경보까지 닫혔다 — BR-019 가 어댑터에만 있고
           엔진에는 없었다. 대시보드가 그 날들을 빈 것으로 알면 그대로 다시 팔린다. */
      if (!items.length) {
        throw new Error(`예약 ${raw.length}건을 읽었는데 날짜를 하나도 못 읽었다 — 온 모양: ${how || '(비어 있다)'}` +
          ' (0건이 아니라 실패다 — 이 날들을 비었다고 알리면 다시 팔린다)');
      }
    }
    /* 손님 정보(연락처·인원·금액·요청사항)는 켰을 때만 실린다 — 서버 파서가 긴 형태를 어떻게 읽는지
       아직 실측 전이다. 켠 뒤에도 미리보기가 이상하면 저장까지 가지 않는다(previewLooksSane). */
    const extended = cfg.dashboard?.pasteColumns === 'extended';
    /* ★ 객실 칸에 **무엇을 보내느냐**가 매핑의 전부다(2026-09-11 실측).
         대시보드의 객실 매핑표는 `channel_room_key → 우리 객실` 이고, 그 열쇠는 채널의
         **객실 코드**다(여기어때 621392 → pen-201). 그런데 예약 목록이 실어 주는 것은
         상품 **이름**(펜션 패밀리룸)이라, 이름을 그대로 보내면 표와 한 건도 안 맞는다 —
         실제로 7건 보내 7건 전부 미매핑이었다. 반영(outbound)은 같은 표를 반대 방향으로
         읽어서 잘 되고 있었기 때문에 "다른 건 다 되는데" 로 보였다.
         그래서 채널의 객실 목록으로 **이름 → 코드**를 풀어 코드를 보낸다.
         못 푼 것은 이름 그대로 보낸다 — 그래야 콘솔 경고에 무엇이 안 붙었는지 남는다. */
    const roomsAs = cfg.dashboard?.pasteRoom || 'key';
    let items2 = items;
    if (roomsAs === 'key') {
      const rooms = await adapter.listRooms().catch((e) => {
        log.warn(`${channel}: 객실 목록을 못 읽어 객실 코드로 못 바꾼다 — ${e.message} (이름 그대로 보낸다)`);
        return [];
      });
      const byName = new Map(rooms.filter((r) => r.name && r.roomKey).map((r) => [String(r.name).replace(/\s+/g, ''), String(r.roomKey)]));
      const missed = new Set();
      items2 = items.map((it) => {
        const key = byName.get(String(it.roomName || '').replace(/\s+/g, ''));
        if (!key) { if (it.roomName) missed.add(it.roomName); return it; }
        return { ...it, roomName: key };
      });
      if (missed.size) {
        log.warn(`${channel}: 객실 코드를 못 찾은 상품 ${missed.size}개 — ${[...missed].join(', ')}` +
          ' (채널 객실 목록에 없는 이름이다. 그대로 보내니 콘솔에 미매핑으로 뜬다)');
      }
    }
    /* ★ 미리보기에서는 **예약번호를 그대로 보여 준다.** 번호가 대시보드가 아는 번호와 다르면
         대시보드는 같은 예약을 한 줄 더 만든다 — 실제 예약마다 오버부킹 경보가 뜬다(2026-09-11).
         번호는 주문 식별자라 이름·연락처와 달리 개인정보가 아니므로, 눈으로 맞춰 볼 수 있게 찍는다.
         이걸 못 보고 저장부터 하면 잘못된 줄을 되돌려야 한다. */
    /* ★ 이미 원장에 있는 예약은 다시 안 보낸다(I-063). 대시보드가 bookings 와 ota_reservations 를
         같은 예약으로 안 묶어서, 또 보내면 점유가 둘로 세어지고 실제 예약마다 오버부킹 경보가 뜬다.
         그렇다고 유입을 끄면 이 프로그램의 본업(새 예약 잡기)이 없어진다 — **가려서 보낸다.**
         원장을 못 읽으면 가리지 않고 전부 보낸다. 새 예약을 빼먹는 것보다 낫다. */
    let items3 = items2;
    let alreadyKnown = 0;
    /* ★ 0건일 때는 가리지 않는다. 여기서 조기 반환하면 아래 BR-019 검사(증명 못 한 0건은 실패다)를
         건너뛰게 되고, 그건 이 프로젝트가 가장 조심하는 자리다 — 그 밤이 비었다고 잘못 알리면 다시 팔린다. */
    /* 원장 읽기가 없는 판(모의·옛 대시보드)에서는 가리지 않는다 — 없는 함수를 부르면 그 자리에서 터진다. */
    const book = items2.length && typeof dashboard.bookings === 'function'
      ? await dashboard.bookings(from, to).catch((e) => ({ ok: false, why: e.message }))
      : null;
    if (!items2.length) { /* 가릴 것이 없다 — 아래 BR-019 검사로 간다 */ }
    else if (!book || !book.ok) {
      log.warn(`${channel}: 원장을 못 읽어 '이미 있는 예약' 을 가리지 못한다 — ${book?.why || '알 수 없다'}` +
        ' (전부 보낸다. 이미 있는 것이 또 들어가면 오버부킹 경보가 뜰 수 있다)');
    } else {
      const known = knownNosFrom(book.rows, items2.map((it) => String(it.reservationNo ?? '')));
      const picked = pickToSend(items2, known, normalizeStatus, { rows: book.rows, cols: book.cols, matchBy: cfg.inbound?.dupeBy || 'no' });
      items3 = picked.send;
      alreadyKnown = picked.skipped.length;
      if (alreadyKnown) {
        const how = (cfg.inbound?.dupeBy || 'no') === 'stay' ? '예약번호 + 이름·날짜' : '예약번호';
        /* ★ 갈라서 적는다 — 같은 줄이 매 주기 반복될 때 정상(취소)인지 고장(새 예약이 원장에 안 앉음)인지
             이 줄만 보고 갈리게 한다(2026-09-17 소유자 로그, already-known.js 의 sendBreakdown 머리말). */
        log.info(`${channel}: 이미 원장에 있는 예약 ${alreadyKnown}건은 안 보낸다(${how}로 가림) — 새 예약·취소 ${items3.length}건만 보낸다` +
          ` — ${breakdownText(sendBreakdown(items3, normalizeStatus))}`);
      }
    }
    if (items2.length && !items3.length) {
      /* 보낼 것이 없다 = 새 예약도 취소도 없다. 정상이다(실패가 아니다). */
      log.info(`${channel}: 새 예약도 취소도 없다 — 보낼 것이 없다(원장에 이미 ${alreadyKnown}건)`);
      result = { ok: true, sent: 0, unchanged: true, alreadyKnown };
      await dashboard.recordRun({ channel, kind: 'inbound', startedAt, finishedAt: new Date(), ok: true, detail: { sent: 0, alreadyKnown } });
      await dashboard.resolveAlerts({ kind: 'sync_stale', channel, source: 'inbound' }).catch(() => 0);
      return result;
    }
    if (previewOnly) {
      const nums = items3.slice(0, 5).map((it) => it.reservationNo);
      log.info(`${channel}: 보낼 예약번호(앞 ${nums.length}개) — ${nums.join(', ')}`);
      log.info(`${channel}: 대시보드 예약 메모의 '채널 예약 자동 반영 (yeogi · …)' 번호와 **같은 꼴**이어야 한다.` +
        ' 다르면 같은 예약이 한 줄 더 생긴다 — 저장하지 말 것.');
    }
    const text = buildPasteText(items3, { extended });
    const hash = hashOf(text);
    const last = state.lastInbound(channel);
    /* ★ 0건은 그 자체로는 참·거짓을 못 가린다. **우리 창으로 물어서 정말 비었던 것**만 성공으로 본다.
         증거 없는 0건을 성공으로 넘기면 콘솔은 초록이 되고 sync_stale 경보까지 닫히는데,
         그동안 파트너센터에 든 예약을 대시보드가 모르니 그 밤이 다시 팔린다(BR-019).
         ★ 이 검사는 `unchanged` 지름길보다 **앞에** 있어야 한다. 뒤에 두면 한 번이라도 0건이
           통과한 순간 그 해시가 state 에 남아, 그 다음부터는 증거를 안 보고 조용히 초록이 된다. */
    if (!items.length) {
      const unproven = (adapter.lastAsk?.windows || []).filter((w) => w.declared && !w.provenEmpty);
      if (unproven.length) {
        /* ★ "증거가 없다" 와 "물었고 증거도 있었는데 그 0건이 물어서 확인한 0건은 아니다" 는 다른 일이다.
             한 문구로 묶으면 다음에 무엇을 고칠지 사람을 반대 방향으로 보낸다(2026-09-09 검토). */
        const why = unproven.map((w) => `${w.from}~${w.toInclusive}` +
          (w.proven ? '(물었지만 0건이라는 것까지는 확인 못 했다)' : '(우리 창으로 물었다는 증거가 없다)')).join(', ');
        throw new Error(`예약 0건인데 우리 창으로 물어서 확인한 0건이 아니다 — ${why}` +
          ' (증명 못 한 0건은 "예약 없음" 이 아니라 실패다)');
      }
    }
    /* 지난 주기에 급락 경보를 연 채였는가 — 그 기준선을 물려받는다(아래 참조). */
    const shrinkBase = last && last.ok ? (last.shrunkFrom ?? last.sent) : null;
    let shrunkFrom = null;
    if (!force && !previewOnly && last && last.hash === hash && last.ok) {
      result = { ok: true, sent: items.length, unchanged: true };
      /* ★ 급락 경보가 **다음 주기에 스스로 지워지면** 안 된다. 줄어든 목록이 그대로 또 오면
           해시가 같아 여기로 오는데, 예전에는 이 길이 곧바로 resolveAlerts 로 경보를 닫았다.
           주기가 1~2분이면 사람이 볼 수 없는 경보가 된다. 회복될 때까지 열어 둔다. */
      if (last.shrunkFrom != null) {
        shrunkFrom = last.shrunkFrom;
        shrinkWhy = `예약이 ${last.shrunkFrom}건 → ${items.length}건으로 줄어든 채 그대로다 — 조회 조건(기간·상태 거르개)이 바뀌었는지 볼 것`;
      }
    } else if (!items.length) {
      // 목록이 비어 있어도 "읽었다" 는 사실은 남긴다 — inbound_stale 을 막는다. 서버에 빈 표를 보내지는 않는다.
      if (!previewOnly) state.setInbound(channel, { hash, ok: true, sent: 0 });
      result = { ok: true, sent: 0, previewOnly: previewOnly || undefined };
    } else {
      const preview = await dashboard.pastePreview(channel, text);
      /* ★ 서버가 몇 줄을 읽었는지만 보면 부족하다. 채널의 상태 문구를 우리가 못 알아보면
           취소된 예약이 '예약취소' 로 안 가고 원장에 확정으로 남아 그 날을 계속 팔게 된다. */
      const statuses = summarizeStatuses(items);
      const sane = previewLooksSane(preview, items.length, statuses);
      if (!sane.ok) {
        /* ★ "상태를 못 알아봤다" 만 말하면 다음에 또 한 바퀴를 돌아야 한다. 응답에 **어떤 칸이
             있었는지 이름만** 붙인다(값은 안 붙인다) — 그 자리에서 채널 JSON 을 고칠 수 있게. */
        const spare = (adapter.spareFields || []).join(', ');
        const missing = (adapter.missingFields || []).join(',');
        /* 상태를 못 알아본 판이면 **어느 칸을 상태로 집었는지**까지 적는다. 이름이 없으면
           "상태가 비었다" 만 되풀이될 뿐 다음에 무엇을 고칠지 알 수가 없다(2026-09-09). */
        const picked = adapter.pickedFields || {};
        const where = picked.status ? ` · 상태로 집은 칸: ${picked.status}` : '';
        throw new Error(`서버가 목록을 읽지 못했다: ${sane.why}` +
          (missing ? ` — 못 붙인 칸: ${missing}` : '') + where + (spare ? ` · 응답에 남은 이름: ${spare}` : ''));
      }
      if (statuses.unknown.length) {
        const sample = statuses.unknown.slice(0, 3).map((u) => `'${u.status}'`).join(', ');
        log.warn(`${channel}: 못 알아본 상태 문구 ${statuses.unknown.length}건 (${sample}) — normalizeStatus 에 넣을 것`);
      }
      /* 첫 실행 확인용 — 서버가 읽는 것만 보고 저장은 하지 않는다(--preview). */
      if (previewOnly) {
        const counts = Object.entries(statuses.counts).map(([k, v]) => `${k} ${v}`).join(', ');
        /* 손님 정보는 **몇 건 잡혔는지만** 센다 — 값은 로그에 한 글자도 남기지 않는다. */
        const filled = (k) => items.filter((it) => it[k] !== '' && it[k] != null).length;
        log.info(`${channel}: [미리보기] 예약 ${items.length}건 · 서버가 읽은 줄 ${sane.total}건 · 상태 ${counts || '없음'}` +
          ` · 손님정보(${extended ? '보냄' : '안 보냄'}) 연락처 ${filled('guestPhone')} 인원 ${filled('partySize')} 금액 ${filled('amount')} 정산금액 ${filled('settleAmount')} 요청 ${filled('memo')}` +
          ' — 저장하지 않았다');
        result = { ok: true, sent: items3.length, previewOnly: true, read: sane.total, statuses: statuses.counts, unknownStatuses: statuses.unknown, alreadyKnown };
        await dashboard.recordRun({ channel, kind: 'inbound', startedAt, finishedAt: new Date(), ok: true, detail: { previewOnly: true, sent: items3.length, read: sane.total } });
        return result;
      }
      /* ★ 지난번보다 갑자기 반 넘게 줄었으면 사람을 부른다. 막지는 않는다(paste.js 의 주석 참조) —
           다만 조용히 지나가면 "짧지만 그럴듯한 목록" 이 원장을 덮어써도 아무도 모른다. */
      if (shrinkBase != null && looksLikeShrink(shrinkBase, items.length)) {
        /* 기준선은 **줄어들기 전 건수**다. 지난번 건수를 기준으로 삼으면 줄어든 다음 주기부터는
           "지난번과 비슷하다" 가 되어 경보가 스스로 사라진다. 회복될 때까지 그 숫자를 들고 간다. */
        shrunkFrom = shrinkBase;
        shrinkWhy = `예약이 ${shrinkBase}건 → 이번 ${items.length}건으로 줄었다 — 조회 조건(기간·상태 거르개)이 바뀌었는지 볼 것`;
        log.warn(`${channel}: ${shrinkWhy}`);
      }
      const commit = await dashboard.pasteCommit(channel, text);
      if (!commit || !commit.ok) throw new Error(`저장 실패: ${(commit && commit.error) || '응답 오류'}`);
      /* ★ 미리보기는 깐깐히 보면서(previewLooksSane) **저장 결과는 ok 하나만 보던** 자리다.
           서버가 {ok:true, saved:0} 을 줘도 성공으로 굳어 ① 해시를 저장해 다음 주기에 재시도조차 안 하고
           ② sync_runs 를 ok 로 남기고 ③ 아래에서 경보까지 닫았다 — 신호가 전부 초록인데 원장은 비어 있다.
           그 밤을 대시보드는 빈 것으로 알고 또 판다(BR-019). 보낸 만큼 저장됐는지 여기서 본다. */
      const saved = commit.saved;
      if (Number.isFinite(saved) && items3.length > 0 && saved <= 0) {
        throw new Error(`보낸 ${items3.length}건 중 서버가 한 줄도 저장하지 않았다(saved=0) — 저장 파서가 우리 표를 못 읽는다`);
      }
      const partial = Number.isFinite(saved) && saved < items3.length;
      if (partial) {
        log.warn(`${channel}: 보낸 ${items3.length}건 중 ${saved}건만 저장됐다 — 나머지는 원장에 없다(그 밤이 빈 것으로 보인다)`);
      }
      const rec = await dashboard.reconcile();
      if (!rec || !rec.ok) log.warn(`${channel}: reconcile 이 실패했다 — ${(rec && rec.error) || '응답 오류'} (15분 크론이 다시 돈다)`);
      /* 일부만 저장됐으면 ok:false 로 남긴다 — 그래야 다음 주기가 해시 지름길을 타지 않고 다시 해 본다. */
      state.setInbound(channel, { hash, ok: !partial, sent: items3.length, saved: commit.saved, shrunkFrom: shrunkFrom ?? undefined });
      /* 화면의 '새 예약' 목록에 쓸 기록. 이 PC 에만 남고 클라우드·로그·보고서로는 안 나간다(state.js 머리말).
         ★ 객실은 **이름으로** 남긴다. 보낼 때는 채널 상품 코드(621393)로 바꿔 보내는데(매핑표의 열쇠라
           그래야 붙는다), 그 코드를 화면에 그대로 내면 어느 방인지 알 수가 없다(2026-09-15 소유자).
           우리 객실명 → 없으면 채널 상품 이름 → 그것도 없으면 코드. */
      const shown = await (async () => {
        let pairs = [];
        try {
          const rows = typeof dashboard.roomMap === 'function' ? await dashboard.roomMap(channel) : [];
          const byResource = new Map();
          for (const m of rows || []) {
            if (!byResource.has(m.resource_id)) byResource.set(m.resource_id, []);
            byResource.get(m.resource_id).push(m.channel_room_key);
          }
          pairs = byResource;
        } catch { /* 이름을 못 읽어도 기록은 남긴다 */ }
        const label = await loadRoomLabels(dashboard, pairs);
        /* 바꾸기 전 이름(채널 상품명)을 예약번호로 들고 있다가, 우리 이름을 못 찾으면 그것을 쓴다. */
        const origin = new Map(items.map((it) => [String(it.reservationNo), String(it.roomName || '')]));
        return items3.map((it) => {
          const key = String(it.roomName || '');
          const name = label.forKey(key);
          const shownName = name !== key ? name : (origin.get(String(it.reservationNo)) || key);
          return { ...it, roomName: shownName, status: normalizeStatus(it.status) };
        });
      })();
      state.addRecentInbound?.(channel, shown);
      const unmapped = Array.isArray(commit.unmapped) ? commit.unmapped.length : (commit.unmapped ?? 0);
      result = { ok: !partial, sent: items3.length, saved: commit.saved ?? null, unmapped, reconciled: !!(rec && rec.ok), partial, alreadyKnown };
      log.info(`${channel}: 예약 ${items3.length}건 보냄 → 저장 ${commit.saved ?? '?'}건${alreadyKnown ? `, 원장에 이미 있어 뺀 것 ${alreadyKnown}건` : ''}${unmapped ? `, 객실 미매핑 ${unmapped}건` : ''}`);
    }
    await dashboard.recordRun({ channel, kind: 'inbound', startedAt, finishedAt: new Date(), ok: result.ok !== false, detail: { sent: result.sent, saved: result.saved ?? undefined, unchanged: !!result.unchanged, partial: result.partial || undefined } });
    /* ★ 건수가 확 줄어든 주기에는 경보를 **닫지 않는다**. 닫으면 방금 연 경보가 같은 자리에서 사라진다. */
    if (shrinkWhy || result.partial) {
      const reason = shrinkWhy || `보낸 ${result.sent}건 중 ${result.saved}건만 저장됐다 — 나머지는 원장에 없다`;
      await dashboard.openAlert({ kind: 'sync_stale', channel, detail: { reason, source: 'inbound' } }).catch(() => {});
      if (shrinkWhy) result = { ...result, shrink: shrinkWhy };
    } else {
      await dashboard.resolveAlerts({ kind: 'sync_stale', channel, source: 'inbound' }).catch(() => 0);
    }
    return result;
  } catch (e) {
    const human = e instanceof NeedsHumanError;
    const msg = human ? e.message : `유입 실패: ${e.message}`;
    log.error(`${channel}: ${msg}`);
    await dashboard.recordRun({ channel, kind: 'inbound', startedAt, finishedAt: new Date(), ok: false, detail: { error: String(e.message).slice(0, 300) } }).catch(() => {});
    await dashboard.openAlert({ kind: 'sync_stale', channel, detail: { reason: human ? '2단계 인증 필요 — 페어링 다시' : forDashboard(e.message), source: 'inbound' } }).catch(() => {});
    return { ok: false, sent: 0, error: e.message, needsHuman: human };
  }
}
