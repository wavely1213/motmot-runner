/* 파트너센터에서 읽은 예약을 대시보드 서버(op=paste)가 읽는 탭 구분 텍스트로 만든다(BR-002).
   콘솔의 붙여넣기 칸 placeholder 가 정한 컬럼 순서를 그대로 따른다:
     예약번호 \t 객실명 \t 체크인 \t 체크아웃 \t 예약자 \t 상태
   서버 파서는 우리 것이 아니므로 열을 늘리거나 순서를 바꾸지 않는다. */

export const PASTE_HEADER = ['예약번호', '객실명', '체크인', '체크아웃', '예약자', '상태'];

/* 손님 정보까지 보내는 긴 형태(PASTE_COLUMNS=extended). 대시보드 예약표에는 guest_phone·party_size·
   amount·memo 자리가 있는데 placeholder 의 여섯 열로는 그 넷이 안 실린다 — 파트너센터에는 있는 값이다.
   붙여넣기 칸은 원래 **사람이 파트너센터 표를 통째로 복사**하는 자리라 서버 파서가 열을 머리글로
   찾을 가능성이 높다. 그래도 우리가 확인한 것은 여섯 열까지다(I-003) — 그래서 기본은 여섯 열이고,
   긴 형태는 켤 때만 나간다. 켠 뒤 첫 실행은 반드시 --preview 로 서버가 몇 줄 읽는지 보고 나서 저장한다. */
/* ★ '정산금액' 은 맨 뒤에 붙인다(2026-09-15). 앞의 열 순서를 건드리면 서버 파서가 자리로 읽는
   판에서 모든 값이 한 칸씩 밀린다 — 뒤에 붙이면 모르는 열은 무시될 뿐이다. 그래도 켠 뒤 첫
   실행은 --preview 로 서버가 몇 줄 읽는지 보고 나서 저장한다(previewLooksSane 이 막아 준다). */
export const PASTE_HEADER_EXTENDED = [...PASTE_HEADER, '연락처', '인원', '금액', '요청사항', '정산금액'];

/** 채널마다 다른 상태 문구를 대시보드가 아는 말로 모은다. 모르면 원문 그대로 둔다. */
export function normalizeStatus(text) {
  /* ★ 상태가 객체({name:'예약완료'})나 숫자 코드(0)로 오는 판이 있다. `text || ''` 로 받으면
       0·false 가 통째로 ''(빈 상태)이 되어 "상태를 하나도 못 알아봤다" 로만 보이고,
       무엇이 왔는지는 끝내 안 보인다. 있는 그대로 글자로 만들어 둔다. */
  const raw = text && typeof text === 'object' && !Array.isArray(text)
    ? (text.name ?? text.label ?? text.text ?? text.title ?? text.value ?? text.code ?? '')
    : text;
  const s = String(raw ?? '').replace(/\s+/g, '');
  if (!s) return '';
  /* ★ 순서와 부정어가 중요하다. '미확인' 이 '확인' 에 걸려 확정으로 읽히면
       취소된 방을 계속 팔게 된다. 부정형을 먼저 걸러 낸다. */
  if (/^미확인$|미확인|확인대기/.test(s)) return '예약대기';
  if (/취소|환불|노쇼|CANCEL/i.test(s)) return '예약취소';
  if (/대기|미확정|PENDING|WAIT/i.test(s)) return '예약대기';   // WAIT = 여기어때 예약상태 열거형(실측)
  if (/이용완료|퇴실|체크아웃완료|완료됨|COMPLETED|CHECKED_?OUT/i.test(s)) return '이용완료';
  if (/확정|예약완료|판매완료|CONFIRM/i.test(s)) return '예약확정';
  return String(raw ?? '').trim();
}

function cell(v) {
  // 탭·줄바꿈이 셀 안에 있으면 표가 깨진다 — 공백 하나로 바꾼다
  return String(v ?? '').replace(/[\t\r\n]+/g, ' ').trim();
}

/** 대시보드가 아는 상태값. 이 넷이 아니면 우리가 문구를 못 알아본 것이다. */
export const KNOWN_STATUSES = ['예약확정', '예약취소', '예약대기', '이용완료'];

/** 정규화 결과를 세어 본다 — 못 알아본 문구가 많으면 첫 실행에서 저장하면 안 된다. */
export function summarizeStatuses(items) {
  const counts = {};
  const unknown = [];
  for (const it of items) {
    const s = normalizeStatus(it.status);
    counts[s] = (counts[s] || 0) + 1;
    if (!KNOWN_STATUSES.includes(s)) unknown.push({ reservationNo: it.reservationNo, status: it.status });
  }
  return { counts, unknown, total: items.length };
}

/**
 * @param {Array<{reservationNo:string, roomName:string, checkIn:string, checkOut:string, guestName?:string, status:string,
 *                guestPhone?:string, partySize?:number|null, amount?:number|null, memo?:string}>} items
 * @param {{extended?:boolean}} [opt] extended 면 연락처·인원·금액·요청사항 네 열을 더 붙인다
 * @returns {string} 헤더 포함 TSV. items 가 비면 헤더만.
 */
export function buildPasteText(items, opt = {}) {
  const ext = !!opt.extended;
  const rows = [(ext ? PASTE_HEADER_EXTENDED : PASTE_HEADER).join('\t')];
  for (const it of items) {
    const base = [
      cell(it.reservationNo), cell(it.roomName), cell(it.checkIn), cell(it.checkOut),
      cell(it.guestName), cell(normalizeStatus(it.status)),
    ];
    /* 금액은 0 을 빈칸으로 접지 않는다 — 무료 예약의 0 이 '금액 모름' 이 되면 안 된다(콘솔도 같은 규칙). */
    if (ext) {
      base.push(cell(it.guestPhone), cell(it.partySize ?? ''), cell(it.amount == null ? '' : it.amount), cell(it.memo));
      /* 정산(입금 예정) 금액. 판매 금액과 **다른 숫자**다 — 못 읽었으면 빈칸으로 둔다.
         빈칸이 아니라 판매 금액을 대신 넣으면 정산 내역이 조용히 틀린다. */
      base.push(cell(it.settleAmount == null ? '' : it.settleAmount));
    }
    rows.push(base.join('\t'));
  }
  return rows.join('\n');
}

/** 같은 예약번호가 여러 줄이면(목록이 겹쳐 읽힘) 마지막 것만 남긴다. 순서는 유지한다. */
export function dedupeByReservationNo(items) {
  const map = new Map();
  for (const it of items) map.set(String(it.reservationNo), it);
  return [...map.values()];
}

/**
 * 지난번보다 갑자기 확 줄었는가 — 거르개가 조용히 바뀌었을 때의 마지막 단서.
 * ★ 이것으로 **막지는 않는다**. 임계값에 실측 근거가 없고, 유입을 멈추면 그 사이 들어온 예약이
 *   원장에 안 들어가 그것대로 그 날이 다시 팔린다. 사람이 보게 소리만 낸다(경보 + 로그).
 *   정상적인 감소(성수기 끝·단체 취소·조회 창 굴러감)도 흔하므로 문턱은 느슨하게 둔다.
 * @returns {boolean}
 */
export function looksLikeShrink(lastSent, nowSent) {
  const last = Number(lastSent), now = Number(nowSent);
  if (!Number.isFinite(last) || !Number.isFinite(now)) return false;
  if (last < 5) return false;             // 기준선이 너무 작으면 판단하지 않는다
  return now < last / 2;
}

/** 서버 미리보기 응답이 우리가 보낸 것과 얼추 맞는지 — 읽힌 건수가 0 이거나 절반 넘게 못 읽으면 저장하지 않는다.
    statuses(summarizeStatuses 결과)를 주면 못 알아본 상태 문구도 함께 본다. 상태를 틀리게 보내면
    취소된 방이 '예약확정' 으로 원장에 들어가 그 날을 계속 팔게 된다 — 그건 못 읽은 것보다 나쁘다. */
export function previewLooksSane(preview, sent, statuses = null) {
  if (!preview || !preview.ok) return { ok: false, why: (preview && preview.error) || '응답 없음' };
  const total = (preview.summary && preview.summary.total) ?? (preview.items || []).length;
  const unreadable = (preview.unreadable || []).length;
  if (sent > 0 && total === 0) return { ok: false, why: '서버가 한 줄도 읽지 못했다 — 표 형식을 확인할 것' };
  if (sent > 0 && unreadable > sent / 2) return { ok: false, why: `절반 넘게 못 읽었다 (${unreadable}/${sent})` };
  if (statuses && statuses.total > 0) {
    const n = statuses.unknown.length;
    const sample = statuses.unknown.slice(0, 3).map((u) => `'${u.status}'`).join(', ');
    if (n === statuses.total) {
      return { ok: false, why: `상태 문구를 하나도 못 알아봤다 (${sample}) — 채널 JSON 과 normalizeStatus 를 맞출 것` };
    }
    if (n > statuses.total / 2) {
      return { ok: false, why: `상태 문구 ${n}/${statuses.total}건을 못 알아봤다 (${sample}) — 확정·취소가 뒤바뀔 수 있다` };
    }
  }
  return { ok: true, total, unreadable, unknownStatuses: statuses ? statuses.unknown.length : 0 };
}
